import subprocess
import sys
import traceback
import os
from pathlib import Path

import yaml
from ruamel.yaml import YAML

from deploy import log_utils

logger = log_utils.setup_logger()

def run_rdaf_precheck(spec_path):
    """Running the precheck.py script before proceeding with the deployment."""
    try:
        logger.info("Starting RDAF pre-checks on nodes...")
        script_path = Path(__file__).resolve().parent / "rdaf_precheck.py"
        result = subprocess.run(["python3", script_path, "--spec", spec_path], check=True)
        # Handle success scenario
        if result.returncode == 0:
            print("\033[92m[INFO] RDAF Pre-checks passed successfully. Proceeding with execution...\033[0m")
            logger.info("RDAF Pre-checks completed successfully.")
            return # Continue with deployment

    except subprocess.CalledProcessError as e:
        print("\033[91m[ERROR] RDAF Pre-check script failed. Stopping execution.\033[0m")
        logger.error("RDAF Pre-checks failed, stopping execution.", exc_info=True)
        sys.exit(1)
    except Exception as e:
        logger.error("Unexpected error in run_rdaf_precheck: %s", e, exc_info=True)
        print("\033[91m[ERROR] Unexpected error in RDAF Pre-check. Stopping execution.\033[0m")
        sys.exit(1)

def rdaf_generate_inventory_and_main_yaml(spec_model):
    logger.info("Generating inventory and main.yaml for RDAF")

    try:
        # Extract RDAF configuration
        rdaf_version = hosts = rdaf_config = None
        platforms = getattr(spec_model, "platforms", [])

        for platform in platforms:
            apps = getattr(platform, "apps", [])
            for app in apps:
                if getattr(app, "type", None) == "RDAF" or getattr(app, "name", None) == "RDAF":
                    rdaf_version = getattr(app, "version", None)
                    hosts = getattr(platform, "hosts", None)
                    creds = getattr(platform, "creds", None)
                    registry_server = getattr(platform, "registry_server", None)
                    rdaf_config = getattr(app, "tags_and_images", None)
                    # Extract fileobject and bulkstat server IPs
                  #  fileobject_server = getattr(app, "fileobject_server", None)
                  #  if fileobject_server:
                   #     fileobject_server = getattr(fileobject_server, "ip", [])
                  #  bulkstat_server = getattr(app, "bulkstat_server", None)
                  #  if bulkstat_server:
                   #     bulkstat_server = getattr(bulkstat_server, "ip", [])
                    break
            if rdaf_version and hosts and rdaf_config:
                break

        if not rdaf_version:
            logger.warning("RDAF version not found in the spec model.")
            rdaf_version = "8.0.0"  # Default version

        if not hosts or not isinstance(hosts, list):
            logger.warning("No RDAF nodes found or nodes invalid in spec.")
            hosts = ["127.0.0.1"]  # Default host

        if not rdaf_config:
            logger.warning("RDAF tags_and_images configuration not found in spec.")
            rdaf_config = {}  # Empty config

        ansible_user = getattr(creds, "user") if creds else "root"
        logger.info(f"RDAF version: {rdaf_version}, nodes: {len(hosts)}, user: {ansible_user}")

        inventory_file_path = Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "inventory" / "rdaf_inventory.ini"
        main_yaml_path = Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "group_vars" / "rdaf_main.yaml"
        main_yaml_path = Path(main_yaml_path)

        # Write all RDAF nodes dynamically to rdaf_inventory.ini
        try:
            with open(inventory_file_path, "w") as f:
                f.write("[rdaf_servers]\n")
                for i, host in enumerate(hosts, start=1):
                    f.write(f"rdaf_server_{i} ansible_host={host} ansible_user={ansible_user}\n")
                f.write("\n[deployer_server]\n")
                f.write(f"rdaf_server_1 ansible_host={registry_server} ansible_user={ansible_user}\n")
            logger.info(f"Wrote RDAF inventory with {len(hosts)} hosts")
        except Exception as e:
            logger.error(f"Failed to write RDAF inventory: {e}", exc_info=True)
            print(f"\033[91m[ERROR] Failed to write RDAF inventory: {e}\033[0m")

        yaml_ruamel = YAML()
        yaml_ruamel.preserve_quotes = True
        yaml_ruamel.indent(mapping=2, sequence=4, offset=2)

        try:
            if main_yaml_path.exists():
                with open(main_yaml_path, "r", encoding="utf-8") as f:
                    data = yaml_ruamel.load(f) or {}
            else:
                data = {}

            # Update values with RDAF configuration from tags_and_images
            for key, value in rdaf_config.items():
                data[key] = value

            # Add RDAF version
            data["rdaf_version"] = f"{rdaf_version}"
            data["rdaf_local_registry_ip"] = f"{registry_server}"
           # data["rdaf_fileobj_host"] = f"{fileobject_server}"
           # data["rdaf_bulkstat_host"] = f"{bulkstat_server}"


            with open(main_yaml_path, "w") as f:
                yaml_ruamel.dump(data, f)

            logger.info("RDAF inventory and main.yaml updated successfully")
            print(f"\033[92m[INFO] RDAF configuration files updated successfully\033[0m")

        except Exception as e:
            logger.error(f"Failed to update rdaf_main.yaml: {e}", exc_info=True)
            print("\033[91m[ERROR] Failed to update rdaf_main.yaml for RDAF. Stopping execution.\033[0m")
            sys.exit(1)
    
    except Exception as e:
        logger.error("Unexpected error in rdaf_generate_inventory_and_main_yaml: %s", e, exc_info=True)
        print("\033[91m[ERROR] Unexpected error in RDAF inventory/main.yaml generation. Stopping execution.\033[0m")
        sys.exit(1)


def run_rdaf_postcheck(spec_path):
    """Running the postcheck.py script after deployment."""
    try:
        logger.info("Starting RDAF post-checks on nodes...")
        script_path = Path(__file__).resolve().parent / "rdaf_postcheck.py"
        result = subprocess.run(["python3", script_path, "--spec", spec_path], check=True)

        # Handle success scenario
        if result.returncode == 0:
            print("\033[92m[INFO] RDAF Post-checks passed successfully.\033[0m")
            logger.info("RDAF Post-checks completed successfully.")
            return  # Continue with deployment

    except subprocess.CalledProcessError as e:
        print("\033[91m[ERROR] RDAF Post-check script failed. Stopping execution.\033[0m")
        logger.error("RDAF Post-checks failed, stopping execution.", exc_info=True)
        sys.exit(1)
    except Exception as e:
        logger.error("Unexpected error in run_rdaf_postcheck: %s", e, exc_info=True)
        print("\033[91m[ERROR] Unexpected error in RDAF Post-check. Stopping execution.\033[0m")
        sys.exit(1)

def deploy_userspec_rdaf(dry_run: bool = False) -> None:
    """
    Extract tags_and_images from userspec RDAF app block and create YAML file.
    """
    try:
        logger.info("Starting deploy_userspec_rdaf...")
        
        user_spec_path = Path(__file__).resolve().parent.parent / "config" / "path_config.yaml"
        logger.info(f"Looking for config file at: {user_spec_path}")
        
        try:
            with open(user_spec_path, "r", encoding="utf-8") as fh:
                user_spec_key = yaml.safe_load(fh) or {}
            userspec_path = user_spec_key['user_spec_path_key']['user_spec_path']
            logger.info(f"User spec path from config: {userspec_path}")
        except FileNotFoundError:
            logger.warning("userspec config file not found, using default path")
            userspec_path = "../specification/rdaf_spec/userSpecVanillaVM_rdaf.yaml"
        except (yaml.YAMLError, KeyError) as exc:
            logger.warning("userspec config error, using default path")
            userspec_path = "../specification/rdaf_spec/userSpecVanillaVM_rdaf.yaml"

        # Make path absolute relative to current working directory
        if not os.path.isabs(userspec_path):
            userspec_path = os.path.join(os.getcwd(), userspec_path)
        
        rdaf_main_yaml_path = Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "group_vars" / "rdaf_main.yaml"

        # Load userSpec file
        try:
            with open(userspec_path, "r", encoding="utf-8") as fh:
                user_spec = yaml.safe_load(fh) or {}
        except FileNotFoundError:
            logger.error("userspec file not found: %s", userspec_path, exc_info=True)
            raise Exception(f'userspec file not found at {userspec_path}')
        except yaml.YAMLError as exc:
            logger.error("userspec YAML error: %s", exc, exc_info=True)
            raise Exception('userspec YAML error')

        # Extract RDAF app block and find tags_and_images
        tags_and_images = None
        fileobject_nodes = None
        bulkstat_nodes = None
        platform_creds = None
        
        for platform in user_spec.get("platforms", []):
            platform_creds = platform.get("creds", {})
            for app in platform.get("apps", []):
                if app.get("name", "").upper() == "RDAF":
                    tags_and_images = app.get("tags_and_images", {})
                    fileobject_nodes = app.get("fileobject_server", {}).get("ip", [])
                    bulkstat_nodes = app.get("bulkstat_server", {}).get("ip", [])
                    logger.info(f"Found RDAF app - fileobject_nodes: {fileobject_nodes}, bulkstat_nodes: {bulkstat_nodes}")
                    logger.info(f"Platform creds: {platform_creds}")
                    break
            if tags_and_images:
                break

        if not tags_and_images:
            logger.error("No tags_and_images found in RDAF app block")
            print("\033[91m[ERROR] No tags_and_images found in user spec\033[0m")
            tags_and_images = {}

        # Add fileobject_server and bulkstat_server to tags_and_images
        if fileobject_nodes:
            rdaf_fileobj_host = ','.join(fileobject_nodes) if len(fileobject_nodes) > 1 else fileobject_nodes[0]
            tags_and_images["rdaf_fileobj_host"] = rdaf_fileobj_host
            logger.info(f"Added rdaf_fileobj_host: {rdaf_fileobj_host}")
        
        if bulkstat_nodes:
            rdaf_bulkstat_host = ','.join(bulkstat_nodes) if len(bulkstat_nodes) > 1 else bulkstat_nodes[0]
            tags_and_images["rdaf_bulkstat_host"] = rdaf_bulkstat_host

        if platform_creds and platform_creds.get("password"):
            tags_and_images["rdaf_setup_ssh_password"] = platform_creds.get("password")

        # Output result
        if dry_run:
            print(f"\033[92m[INFO] RDAF main.yaml content from tags_and_images:\033[0m")
            print(yaml.safe_dump(tags_and_images, sort_keys=False, default_flow_style=False))
            logger.info("rdaf_main.yaml content generated")
        else:
            try:
                # Ensure parent directory exists
                rdaf_main_yaml_path.parent.mkdir(parents=True, exist_ok=True)
                with open(rdaf_main_yaml_path, "w", encoding="utf-8") as fh:
                    yaml.safe_dump(tags_and_images, fh, sort_keys=False, default_flow_style=False)
                print(f"\033[92m[INFO] RDAF main.yaml updated successfully\033[0m")
                logger.info("rdaf_main.yaml updated from userspec tags_and_images")
            except Exception as e:
                logger.error("Failed to write updated rdaf_main.yaml: %s", e, exc_info=True)
                print(f"\033[91m[ERROR] Failed to write rdaf_main.yaml: {e}\033[0m")
                
    except Exception as e:
        logger.warning("Error in deploy_userspec_rdaf: %s", e, exc_info=True)
        print(f"\033[93m[WARNING] Could not deploy user spec for RDAF: {e}\033[0m")
        # Don't exit, continue with deployment

def generate_rdaf_input_template(dry_run: bool = False) -> None:
    """
    Generate input.json.j2 template dynamically from userSpec RDAF configuration.
    """
    try:
        logger.info("Starting generate_rdaf_input_template...")
        
        # Load userSpec file path
        user_spec_path = Path(__file__).resolve().parent.parent / "config" / "path_config.yaml"
        
        try:
            with open(user_spec_path, "r", encoding="utf-8") as fh:
                user_spec_key = yaml.safe_load(fh) or {}
            userspec_path = user_spec_key['user_spec_path_key']['user_spec_path']
        except FileNotFoundError:
            logger.warning("userspec config file not found, using default path")
            userspec_path = "../specification/rdaf_spec/userSpecVanillaVM_rdaf.yaml"
        except (yaml.YAMLError, KeyError) as exc:
            logger.warning("userspec config error, using default path")
            userspec_path = "../specification/rdaf_spec/userSpecVanillaVM_rdaf.yaml"

        # Make path absolute relative to current working directory
        if not os.path.isabs(userspec_path):
            userspec_path = os.path.join(os.getcwd(), userspec_path)
        
        # Load userSpec file
        try:
            with open(userspec_path, "r", encoding="utf-8") as fh:
                user_spec = yaml.safe_load(fh) or {}
        except FileNotFoundError:
            logger.error("userspec file not found: %s", userspec_path, exc_info=True)
            raise Exception(f'userspec file not found at {userspec_path}')
        except yaml.YAMLError as exc:
            logger.error("userspec YAML error: %s", exc, exc_info=True)
            raise Exception('userspec YAML error')

        # Extract platform and RDAF app configuration
        platform_config = user_spec.get("platforms", [{}])[0] if user_spec.get("platforms") else {}
        rdaf_app = None
        
        for app in platform_config.get("apps", []):
            if app.get("name", "").upper() == "RDAF" or app.get("type", "").upper() == "RDAF":
                rdaf_app = app
                break
        
        if not rdaf_app:
            logger.error("No RDAF app found in userSpec")
            raise Exception("No RDAF app found in userSpec")

        # Determine configuration values
        is_ha = rdaf_app.get("flavour", "").upper() == "HA"
        project_name = platform_config.get("project_name", "rdaf_org")
        
        # Extract node configurations
        infra_nodes = rdaf_app.get("infrastructure_nodes", {}).get("ip", [])
        platform_nodes = rdaf_app.get("platform_nodes", {}).get("ip", [])
        app_nodes = rdaf_app.get("application_nodes", {}).get("ip", [])
        worker_nodes = rdaf_app.get("worker_nodes", {}).get("ip", [])
        minio_additional_node = rdaf_app.get("minio_additional_node", {}).get("ip", [])
        fileobject_nodes = rdaf_app.get("fileobject_server", {}).get("ip", [])
        bulkstat_nodes = rdaf_app.get("bulkstat_server", {}).get("ip", [])
        
        # Extract credentials
        creds = platform_config.get("creds", {})
        ssh_user = creds.get("username", creds.get("user", "rdauser"))
        ssh_password = creds.get("password", "rdauser1234")
        
        # VIP configuration
        vip = platform_config.get("vip", "")

        # Event gateway host configuration - first 2 worker nodes if more than 1, else first one
        if len(worker_nodes) > 1:
            event_gateway_host = f"{worker_nodes[0]},{worker_nodes[1]}"
        elif worker_nodes:
            event_gateway_host = worker_nodes[0]
        else:
            event_gateway_host = "{{ ansible_default_ipv4.address }}"

        # Ha proxy host configuration - first 2 infra nodes if more than 1, else first one
        if len(infra_nodes) > 1:
            haproxy_host = f"{infra_nodes[0]},{infra_nodes[1]}"
        elif infra_nodes:
            haproxy_host = infra_nodes[0]
        else:
            haproxy_host = "{{ ansible_default_ipv4.address }}"

        # Configure hosts based on HA flavour
        if is_ha:
            # For HA, use all available nodes for each service
            nats_host = ','.join(infra_nodes) 
            mariadb_host = ','.join(infra_nodes) 
            kafka_host = ','.join(infra_nodes) 
            opensearch_host = ','.join(infra_nodes) 
            graphdb_host = ','.join(infra_nodes) 
            minio_nodes = infra_nodes+minio_additional_node
            minio_host = ','.join(minio_nodes) 
            
            # Service and worker hosts use all app nodes for HA
            service_host = ','.join(app_nodes) 
            worker_host = ','.join(worker_nodes) 
        else:
            # For non-HA, use single nodes
            nats_host = infra_nodes[0] if infra_nodes else '{{ ansible_default_ipv4.address }}'
            mariadb_host = infra_nodes[0] if infra_nodes else '{{ ansible_default_ipv4.address }}'
            kafka_host = infra_nodes[0] if infra_nodes else '{{ ansible_default_ipv4.address }}'
            opensearch_host = infra_nodes[0] if infra_nodes else '{{ ansible_default_ipv4.address }}'
            graphdb_host = infra_nodes[0] if infra_nodes else '{{ ansible_default_ipv4.address }}'
            minio_host = infra_nodes[0] if infra_nodes else '{{ ansible_default_ipv4.address }}'
            service_host = app_nodes[0] if app_nodes else '{{ ansible_default_ipv4.address }}'
            worker_host = worker_nodes[0] if worker_nodes else '{{ ansible_default_ipv4.address }}'

        # Generate the input.json.j2 template content
        template_content = f'''{{
"accept_eula": true,
"alt_names": "",
"app_service_ha": {str(is_ha).lower()},
"platform_service_ha": {str(is_ha).lower()},
"admin_organization": "{project_name}",
"docker_registry_ca": "",
"nats_host": "{nats_host}",
"minio_server_host": "{minio_host}",
"minio_user": "rdafadmin",
"minio_password": "rdaf1234",
"mariadb_server_host": "{mariadb_host}",
"mariadb_user": "rdafadmin",
"mariadb_password": "rdaf1234",
"kafka_server_host": "{kafka_host}",
"opensearch_server_host": "{opensearch_host}",
"opensearch_user": "rdafadmin",
"opensearch_password": "rdaf1234",
"graphdb_host": "{graphdb_host}",
"graphdb_password": "rdaf1234",
"graphdb_user": "rdafadmin",
"haproxy_host": "{haproxy_host}",
"bind_internal_inf": false,
"advertised_int_host": "",
"advertised_int_interface": "",
"bind_internal_inf": false,
"advertised_ext_host": "{vip if is_ha and vip else ''}",
"advertised_ext_interface": "ens160",
"platform_service_host": "{','.join(platform_nodes) if is_ha and platform_nodes else (platform_nodes[0] if platform_nodes else '{{ ansible_default_ipv4.address }}')}",
"service_host": "{service_host}",
"worker_host": "{worker_host}",
"rda_event_gateway_host": "{event_gateway_host}",
"ssh_password": "{ssh_password}",
"ssh_user": "{ssh_user}",
"no_prompt": true
}}'''

        # Define the template file path
        template_file_path = Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "roles" / "deploy_rdaf" / "rdaf_infra_services_install" / "templates" / "input.json.j2"

        # Output result
        if dry_run:
            print(f"\033[92m[INFO] Generated input.json.j2 template content:\033[0m")
            print(template_content)
            logger.info("input.json.j2 template content generated")
        else:
            try:
                # Ensure parent directory exists
                template_file_path.parent.mkdir(parents=True, exist_ok=True)
                with open(template_file_path, "w", encoding="utf-8") as fh:
                    fh.write(template_content)
                print(f"\033[92m[INFO] Generated input.json.j2 template successfully\033[0m")
                logger.info("input.json.j2 template generated from userspec with HA=%s, project=%s", is_ha, project_name)
            except Exception as e:
                logger.error("Failed to write input.json.j2 template: %s", e, exc_info=True)
                print(f"\033[91m[ERROR] Failed to write input.json.j2 template: {e}\033[0m")
                
    except Exception as e:
        logger.warning("Error in generate_rdaf_input_template: %s", e, exc_info=True)
        print(f"\033[93m[WARNING] Could not generate input.json.j2 template for RDAF: {e}\033[0m")
        # Don't exit, continue with deployment
