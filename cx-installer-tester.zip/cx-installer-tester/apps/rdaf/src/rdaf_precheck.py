"""
RDAF Pre-installation validation checks
Standalone executable script for RDAF deployment validation
"""

import argparse
import socket
import re
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Tuple

import yaml

from deploy import log_utils

logger = log_utils.setup_logger()

BASE_DIR = Path(__file__).resolve().parent.parent.parent.parent

def load_yaml(file_path):
    """Load YAML file with error handling."""
    try:
        with open(file_path, "r") as file:
            return yaml.safe_load(file)
    except Exception as e:
        print(f"\033[91m[ERROR] Failed to load YAML: {str(e)}\033[0m")
        sys.exit(1)

def run_ssh_command(host, username, password, command):
    """Run SSH command using sshpass."""
    full_command = f"sshpass -p '{password}' ssh -o StrictHostKeyChecking=no {username}@{host} '{command}'"
    try:
        result = subprocess.run(
            full_command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        return result.stdout.strip(), result.stderr.strip(), result.returncode
    except Exception as e:
        logger.error("SSH command failed on %s: %s", host, str(e))
        return "", str(e), 1

# Define minimum partition sizes in GB by role (from your original script)
PARTITION_REQUIREMENTS = {
    "infra": {
        "/": 75,
        "/opt": 50,
        "/var/lib/docker": 50,
        "/minio-data": 50,
        "/kafka-logs": 25,
        "/var/mysql": 50,
        "/opensearch": 50,
        "/graphdb": 50,
    },
    "platform": {
        "/": 75,
        "/opt": 50,
        "/var/lib/docker": 50,
    },
    "worker": {
        "/": 75,
        "/opt": 25,
        "/var/lib/docker": 25,
    }
}

def _extract_hosts_creds(spec):
    """Extract RDAF hosts and credentials from spec file."""
    for plat in spec.get("platforms", []):
        if plat.get("type") == "VanillaVM":
            creds = plat.get("creds", {})
            hosts = plat.get("hosts", [])
            user = creds.get("user")
            pwd = creds.get("password")
            return hosts, user, pwd
    return [], None, None

def _extract_rdaf_roles(spec):
    """Extract RDAF node roles from spec."""
    roles = {}
    for plat in spec.get("platforms", []):
        if plat.get("type") == "VanillaVM":
            for app in plat.get("apps", []):
                if app.get("type") == "RDAF":
                    node_roles = app.get("node_roles", {})
                    for role, hosts in node_roles.items():
                        for host in hosts:
                            roles[host] = role.lower()
    return roles

def _check_ssh_prereqs(hosts, user, pwd, check_name):
    """Check SSH prerequisites."""
    if not hosts or not user or not pwd:
        print(f"\033[91m[FAILED] {check_name}: Missing SSH credentials or hosts\033[0m")
        logger.error("[FAILED] %s: hosts=%s, user=%s, password=%s", check_name, hosts, user, 'set' if pwd else 'not set')
        return False
    return True

def _check_reachability(host):
    """Check if host is reachable on SSH port."""
    try:
        socket.setdefaulttimeout(3)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, 22))
        return True
    except Exception:
        return False

# def _check_partitions(host, user, pwd, role):
#     """Check partition requirements for specific RDAF role (adapted from your script)."""
#     required_partitions = PARTITION_REQUIREMENTS.get(role)
#     if not required_partitions:
#         return True, f"No partition requirements defined for role '{role}'"

#     # Get disk usage in GB for all mounted filesystems
#     cmd = "df -BG --output=target,avail | tail -n +2"
#     stdout, stderr, rc = run_ssh_command(host, user, pwd, cmd)
    
#     if rc != 0:
#         return False, f"Failed to get partition info: {stderr}"

#     # Parse output into dict {mount_point: available_size_in_GB}
#     available = {}
#     for line in stdout.splitlines():
#         parts = line.split()
#         if len(parts) != 2:
#             continue
#         mount_point, avail_str = parts
#         if avail_str.endswith("G"):
#             try:
#                 available[mount_point] = int(avail_str[:-1])
#             except:
#                 pass

#     # Check each required partition
#     failures = []
#     successes = []
#     for partition, min_size in required_partitions.items():
#         avail = available.get(partition)
#         if avail is None:
#             failures.append(f"Partition {partition}: NOT MOUNTED or NOT FOUND")
#         elif avail < min_size:
#             failures.append(f"Partition {partition}: {avail}GB available, LESS than required {min_size}GB")
#         else:
#             successes.append(f"Partition {partition}: OK ({avail}GB available)")

#     if failures:
#         result_msg = "Partition check failures:\n" + "\n".join(failures)
#         if successes:
#             result_msg += "\nPassed partitions:\n" + "\n".join(successes)
#         return False, result_msg
#     else:
#         return True, "All partition requirements met:\n" + "\n".join(successes)

def _check_partitions(host, user, pwd, role):
    """Check partition requirements for RDAF standalone deployment."""
    # Standalone RDAF partition requirements (temporarily lowered for testing)
    required_partitions = {
        "/": 50,  # Temporarily lowered from 75GB to 50GB
        "/opt": 50,
        "/var/lib/docker": 100,
        "/minio-data": 50,
        "/kafka-logs": 25,
        "/var/mysql": 50,
        "/opensearch": 50,
        "/graphdb": 50,
    }

    # Get total disk size in GB for all mounted filesystems
    cmd = "df -BG --output=target,size | tail -n +2"
    stdout, stderr, rc = run_ssh_command(host, user, pwd, cmd)
    
    if rc != 0:
        return False, f"Failed to get partition info: {stderr}"

    # Parse output into dict {mount_point: total_size_in_GB}
    total_sizes = {}
    for line in stdout.splitlines():
        parts = line.split()
        if len(parts) != 2:
            continue
        mount_point, size_str = parts
        if size_str.endswith("G"):
            try:
                total_sizes[mount_point] = int(size_str[:-1])
            except:
                pass

    # Check each required partition
    failures = []
    successes = []
    for partition, min_size in required_partitions.items():
        total = total_sizes.get(partition)
        if total is None:
            failures.append(f"Partition {partition}: NOT MOUNTED or NOT FOUND")
        elif total < min_size:
            failures.append(f"Partition {partition}: {total}GB total size, LESS than required {min_size}GB")
        else:
            successes.append(f"Partition {partition}: OK ({total}GB total size)")

    if failures:
        result_msg = "Partition check failures:\n" + "\n".join(failures)
        if successes:
            result_msg += "\nPassed partitions:\n" + "\n".join(successes)
        return False, result_msg
    else:
        return True, "All partition requirements met:\n" + "\n".join(successes)

def check_network_reachability(spec):
    """Check network reachability to all RDAF hosts."""
    print(f"\n\033[94m---Checking Network Reachability---\033[0m")
    
    hosts, user, pwd = _extract_hosts_creds(spec)
    if not _check_ssh_prereqs(hosts, user, pwd, "check_network_reachability"):
        return False

    failed = []
    
    for host in hosts:
        if _check_reachability(host):
            print(f"\033[92m[OK] {host}:\033[0m Reachable on SSH port 22")
            logger.info("[OK] %s: Reachable on SSH port 22", host)
        else:
            failed.append(f"{host}: NOT reachable on SSH port 22")
            print(f"\033[91m[FAILED] {host}:\033[0m NOT reachable on SSH port 22")
            logger.error("[FAILED] %s: NOT reachable on SSH port 22", host)

    if not failed:
        print(f"\033[92m[OK] All RDAF hosts are reachable on SSH port.\033[0m")
        logger.info("[OK] All RDAF hosts are reachable on SSH port.")
        return True
    else:
        print(f"\033[91m[FAILED] Network reachability check failed:\033[0m")
        for failure in failed:
            print(f"  - {failure}")
        logger.error("[FAILED] Network reachability check failed: %s", "; ".join(failed))
        return False

def check_rdaf_partition_requirements(spec):
    """Check RDAF-specific partition requirements by role."""
    print(f"\n\033[94m---Checking RDAF Partition Requirements---\033[0m")
    
    hosts, user, pwd = _extract_hosts_creds(spec)
    if not _check_ssh_prereqs(hosts, user, pwd, "check_rdaf_partition_requirements"):
        return False

    roles = _extract_rdaf_roles(spec)
    failed = []
    
    for host in hosts:
        role = roles.get(host, "worker")  # Default to worker if role not specified
        success, message = _check_partitions(host, user, pwd, role)
        
        print(f"\033[94m{host} (role: {role}):\033[0m")
        if success:
            print(f"\033[92m[OK] Partition requirements met\033[0m")
            for line in message.split('\n'):
                if line.strip():
                    print(f"  {line}")
            logger.info("[OK] %s (role: %s): Partition requirements met", host, role)
        else:
            print(f"\033[91m[FAILED] Partition requirements not met\033[0m")
            for line in message.split('\n'):
                if line.strip():
                    print(f"  {line}")
            failed.append(f"{host} (role: {role}): Partition requirements not met")
            logger.error("[FAILED] %s (role: %s): Partition requirements not met", host, role)

    if not failed:
        print(f"\033[92m[OK] All RDAF partition requirements are met.\033[0m")
        logger.info("[OK] All RDAF partition requirements are met.")
        return True
    else:
        print(f"\033[91m[FAILED] Partition requirements check failed:\033[0m")
        for failure in failed:
            print(f"  - {failure}")
        logger.error("[FAILED] Partition requirements check failed: %s", "; ".join(failed))
        return False

def check_rdaf_system_requirements(spec):
    """Check basic system requirements (OS, Python, resources)."""
    print(f"\n\033[94m---Checking RDAF System Requirements---\033[0m")
    
    hosts, user, pwd = _extract_hosts_creds(spec)
    if not _check_ssh_prereqs(hosts, user, pwd, "check_rdaf_system_requirements"):
        return False

    failed = []
    
    for host in hosts:
        print(f"\033[94m{host}:\033[0m")
        host_failures = []
        
        # Check OS version
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "cat /etc/os-release | grep PRETTY_NAME")
        if rc == 0 and stdout:
            print(f"\033[92m[OK] OS:\033[0m {stdout}")
            logger.info("[OK] %s: OS: %s", host, stdout)
        else:
            host_failures.append("OS version check failed")
            print(f"\033[91m[FAILED] OS:\033[0m version check failed - {stderr}")
            logger.error("[FAILED] %s: OS version check failed - %s", host, stderr)

        # Check Python version
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "python3 --version || python --version")
        if rc == 0 and stdout:
            print(f"\033[92m[OK] Python:\033[0m {stdout}")
            logger.info("[OK] %s: Python: %s", host, stdout)
        else:
            host_failures.append("Python not available")
            print(f"\033[91m[FAILED] Python:\033[0m not available - {stderr}")
            logger.error("[FAILED] %s: Python not available - %s", host, stderr)

        # Check CPU cores (using lscpu with safe parsing - no shell syntax issues)
        stdout, stderr, rc = run_ssh_command(host, user, pwd, "lscpu")
        if rc == 0 and stdout:
            # Parse lscpu output to find CPU(s) line and extract the number
            cpu_count = None
            for line in stdout.split('\n'):
                line = line.strip()
                # Look for the CPU(s): line and extract the number
                if line.startswith('CPU(s):') or 'CPU(s):' in line:
                    parts = line.split(':')
                    if len(parts) >= 2:
                        try:
                            cpu_count = int(parts[1].strip())
                            break
                        except:
                            continue
            
            if cpu_count is not None:
                if cpu_count < 2:  # Minimum 2 cores for RDAF
                    host_failures.append(f"Insufficient CPU cores: {cpu_count} (minimum 2)")
                    print(f"\033[91m[FAILED] CPU cores:\033[0m {cpu_count} (minimum 2 required)")
                    logger.error("[FAILED] %s: Insufficient CPU cores: %d (minimum 2)", host, cpu_count)
                else:
                    print(f"\033[92m[OK] CPU cores:\033[0m {cpu_count}")
                    logger.info("[OK] %s: CPU cores: %d", host, cpu_count)
            else:
                host_failures.append("Could not parse CPU count from lscpu output")
                print(f"\033[91m[FAILED] CPU cores:\033[0m Could not parse CPU count")
                logger.error("[FAILED] %s: Could not parse CPU count from lscpu output", host)
        else:
            host_failures.append("CPU check failed")
            print(f"\033[91m[FAILED] CPU cores:\033[0m check failed - {stderr}")
            logger.error("[FAILED] %s: CPU check failed - %s", host, stderr)

        # Check memory (completely banner-safe approach)
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "cat /proc/meminfo | head -1")
        if rc == 0 and stdout:
            # Extract memory value from first line of /proc/meminfo
            lines = [line.strip() for line in stdout.split('\n') if line.strip() and 'MemTotal:' in line]
            if lines:
                try:
                    # Parse "MemTotal:     67133952 kB" format
                    mem_line = lines[-1]  # Take last valid MemTotal line
                    parts = mem_line.split()
                    if len(parts) >= 2:
                        mem_kb = int(parts[1])
                        mem_gb = mem_kb / 1048576  # Convert kB to GB
                        if mem_gb < 63:  # Allow 63GB+ (1GB buffer below 64GB requirement)
                            host_failures.append(f"Insufficient memory: {mem_gb:.2f}GB (minimum 63GB)")
                            print(f"\033[91m[FAILED] Memory:\033[0m {mem_gb:.2f}GB (minimum 63GB required)")
                            logger.error("[FAILED] %s: Insufficient memory: %.2fGB (minimum 63GB)", host, mem_gb)
                        else:
                            print(f"\033[92m[OK] Memory:\033[0m {mem_gb:.2f}GB")
                            logger.info("[OK] %s: Memory: %.2fGB", host, mem_gb)
                    else:
                        host_failures.append("Could not parse memory format")
                        print(f"\033[91m[FAILED] Memory:\033[0m Could not parse format - {stdout}")
                        logger.error("[FAILED] %s: Could not parse memory format - %s", host, stdout)
                except (ValueError, IndexError) as e:
                    host_failures.append("Could not parse memory size")
                    print(f"\033[91m[FAILED] Memory:\033[0m Could not parse size - {stdout}")
                    logger.error("[FAILED] %s: Could not parse memory size - %s", host, stdout)
            else:
                host_failures.append("Could not find MemTotal in output")
                print(f"\033[91m[FAILED] Memory:\033[0m Could not find MemTotal - {stdout}")
                logger.error("[FAILED] %s: Could not find MemTotal - %s", host, stdout)
        else:
            host_failures.append("Memory check failed")
            print(f"\033[91m[FAILED] Memory:\033[0m check failed - {stderr}")
            logger.error("[FAILED] %s: Memory check failed - %s", host, stderr)

        # Check time synchronization (using timedatectl show command)
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "timedatectl show -p NTPSynchronized --value")
        if rc == 0 and stdout.strip().lower() == "yes":
            print(f"\033[92m[OK] Time sync:\033[0m YES")
            logger.info("[OK] %s: Time sync: YES", host)
        else:
            host_failures.append("Time synchronization not enabled or not working")
            print(f"\033[91m[FAILED] Time sync:\033[0m NOT synchronized - {stdout.strip()}")
            logger.error("[FAILED] %s: Time synchronization failed - %s", host, stdout.strip())

        if host_failures:
            failed.extend([f"{host}: {failure}" for failure in host_failures])

    if not failed:
        print(f"\033[92m[OK] All RDAF system requirements are met.\033[0m")
        logger.info("[OK] All RDAF system requirements are met.")
        return True
    else:
        print(f"\033[91m[FAILED] System requirements check failed:\033[0m")
        for failure in failed:
            print(f"  - {failure}")
        logger.error("[FAILED] System requirements check failed: %s", "; ".join(failed))
        return False

def check_docker_requirements(spec):
    """Check Docker service and container runtime requirements."""
    print(f"\n\033[94m---Checking Docker Requirements---\033[0m")
    
    hosts, user, pwd = _extract_hosts_creds(spec)
    if not _check_ssh_prereqs(hosts, user, pwd, "check_docker_requirements"):
        return False

    failed = []
    
    for host in hosts:
        print(f"\033[94m{host}:\033[0m")
        host_failures = []
        
        # Check Docker service status
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "systemctl is-active docker")
        if rc == 0 and stdout.strip() == "active":
            print(f"\033[92m[OK] Docker service:\033[0m ACTIVE")
            logger.info("[OK] %s: Docker service: ACTIVE", host)
        else:
            host_failures.append("Docker service not active")
            print(f"\033[91m[FAILED] Docker service:\033[0m INACTIVE - {stdout}")
            logger.error("[FAILED] %s: Docker service not active - %s", host, stdout)

        # Check Docker version
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "docker --version")
        if rc == 0 and stdout:
            print(f"\033[92m[OK] Docker version:\033[0m {stdout}")
            logger.info("[OK] %s: Docker version: %s", host, stdout)
        else:
            host_failures.append("Docker command not available")
            print(f"\033[91m[FAILED] Docker version:\033[0m command not available - {stderr}")
            logger.error("[FAILED] %s: Docker command not available - %s", host, stderr)

        # Check if user can run docker commands
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "docker info > /dev/null 2>&1 && echo OK || echo FAILED")
        if stdout.strip() == "OK":
            print(f"\033[92m[OK] Docker access:\033[0m OK")
            logger.info("[OK] %s: Docker access: OK", host)
        else:
            host_failures.append("User cannot run docker commands (may need docker group membership)")
            print(f"\033[91m[FAILED] Docker access:\033[0m User cannot run docker commands")
            logger.error("[FAILED] %s: User cannot run docker commands", host)
        
        if host_failures:
            failed.extend([f"{host}: {failure}" for failure in host_failures])

    if not failed:
        print(f"\033[92m[OK] Docker requirements are met on all hosts.\033[0m")
        logger.info("[OK] Docker requirements are met on all hosts.")
        return True
    else:
        print(f"\033[91m[FAILED] Docker requirements check failed:\033[0m")
        for failure in failed:
            print(f"  - {failure}")
        logger.error("[FAILED] Docker requirements check failed: %s", "; ".join(failed))
        return False


def main():
    """Main function to run RDAF precheck."""
    parser = argparse.ArgumentParser(description="RDAF Precheck")
    parser.add_argument("--spec", required=True, help="Path to spec YAML file")
    args = parser.parse_args()

    YAML_FILE = Path(args.spec).resolve()
    spec_data = load_yaml(YAML_FILE)

    username = None
    password = None
    hosts = []

    vanilla_platforms = [p for p in spec_data.get("platforms", []) if p.get("type") == "VanillaVM"]
    for platform in vanilla_platforms:
        apps = platform.get("apps", [])
        for app in apps:
            if app.get("type") == "RDAF" or app.get("name") == "RDAF":
                creds = platform.get("creds", {})
                username = creds.get("user")
                password = creds.get("password")
                hosts = platform.get("hosts", [])

    if not username or not password or not hosts:
        print("\033[91m[ERROR] RDAF app credentials or hosts missing in spec YAML.\033[0m")
        sys.exit(1)

    print("\n" + "="*60) 
    print("\033[1;96m ⚡ RDAF PRE-INSTALLATION CHECKS ⚡\033[0m")
    print("\n" + "="*60)
    print(f"Checking RDAF deployment prerequisites on hosts: {', '.join(hosts)}")

    all_success = True
    
    # Run all RDAF pre-installation checks
    if not check_network_reachability(spec_data):
        all_success = False
        
    if not check_rdaf_system_requirements(spec_data):
        all_success = False
        
    if not check_docker_requirements(spec_data):
        all_success = False
        
    if not check_rdaf_partition_requirements(spec_data):
        all_success = False

    if all_success:
        print("\n\033[92mRDAF pre-checks passed on all hosts.\033[0m")
        sys.exit(0)
    else:
        print("\n\033[91mOne or more RDAF pre-checks failed.\033[0m")
        sys.exit(1)


if __name__ == "__main__":
    main()

