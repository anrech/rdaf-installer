Why cx-Installer ?
The CX Delivery Team works across a broad portfolio of software products, supporting complex project lifecycles. One of the initial and most critical tasks for any project team is the installation and setup of these applications across various environments — including sandbox, development, staging, and production.

This process is often repetitive and time-consuming, as it needs to be executed multiple times for different environments. Beyond installation, there are essential platform requirements such as:

Proper sizing and scaling,

High availability and Geo-redundancy,

Monitoring and alerting,

And robust failure recovery mechanisms.

All of these tasks demand significant delivery effort and are prone to inconsistency when performed manually.

To address these challenges, we introduce cx-Installer — a platform designed to simplify and automate the complete lifecycle management (LCM) of software applications. Built on the principles of Infrastructure as Code (IaC), cx-Installer enables:

Consistent and repeatable deployments across all environments,

Standardization of configurations,

Reduced manual effort and delivery timelines,

And improved reliability and scalability of application environments.

With cx-Installer, the CX Delivery Team can focus more on value-driven tasks while ensuring that foundational setup and operations are handled efficiently and transparently.

The cx-installer artifacts are currently hosted on the VM with IP address 10.127.195.225 hosted by the nginx server, and you can manually look in the browser and download from the http://10.127.195.225 given that you are in the cisco network.

If you want to add any new files on this artifact repository
```bash
ssh root@10.127.195.225

cd  /var/www/artifacts/cx-installer-artifacts/
```
Add your files on the files/ directory of this path
### Run the binary to download and install the necessary packages required by the platform installer (one-time setup)

``` bash
scripts/setup_cxinstaller_prereqs
```
The script provided above is sufficient to install all required prerequisites. The following installation steps are included for reference purposes only.
# platform-installer

**PREREQUISITE FOR RUNNING INSTALLER:**
1. Python 3.12.x
2. The spec file((after cloning ../userSpecRKE2_bpa.yaml)) specified, needs to have proper VM ip and other inputs as per your environment . E.g. userSpecRKE2_bpa.yaml for BPA
3. Install the python dependencies -
   - pip install click
   - pip install pydantic
5. Also install below,
   - pip install ansible-runner
   - pip install paramiko
   - pip install kubernetes
   - pip install ansible
   - pip install ruamel.yaml
6. In the spec file userSpecRKE2_bpa.yaml(after cloning ../userSpecRKE2_bpa.yaml), jump-rke is the worker node
7. registry server is where we host our docker/containerd images... in our setup both the worker node and the registry server are in the same node
8. Also below commands are needed to be run on the host VM for python to run the pre-checks by logging into the host VM and run ansible playbook.

    sudo yum install epel-release -y  (for almalinux)

    sudo yum install sshpass -y (for almalinux)

**PRECHECK for BPA:**
**For BPA application below are the hardware requirements.**
16 core CPU ==cat /proc/cpuinfo

32GB memory  ===cat /proc/meminfo

Disk space - 500 GB for /opt  ==== df -h

Network port - 443 to be open  ==== netstat -tuln

NIC - 1 for BPA == ip link show

**below are the software requirements.**
NTP is running or not running == systemctl status chronyd

DNS is configured or not ===nmcli dev show | grep DNS

SMTP server access check === nc -zv smtp.example.com 25

Proxy is enabled or not === env | grep -i proxy
 
If the above conditions are not met, execution stops.


**For contributing to this project, Run below command to adhere to PEP8 formatting standard before making final commits**
1. pre-commit install

**STEPS TO RUN BPA Installation:**

1. Clone the cx-installer repo.
2. cd deploy
3. export PYTHONPATH = Absolute path to cx-installer folder
4. export ANSIBLE_CONFIG= Absolute path of ansible.cfg


**For installing RKE2 + BPA**


**To run the dry-run of deployement use below command:**

python cli.py --spec ../specification/bpa_spec/userSpecRKE2_bpa.yaml --dry-run

**To run the actual deployement run as below:**

python cli.py --spec ../specification/bpa_spec/userSpecRKE2_bpa.yaml


###############################################################

**EXPLANATION OF SPECFILE ATTRIBUTES:**

###############################################################

platform:  =>

  type: RKE2 =>

  creds:

    user: root

    password: cisco

  hosts:

    - 10.127.195.222

    - 10.127.195.223

    - 10.127.195.224

  jump_server: 10.127.195.224

  registry_server: 10.127.195.224

  vip: 10.127.195.242

apps:

  - name: BPA
  -
    type: BPA

    nodes:

      - 10.127.195.222

      - 10.127.195.223

      - 10.127.195.224
      -
    vip_ip: 10.127.195.242

    vip: 'yes'

    purge: 'yes'

    ingress: 'yes'

    registry_url: containers.cisco.com

    registry_path: bpa

    registry_username: <Private Registry username>

    registry_password: <Private Registry Password>

    entitlements:

      - customer: Dish

      - deploymentType: Regular

      - platform_components: true

      - platform_service_catalog: true

      - Software Conformance and Upgrades: true

      - Config Complaiance: false

      - Config Backup and Restore: true

      - Device Onboarding With ZTP: false


**STEPS TO RUN NSO Installation:**

1. Clone the cx-installer repo.
2. cd deployer
3. export PYTHONPATH = Absolute path to cx-installer folder
4. export ANSIBLE_CONFIG=/path_to/cx-installer/ansible_playbooks/ansible.cfg

###########################
**For installing NSO on a VM**
###########################

**To run the dry-run of deployement use below command:**

python cli.py --spec ../specification/nso_spec/userSpecVanillaVM_nso.yaml --dry-run

**To run the actual deployement run as below:**

python cli.py --spec ../specification/nso_spec/userSpecVanillaVM_nso.yaml

###############################################################

**Explanation of Schema**

###############################################################

**Top-Level Structure**

The schema expects an object with a single required key:
platforms:
A list (array) of platform configurations.
Each platform is represented as an object with specific properties.

Properties of platforms:

=========================

Each item in the platforms array must follow the structure defined by the schema. Let’s break it down:


1. type (required)

Specifies the type of platform.
Must be one of the following:
"RKE2"
"Vanilla VM"
This ensures the type field is limited to only valid platform types.

2. creds (required)

Represents the credentials for the platform.
creds is an object with two required fields:
user: Must be a string.
password: Must be a string.
This enforces that both user and password must be provided.

3. hosts (required)

A list (array) of IP addresses (as strings).
Each item in the array must follow the IPv4 address format (e.g., 10.127.195.222).
This ensures that the hosts list only contains valid IP addresses.

4. jump_server (optional)

A string representing the IP address of the jump server.
Can be null (if not provided).
If provided, it must be a valid IPv4 address.

5. registry_server (optional)

A string representing the IP address of the registry server.
Can be null (if not provided).
If provided, it must be a valid IPv4 address.

6. vip (optional)

A string representing the VIP (virtual IP) address.
Can be null (if not provided).
If provided, it must be a valid IPv4 address.

7. apps (required)

A list (array) of applications deployed on the platform.
Each application is an object with specific properties (described below).

Properties of Each Application (apps)

========================================

Each item in the apps array must follow the structure defined by the schema:


1. name (required)

The name of the application (e.g., BPA, NSO).
Must be a string.

2. type (required)

Specifies the type of the application.
Must be one of the following:
"NSO"
"BPA"
"Postgres"
This ensures that only valid application types are allowed.

3. version (optional)

Specifies the version of the application.
Must be a string.

4. creds (optional)

Represents credentials required for the application.
If provided, it is an object with two required fields:
user: Must be a string.
password: Must be a string.

5. nodes (optional)

A list (array) of IP addresses (as strings) where the application is deployed.
Each IP must follow the IPv4 address format.

6. vip_ip (optional)

A string representing the VIP IP address for the application.
Can be null (if not provided).
If provided, it must be a valid IPv4 address.

7. vip, purge, ingress (optional)

Each of these fields is a string.
Allowed values: "yes" or "no".
These fields indicate whether certain features (e.g., VIP, purge, ingress) are enabled for the application.

8. registry_url (optional)

A string representing the URL of the registry server for the application.
Must follow the URI format (e.g., https://containers.cisco.com).

9. registry_path, registry_username, registry_password (optional)

Strings representing the registry path, username, and password for the application registry.
These fields allow you to specify details for accessing the registry.

10. entitlements (optional)

A list (array) of entitlement objects for the application.
Each entitlement is an object with various fields:
customer: Must be a string (e.g., "Dish").
deploymentType: Must be a string (e.g., "Regular").
Feature Flags:
Boolean fields like platform_components, platform_service_catalog, etc., indicate whether specific features are enabled (e.g., true or false).

Validation Rules

=======================================

Required Fields:

=====================

platforms is mandatory at the top level.
Within each platform, the following are required:
type
creds (with user and password).
hosts (array).
apps (array).
Within each application in apps, name and type are required.
Data Types and Formats:

Strings, arrays, and objects are validated for correct data types.
IP addresses are validated using the ipv4 format.
URLs are validated using the uri format.
Enumerations:

Specific fields (like type, vip, purge, ingress) are restricted to predefined values (enum), ensuring they only accept valid inputs.
Optional Fields:

Some fields (e.g., jump_server, registry_server, vip, etc.) are optional but validated when provided.
Boolean Flags:

Fields like platform_components and Config Backup and Restore in entitlements are strictly boolean (true or false).


## 1. For building the Binary setup_prerequisites

Run PyInstaller in **onefile mode**:

```bash
cd scripts/
pyinstaller --onefile setup_prerequisites.py
cp dist/setup_prerequisites setup_cxinstaller_prereqs
rm -rf setup_cxinstaller_prereqs.spec build/ dist/
```
