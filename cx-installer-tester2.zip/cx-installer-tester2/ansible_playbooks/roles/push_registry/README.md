# 📦 Private Registry Image Push Guide

This guide outlines the procedure to package and push Docker images to a private registry using Ansible.

---


## 🚀 Steps to Push Images

### 1. **List Required Images**

Identify and list all Docker images necessary for your application version.

### 2. **Save Images as Tar Files**

For each image, save it as a `.tar` file:

```bash
docker save -o <image-name>.tar <image-name>:<tag>
```

Example:

```bash
docker save -o myapp-backend.tar myapp-backend:1.0.0
```

### 3. **Organize Tar Files**

Create a directory named after your application and version, then move all `.tar` files created out of these into this directory:

```bash
mkdir -p myapp_1.0.0
mv *.tar myapp_1.0.0/
```

### 4. **Compress the Directory**

Compress the directory into a `.tar.gz` archive:

```bash
tar -czvf myapp_1.0.0.tar.gz myapp_1.0.0/
```

### 5. **Place Archive in Designated Location**

Move the compressed archive to the following path:

Ensure the directory structure `rke2/images/application_name/application_version/` exists.

```bash
mv myapp_1.0.0.tar.gz rke2/images/myapp/1.0.0/
```


### 6. **Run Ansible Playbook**

From the base directory of your repository, execute the Ansible playbook to push images to the private registry:

```bash
ansible-playbook -i inventory.ini private-registry-push.yaml
```

This playbook will load the images from the `.tar.gz` archive and push them to the configured private registry.

---

## 📂 Directory Structure Overview

```
rke2/
└── images/
    └── myapp/
        └── 1.0.0/
            └── myapp_1.0.0.tar.gz
```

---

## ✅ Verification

After running the playbook, verify that the images are available in your private registry by listing the images:

```bash
curl -X GET http://registry_ip:5000/v2/_catalog
```

You should see the images tagged appropriately and available for deployment.

---
