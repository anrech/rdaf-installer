# ansible-rke2

## Overview
A modular, extensible, and maintainable Ansible repository for Kubernetes (RKE2/kubeadm) and BPA/NSO deployments in both airgap and online environments.

## Structure

```
ansible-rke2/
├── ansible.cfg
├── README.md
├── inventory/
│   ├── hosts.ini
│   └── group_vars/
│       ├── all.yml
│       ├── k8s_airgap.yml
│       └── ...
├── playbooks/
│   ├── preinstall.yml
│   ├── rke2-install.yml
│   ├── kubeadm-airgap.yml
│   ├── bpa-install.yml
│   └── ...
├── roles/
│   ├── common/
│   ├── k8s_install/
│   │   ├── prepare_airgap/
│   │   ├── install_kube_packages/
│   │   ├── load_images/
│   │   ├── kubeadm_init/
│   │   └── kubeadm_join/
│   ├── rke2/
│   ├── deploy_bpa/
│   ├── deploy_nso/
│   ├── postinstall/
│   ├── preinstall/
│   └── ...
├── files/
│   └── artifacts/
└── vars/
    └── main.yml
```

## Usage

- Preinstall: `ansible-playbook -i inventory/hosts.ini playbooks/preinstall.yml`
- Kubeadm Airgap: `ansible-playbook -i inventory/hosts.ini playbooks/kubeadm-airgap.yml`
- RKE2 Install: `ansible-playbook -i inventory/hosts.ini playbooks/rke2-install.yml`
- BPA Install: `ansible-playbook -i inventory/hosts.ini playbooks/bpa-install.yml`

## Principles
- All playbooks in `playbooks/`
- All inventories and group_vars in `inventory/`
- All roles in `roles/` (self-contained)
- All artifacts/scripts in `files/`
- No business logic in the root directory
- Each playbook does one thing (preinstall, install, postinstall, etc)
- Group/host variables in `inventory/group_vars/` and `inventory/host_vars/`

## Extending
- Add new features by creating a new role or playbook
- Add new OS support by extending roles and group_vars
- Add new clusters or environments by adding new inventories

## Example: Adding a new role
1. Create a new role in `roles/your_role/`
2. Add tasks, handlers, templates, etc.
3. Reference it in a playbook in `playbooks/`

---
