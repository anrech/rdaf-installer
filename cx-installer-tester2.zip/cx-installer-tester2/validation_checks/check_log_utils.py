import logging
import logging.config
import os
import sys
from pathlib import Path

# Global flag to ensure logging is configured only once
_logging_configured = False

LOG_ROOT_PATH = "./check_logs"
LOG_FILE_MAIN = "validation_checks.log"
LOG_FILE_REPORTS = "validation_reports.log"

LOGGING_CONFIG_DICT = {
    # Boilerplate
    "version": 1,
    "disable_existing_loggers": False,   # keep stdlib & dependency loggers alive

    # Log Formatters
    "formatters": {
        "verbose": {                     # timestamp, level, module, message
            "format": "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S",
        },
        "simple": {                      # just level + message (for console)
            "format": "%(levelname)-8s: %(message)s",
        },
    },

    # Log Stream Handlers
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "level": "DEBUG",
            "formatter": "simple",
        },
        "file": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": f"{LOG_ROOT_PATH}/{LOG_FILE_MAIN}",
            "maxBytes": 5_000_000,       # 5 MB per file
            "backupCount": 3,            # keep 3 old logs
            "encoding": "utf-8",
            "level": "DEBUG",
            "formatter": "verbose",
        },
        "reports_file": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": f"{LOG_ROOT_PATH}/{LOG_FILE_REPORTS}",
            "maxBytes": 10_000_000,      # 10 MB per file for detailed reports
            "backupCount": 5,            # keep 5 old report logs
            "encoding": "utf-8",
            "level": "INFO",
            "formatter": "verbose",
        }
    },

    # Root logger (default)
    "root": {
        "level": "INFO",
        "handlers": ["file"],
    },

    # Custom / package loggers
    "loggers": {
        "cli": {
            "level": "DEBUG",
            "handlers": [],
            "propagate": True,
        },
        "precheck": {
            "level": "INFO",
            "handlers": [],
            "propagate": True,
        },
        "validation_reports": {
            "level": "INFO",
            "handlers": ["reports_file"],
            "propagate": False,  # Don't propagate to avoid duplicate logging
        },
    },
}


def _ensure_logging_configured():
    """Ensure logging is configured exactly once with proper error handling."""
    global _logging_configured, LOG_ROOT_PATH
    if not _logging_configured:
        try:
            os.makedirs(LOG_ROOT_PATH, exist_ok=True)
        except PermissionError as e:
            print(f"Warning: Cannot create log directory {LOG_ROOT_PATH}: {e}")
            # Fallback to current directory
            LOG_ROOT_PATH = str(Path.cwd() / "check_logs")
            try:
                os.makedirs(LOG_ROOT_PATH, exist_ok=True)
            except Exception as fallback_e:
                print(f"Warning: Fallback log directory creation failed: {fallback_e}")
                LOG_ROOT_PATH = str(Path.cwd())  # Use current directory as last resort
        except Exception as e:
            print(f"Warning: Unexpected error creating log directory: {e}")
            LOG_ROOT_PATH = str(Path.cwd())

        try:
            logging.config.dictConfig(LOGGING_CONFIG_DICT)
            _logging_configured = True
        except Exception as e:
            print(f"Warning: Failed to configure logging: {e}")
            # Fall back to basic logging
            logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
            _logging_configured = True


def setup_logger():
    """
    Sets up the logger based on calling module.
    """
    _ensure_logging_configured()

    caller_frame = sys._getframe(1)
    caller_file = os.path.basename(caller_frame.f_code.co_filename)
    caller_module_name, _ = os.path.splitext(caller_file)

    logger = logging.getLogger(caller_module_name)
    logger.info("Logging initiated for %s module.", caller_module_name)

    return logger


def get_check_logger(check_id: str):
    """
    Get a logger for a specific validation check.
    """
    _ensure_logging_configured()
    return logging.getLogger(f"validation_checks.{check_id}")


def get_reports_logger():
    """
    Get the dedicated reports logger that writes to validation_reports.log
    """
    _ensure_logging_configured()
    return logging.getLogger("validation_reports")
