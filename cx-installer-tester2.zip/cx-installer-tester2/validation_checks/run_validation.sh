#!/bin/bash
# Validation Checks Wrapper Script
# Provides a user-friendly interface for running validation checks

set -euo pipefail  # Exit on error, undefined vars, pipe failures

# Script configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VALIDATION_RUNNER="$SCRIPT_DIR/run_validation_checks.py"
DEFAULT_POLICY="$SCRIPT_DIR/validation_policies/default.yaml"
LOG_DIR="$SCRIPT_DIR/check_logs"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }
print_header() { echo -e "${CYAN}$1${NC}"; }

# Function to show usage
show_usage() {
    cat << EOF
Usage: $0 [OPTIONS] COMMAND

COMMANDS:
    pre <spec_file>              Run pre-deployment validation checks
    post <spec_file>             Run post-deployment validation checks
    list                         List all available validation checks
    config                       Show current validation configuration
    logs                         Show recent validation logs
    help                         Show this help message

OPTIONS:
    -p, --policy <file>          Use custom policy file (default: validation_policies/default.yaml)
    -v, --verbose                Enable verbose output
    -q, --quiet                  Suppress non-error output
    -f, --follow-logs            Follow validation logs in real-time
    --jira-mode <mode>          Set JIRA ticket mode: individual|consolidated
    --no-jira                   Disable JIRA ticket creation
    --dry-run                   Show what would be run without executing
    --update-config             Update validation configuration before running
    --validate-config           Validate configuration file before running

EXAMPLES:
    $0 pre /path/to/deployment.yaml                    # Run pre-deployment checks
    $0 post /path/to/deployment.yaml -v               # Run post-deployment checks (verbose)
    $0 pre spec.yaml --jira-mode consolidated         # Use consolidated JIRA tickets
    $0 list                                            # List all available checks
    $0 config                                          # Show current configuration
    $0 logs --follow-logs                              # Follow logs in real-time

CONFIGURATION:
    Policy file: $DEFAULT_POLICY
    Logs directory: $LOG_DIR
    JIRA config: ../integrations/jira_config.env

EOF
}

# Function to check prerequisites
check_prerequisites() {
    local missing_tools=()

    # Check Python
    if ! command -v python3 >/dev/null 2>&1; then
        missing_tools+=("python3")
    fi

    # Check required Python script
    if [[ ! -f "$VALIDATION_RUNNER" ]]; then
        print_error "Validation runner not found: $VALIDATION_RUNNER"
        exit 1
    fi

    # Check if we can import required modules
    if ! python3 -c "import yaml" >/dev/null 2>&1; then
        missing_tools+=("python3-yaml (pip install pyyaml)")
    fi

    if [[ ${#missing_tools[@]} -gt 0 ]]; then
        print_error "Missing required tools: ${missing_tools[*]}"
        exit 1
    fi
}

# Function to setup environment
setup_environment() {
    # Create logs directory if it doesn't exist
    mkdir -p "$LOG_DIR"

    # Set default JIRA mode if not specified
    export JIRA_TICKET_MODE="${JIRA_TICKET_MODE:-individual}"
}

# Function to validate spec file
validate_spec_file() {
    local spec_file="$1"
    
    if [[ ! -f "$spec_file" ]]; then
        print_error "Specification file not found: $spec_file"
        exit 1
    fi

    # Check if it's valid YAML
    if ! python3 -c "import yaml; yaml.safe_load(open('$spec_file'))" >/dev/null 2>&1; then
        print_error "Invalid YAML format in specification file: $spec_file"
        exit 1
    fi

    print_info "Specification file validated: $spec_file"
}

# Function to validate policy file
validate_policy_file() {
    local policy_file="$1"
    
    if [[ ! -f "$policy_file" ]]; then
        print_error "Policy file not found: $policy_file"
        exit 1
    fi

    # Validate policy configuration
    if ! python3 "$SCRIPT_DIR/generate_validation_config.py" --validate -o "$policy_file" >/dev/null 2>&1; then
        print_error "Invalid policy configuration: $policy_file"
        print_info "Run: make validate-validation-config to see details"
        exit 1
    fi

    print_info "Policy file validated: $policy_file"
}

# Function to run validation checks
run_validation() {
    local stage="$1"
    local spec_file="$2"
    local policy_file="$3"
    local verbose="$4"
    local dry_run="$5"

    print_header "==============================================="
    print_header "  CX Platform Installer Validation Checks"
    print_header "==============================================="
    print_info "Stage: $stage"
    print_info "Spec: $spec_file"
    print_info "Policy: $policy_file"
    print_info "JIRA Mode: ${JIRA_TICKET_MODE:-individual}"
    print_header "==============================================="

    if [[ "$dry_run" == "true" ]]; then
        print_warning "DRY RUN MODE - No checks will be executed"
        print_info "Would run: python3 $VALIDATION_RUNNER -t $stage -s $spec_file -p $policy_file"
        return 0
    fi

    local cmd_args=("-t" "$stage" "-s" "$spec_file" "-p" "$policy_file")
    
    if [[ "$verbose" == "true" ]]; then
        # Enable debug logging for verbose mode
        export PYTHONPATH="$SCRIPT_DIR:${PYTHONPATH:-}"
        print_info "Running in verbose mode..."
    fi

    print_info "Starting validation checks..."
    echo

    # Run the actual validation
    local start_time=$(date +%s)
    local exit_code=0
    
    if python3 "$VALIDATION_RUNNER" "${cmd_args[@]}"; then
        local end_time=$(date +%s)
        local duration=$((end_time - start_time))
        echo
        print_success "Validation completed successfully in ${duration}s"
        
        # Show log file locations
        print_info "Detailed logs available at:"
        print_info "  - General: $LOG_DIR/validation_checks.log"
        print_info "  - Reports: $LOG_DIR/validation_reports.log"
    else
        exit_code=$?
        local end_time=$(date +%s)
        local duration=$((end_time - start_time))
        echo
        print_error "Validation failed in ${duration}s (exit code: $exit_code)"
        
        # Show recent errors from logs
        print_info "Recent errors:"
        if [[ -f "$LOG_DIR/validation_checks.log" ]]; then
            tail -n 5 "$LOG_DIR/validation_checks.log" | while read -r line; do
                print_error "  $line"
            done
        fi
    fi

    return $exit_code
}

# Function to list validation checks
list_checks() {
    print_header "Available Validation Checks"
    print_header "=========================="
    python3 "$SCRIPT_DIR/generate_validation_config.py" --list
}

# Function to show configuration
show_config() {
    print_header "Current Validation Configuration"
    print_header "==============================="
    
    if [[ -f "$DEFAULT_POLICY" ]]; then
        print_info "Policy file: $DEFAULT_POLICY"
        echo
        
        # Show validation control settings
        python3 -c "
import yaml
config = yaml.safe_load(open('$DEFAULT_POLICY'))
validation_control = config.get('validation_control', {})
print('Global enabled:', validation_control.get('global_enabled', True))
print()
print('App Controls:')
for app, settings in validation_control.get('app_controls', {}).items():
    print(f'  {app}: enabled={settings.get(\"enabled\", True)}')
    stage_controls = settings.get('stage_controls', {})
    for stage, stage_config in stage_controls.items():
        if isinstance(stage_config, bool):
            print(f'    {stage}: {stage_config}')
        else:
            enabled = stage_config.get('enabled', True) if isinstance(stage_config, dict) else stage_config
            print(f'    {stage}: enabled={enabled}')
"
    else
        print_warning "Policy file not found: $DEFAULT_POLICY"
    fi

    # Show JIRA configuration
    echo
    print_info "JIRA Configuration:"
    local jira_config="../integrations/jira_config.env"
    if [[ -f "$jira_config" ]]; then
        print_info "  Mode: ${JIRA_TICKET_MODE:-individual}"
        print_info "  Config file: $jira_config"
    else
        print_warning "  JIRA config not found: $jira_config"
    fi
}

# Function to show logs
show_logs() {
    local follow="$1"
    
    print_header "Validation Logs"
    print_header "=============="
    
    if [[ "$follow" == "true" ]]; then
        print_info "Following validation logs (Press Ctrl+C to stop)..."
        echo
        if [[ -f "$LOG_DIR/validation_reports.log" ]]; then
            tail -f "$LOG_DIR/validation_reports.log"
        else
            print_warning "No logs found yet. Run some validations first."
        fi
    else
        # Show recent logs
        print_info "Recent validation reports:"
        if [[ -f "$LOG_DIR/validation_reports.log" ]]; then
            tail -n 20 "$LOG_DIR/validation_reports.log"
        else
            print_warning "No logs found yet. Run some validations first."
        fi
    fi
}

# Function to update configuration
update_config() {
    print_info "Updating validation configuration..."
    if (cd "$SCRIPT_DIR" && make update-validation-config); then
        print_success "Configuration updated successfully"
    else
        print_error "Failed to update configuration"
        return 1
    fi
}

# Main script logic
main() {
    # Parse command line arguments
    local stage=""
    local spec_file=""
    local policy_file="$DEFAULT_POLICY"
    local command=""
    local verbose="false"
    local quiet="false"
    local follow_logs="false"
    local dry_run="false"
    local update_config_flag="false"
    local validate_config_flag="false"
    local no_jira="false"

    while [[ $# -gt 0 ]]; do
        case $1 in
            pre|post)
                command="validate"
                stage="$1"
                shift
                if [[ $# -gt 0 && ! "$1" =~ ^- ]]; then
                    spec_file="$1"
                    shift
                else
                    print_error "Specification file required for $stage command"
                    show_usage
                    exit 1
                fi
                ;;
            list)
                command="list"
                shift
                ;;
            config)
                command="config"
                shift
                ;;
            logs)
                command="logs"
                shift
                ;;
            help|--help|-h)
                show_usage
                exit 0
                ;;
            -p|--policy)
                policy_file="$2"
                shift 2
                ;;
            -v|--verbose)
                verbose="true"
                shift
                ;;
            -q|--quiet)
                quiet="true"
                shift
                ;;
            -f|--follow-logs)
                follow_logs="true"
                shift
                ;;
            --jira-mode)
                export JIRA_TICKET_MODE="$2"
                shift 2
                ;;
            --no-jira)
                no_jira="true"
                shift
                ;;
            --dry-run)
                dry_run="true"
                shift
                ;;
            --update-config)
                update_config_flag="true"
                shift
                ;;
            --validate-config)
                validate_config_flag="true"
                shift
                ;;
            *)
                print_error "Unknown option: $1"
                show_usage
                exit 1
                ;;
        esac
    done

    # Handle quiet mode
    if [[ "$quiet" == "true" ]]; then
        exec 1>/dev/null  # Suppress stdout
    fi

    # Check prerequisites
    check_prerequisites

    # Setup environment
    setup_environment

    # Handle no-jira flag
    if [[ "$no_jira" == "true" ]]; then
        export ENABLE_JIRA_PRE="false"
        export ENABLE_JIRA_POST="false"
        print_info "JIRA ticket creation disabled"
    fi

    # Update config if requested
    if [[ "$update_config_flag" == "true" ]]; then
        update_config
    fi

    # Validate config if requested
    if [[ "$validate_config_flag" == "true" ]]; then
        validate_policy_file "$policy_file"
        print_success "Policy configuration is valid"
    fi

    # Execute command
    case "$command" in
        validate)
            validate_spec_file "$spec_file"
            validate_policy_file "$policy_file"
            run_validation "$stage" "$spec_file" "$policy_file" "$verbose" "$dry_run"
            ;;
        list)
            list_checks
            ;;
        config)
            show_config
            ;;
        logs)
            show_logs "$follow_logs"
            ;;
        "")
            print_error "No command specified"
            show_usage
            exit 1
            ;;
        *)
            print_error "Unknown command: $command"
            show_usage
            exit 1
            ;;
    esac
}

# Run main function with all arguments
main "$@"
