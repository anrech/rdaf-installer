# Core check registration and result classes for validation_checks
from typing import Callable, Dict, List, Optional


class Result:
    def __init__(self, id: str, success: bool, message: str, output: Optional[str] = None):
        self.id = id
        self.success = success
        self.message = message
        self.output = output

    def __repr__(self):
        return f"Result(id={self.id}, success={self.success}, message={self.message}, output={self.output})"

# Registry for all checks: { (app, stage): [funcs] }
CHECK_REGISTRY: Dict[str, Dict[str, List[Callable]]] = {}

def check_for(app: str, stage: str):
    """Decorator to register a check for an app and stage ('pre', 'post', or '*')."""
    def decorator(func):
        apps = [app] if app != "*" else ["*"]
        stages = [stage] if stage != "*" else ["pre", "post"]
        for a in apps:
            if a not in CHECK_REGISTRY:
                CHECK_REGISTRY[a] = {"pre": [], "post": []}
            for s in stages:
                if s not in CHECK_REGISTRY[a]:
                    CHECK_REGISTRY[a][s] = []
                CHECK_REGISTRY[a][s].append(func)
        return func
    return decorator
