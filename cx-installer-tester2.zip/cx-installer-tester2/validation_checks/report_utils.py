#!/usr/bin/env python3
"""
Validation checks reporting utilities for console and log file output.
"""

import datetime
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Set


class ValidationReporter:
    """Handles comprehensive reporting for validation check runs."""

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.start_time = datetime.datetime.now()
        self.total_checks = 0
        self.passed_checks = 0
        self.failed_checks = 0
        self.skipped_checks = 0
        self.critical_failures = 0
        self.non_critical_failures = 0

    def log_run_start(self, stage: str, apps: Set[str], spec_file: str, policy_file: str):
        """Log the start of a validation run with comprehensive details."""
        separator = "=" * 80
        self.logger.info(separator)
        self.logger.info("VALIDATION CHECKS RUN STARTED")
        self.logger.info(separator)
        self.logger.info(f"Start Time: {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        self.logger.info(f"Stage: {stage}")
        self.logger.info(f"Apps: {', '.join(sorted(apps))}")
        self.logger.info(f"Specification File: {spec_file}")
        self.logger.info(f"Policy File: {policy_file}")
        self.logger.info(separator)

    def log_policy_details(self, critical: Set[str], non_critical: Set[str],
                          default_critical: bool, validation_control: Dict):
        """Log detailed policy configuration."""
        self.logger.info("POLICY CONFIGURATION:")
        self.logger.info(f"  Default Critical Setting: {default_critical}")
        self.logger.info(f"  Explicitly Critical Checks: {len(critical)}")
        if critical:
            for check in sorted(critical):
                self.logger.info(f"    - {check}")

        self.logger.info(f"  Explicitly Non-Critical Checks: {len(non_critical)}")
        if non_critical:
            for check in sorted(non_critical):
                self.logger.info(f"    - {check}")

        # Log validation control configuration
        if validation_control:
            global_enabled = validation_control.get('global_enabled', True)
            self.logger.info(f"  Global Validation Enabled: {global_enabled}")

            app_controls = validation_control.get('app_controls', {})
            if app_controls:
                self.logger.info("  App-Specific Controls:")
                for app, controls in app_controls.items():
                    app_enabled = controls.get('enabled', True)
                    self.logger.info(f"    {app}: enabled={app_enabled}")

                    stage_controls = controls.get('stage_controls', {})
                    if stage_controls:
                        for stage, stage_enabled in stage_controls.items():
                            self.logger.info(f"      {stage}: enabled={stage_enabled}")

                    check_controls = controls.get('check_controls', {})
                    if check_controls:
                        disabled_checks = [k for k, v in check_controls.items() if not v]
                        if disabled_checks:
                            self.logger.info(f"      Disabled checks: {', '.join(disabled_checks)}")

        self.logger.info("-" * 80)

    def log_check_discovery(self, relevant_checks: List[tuple], skipped_checks: List[str]):
        """Log check discovery results."""
        self.total_checks = len(relevant_checks) + len(skipped_checks)
        self.skipped_checks = len(skipped_checks)

        self.logger.info("CHECK DISCOVERY RESULTS:")
        self.logger.info(f"  Total Checks Found: {self.total_checks}")
        self.logger.info(f"  Checks to Execute: {len(relevant_checks)}")
        self.logger.info(f"  Checks Skipped: {len(skipped_checks)}")

        if relevant_checks:
            self.logger.info("  Checks to Execute:")
            for check_id, _ in relevant_checks:
                self.logger.info(f"    - {check_id}")

        if skipped_checks:
            self.logger.info("  Skipped Checks:")
            for check_id in skipped_checks:
                self.logger.info(f"    - {check_id}")

        self.logger.info("-" * 80)

    def log_check_result(self, check_id: str, result: Any, is_critical: bool,
                        execution_time: Optional[float] = None):
        """Log detailed result for a single check."""
        if result.success:
            self.passed_checks += 1
            status = "PASSED"
            level = logging.INFO
        else:
            self.failed_checks += 1
            if is_critical:
                self.critical_failures += 1
                status = "FAILED (CRITICAL)"
                level = logging.ERROR
            else:
                self.non_critical_failures += 1
                status = "FAILED (NON-CRITICAL)"
                level = logging.WARNING

        # Log the main result
        time_info = f" [{execution_time:.2f}s]" if execution_time else ""
        self.logger.log(level, f"CHECK RESULT: {check_id} - {status}{time_info}")

        # Log detailed information
        if hasattr(result, 'message') and result.message:
            self.logger.log(level, f"  Message: {result.message}")

        if hasattr(result, 'requirement') and result.requirement:
            self.logger.log(level, f"  Requirement: {result.requirement}")

        if hasattr(result, 'observed') and result.observed:
            self.logger.log(level, f"  Observed: {result.observed}")

        if hasattr(result, 'remediation') and result.remediation:
            self.logger.log(level, f"  Remediation: {result.remediation}")

        if hasattr(result, 'host') and result.host:
            self.logger.log(level, f"  Host: {result.host}")

        if hasattr(result, 'output') and result.output:
            self.logger.log(level, f"  Command Output:")
            for line in str(result.output).splitlines():
                self.logger.log(level, f"    {line}")

        if hasattr(result, 'extra') and result.extra:
            self.logger.log(level, f"  Additional Info: {result.extra}")

    def log_jira_activity(self, activity_type: str, details: str):
        """Log JIRA ticket creation activities."""
        self.logger.info(f"JIRA ACTIVITY: {activity_type}")
        self.logger.info(f"  {details}")

    def log_run_summary(self, success: bool, failures: Optional[List[Dict]] = None):
        """Log comprehensive run summary."""
        end_time = datetime.datetime.now()
        duration = end_time - self.start_time

        separator = "=" * 80
        self.logger.info(separator)
        self.logger.info("VALIDATION CHECKS RUN SUMMARY")
        self.logger.info(separator)
        self.logger.info(f"End Time: {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
        self.logger.info(f"Total Duration: {duration}")
        self.logger.info(f"Overall Result: {'SUCCESS' if success else 'FAILURE'}")
        self.logger.info("")

        self.logger.info("STATISTICS:")
        self.logger.info(f"  Total Checks: {self.total_checks}")
        self.logger.info(f"  Executed: {self.passed_checks + self.failed_checks}")
        self.logger.info(f"  Skipped: {self.skipped_checks}")
        self.logger.info(f"  Passed: {self.passed_checks}")
        self.logger.info(f"  Failed: {self.failed_checks}")
        self.logger.info(f"    - Critical Failures: {self.critical_failures}")
        self.logger.info(f"    - Non-Critical Failures: {self.non_critical_failures}")

        if failures:
            self.logger.info("")
            self.logger.info("FAILURE DETAILS:")
            for i, failure in enumerate(failures, 1):
                self.logger.error(f"  Failure {i}: {failure['check_id']}")
                self.logger.error(f"    Message: {failure['message']}")
                if failure.get('host'):
                    self.logger.error(f"    Host: {failure['host']}")

        self.logger.info(separator)
        self.logger.info("VALIDATION CHECKS RUN COMPLETED")
        self.logger.info(separator)

        # Add performance metrics if we have timing data
        if self.passed_checks + self.failed_checks > 0:
            avg_time = duration.total_seconds() / (self.passed_checks + self.failed_checks)
            self.logger.info(f"Average check execution time: {avg_time:.2f} seconds")

    def get_summary_stats(self) -> Dict[str, Any]:
        """Get summary statistics for the run."""
        return {
            'total_checks': self.total_checks,
            'executed': self.passed_checks + self.failed_checks,
            'skipped': self.skipped_checks,
            'passed': self.passed_checks,
            'failed': self.failed_checks,
            'critical_failures': self.critical_failures,
            'non_critical_failures': self.non_critical_failures,
            'duration': datetime.datetime.now() - self.start_time
        }
