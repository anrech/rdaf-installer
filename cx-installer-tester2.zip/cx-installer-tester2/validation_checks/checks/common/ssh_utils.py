# Common SSH helper for all validation checks
import subprocess


def run_ssh_command(host: str, user: str, pwd: str, command: str, timeout: int = 10, logger=None):
    """
    Run a command on a remote host via SSH with a timeout.
    Returns (stdout, stderr, returncode)
    """
    cmd = f"timeout {timeout}s sshpass -p '{pwd}' ssh -o ConnectTimeout=10 -o StrictHostKeyChecking=no {user}@{host} '{command}'"
    if logger:
        logger.info(f"Running SSH command on {host}: {command}")
    res = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True)
    if logger:
        logger.info(f"SSH command result on {host}: rc={res.returncode}, stdout={res.stdout.strip()}, stderr={res.stderr.strip()}")
    return res.stdout.strip(), res.stderr.strip(), res.returncode
