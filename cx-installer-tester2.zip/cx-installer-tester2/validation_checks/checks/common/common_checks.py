import socket

from validation_checks.check_core import Result, check_for


@check_for("*", stage="pre")
def check_ntp(spec):
    # Dummy: pass if ntp_enabled in spec
    if spec.get("ntp_enabled", True):
        return Result("common.pre.check_ntp", True, "NTP is enabled.")
    else:
        return Result("common.pre.check_ntp", False, "NTP is not enabled.")

@check_for("*", stage="pre")
def check_dns(spec):
    hosts = []
    for plat in spec.get("platforms", []):
        hosts.extend(plat.get("hosts", []))
    failed = []
    for host in hosts:
        try:
            socket.gethostbyaddr(host)
        except Exception:
            failed.append(host)
    if not failed:
        return Result("common.pre.check_dns", True, "DNS resolution succeeded for all hosts.")
    else:
        return Result("common.pre.check_dns", False, "DNS failed for: " + ", ".join(failed))

@check_for("*", stage="pre")
def check_proxy(spec):
    if spec.get("proxy", None):
        return Result("common.pre.check_proxy", True, "Proxy is configured.")
    else:
        return Result("common.pre.check_proxy", False, "Proxy is not configured.")
