from typing import Any
import json
import re
import os
import base64
from collections import defaultdict

import validation_checks.check_log_utils as check_log_utils

from validation_checks.check_core import Result, check_for
from validation_checks.checks.common.ssh_utils import run_ssh_command
import subprocess

logger = check_log_utils.setup_logger()

APP_ID, STAGE = "rdaf", "post"

def _extract_hosts_creds(spec):
    """Extract RDAF hosts and credentials from spec file."""
    for plat in spec.get("platforms", []):
        if plat.get("type") in ["VanillaVM"]:  # Support both types
            creds = plat.get("creds", {})
            hosts = plat.get("hosts", [])
            user = creds.get("user")
            pwd = creds.get("password")
            
            # Extract UI IP from RDAF app config or platform config or use first host
            ui_ip = plat.get("ui_ip")
            if not ui_ip:
                # Look for rdaf_url in apps
                for app in plat.get("apps", []):
                    if app.get("type") == "RDAF" or app.get("name") == "RDAF":
                        rdaf_url = app.get("rdaf_url", "")
                        if rdaf_url:
                            # Extract IP from URL like "https://172.24.14.2"
                            import re
                            match = re.search(r'https?://([^:/]+)', rdaf_url)
                            if match:
                                ui_ip = match.group(1)
                                break
            
            # Fallback to first host if no UI IP found
            if not ui_ip and hosts:
                ui_ip = hosts[0]
                
            return hosts, user, pwd, ui_ip
    return [], None, None, None

def _extract_rdaf_config(spec):
    """Extract RDAF-specific configuration from spec."""
    for plat in spec.get("platforms", []):
        if plat.get("type") in ["RDAF", "VanillaVM"]:
            for app in plat.get("apps", []):
                if app.get("type") == "RDAF" or app.get("name") == "RDAF":
                    return {
                        # UI credentials - use download server credentials as fallback for UI login
                        "ui_username": app.get("rdaf_ui_username", app.get("rdaf_download_server_username", "admin@cfx.com")),
                        "ui_password": app.get("rdaf_ui_password", app.get("rdaf_download_server_password", "Cisco@1234")),
                        # Download server credentials
                        "download_username": app.get("rdaf_download_server_username", app.get("username", "admin@cfx.com")),
                        "download_password": app.get("rdaf_download_server_password", app.get("password")),
                        "geo_ha_enabled": app.get("geo_ha_enabled", False),
                        "site_b_host": app.get("site_b_host")
                    }
    return {
        "ui_username": "admin@cfx.com", 
        "ui_password": "Cisco@1234",
        "download_username": "admin@cfx.com", 
        "download_password": None, 
        "geo_ha_enabled": False, 
        "site_b_host": None
    }

def _check_ssh_prereqs(hosts, user, pwd, check_name):
    """Check SSH prerequisites."""
    if not hosts or not user or not pwd:
        reason = (
            f"Requirement: hosts, user, and password must be defined in the spec.\n"
            f"Observed: hosts={hosts}, user={user}, password={'set' if pwd else 'not set'}\n"
            f"Remediation: Ensure all required fields are present in the spec."
        )
        return Result(f"{APP_ID}.{STAGE}.{check_name}", False, reason, output=None)
    return None

def _run_local_command(cmd, suppress_fail_msg=False):
    """Run local command (equivalent to original run_cmd)."""
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0 and not suppress_fail_msg:
            logger.warning(f"Local command failed: {cmd}")
        return result.stdout.strip() if result.returncode == 0 else ""
    except Exception as e:
        if not suppress_fail_msg:
            logger.error(f"Local command error: {e}")
        return ""

def _parse_status_output(output):
    """Parse RDAF status output into structured format."""
    lines = output.strip().splitlines()
    services = defaultdict(lambda: {"up": set(), "down": set(), "tags": set()})
    all_nodes = set()

    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line.startswith("|"):
            i += 1
            continue

        parts = [p.strip() for p in line.strip("|").split("|")]
        if len(parts) < 4:
            i += 1
            continue

        service_name = parts[0]
        ip = parts[1]
        status = parts[2]
        tag = parts[4] if len(parts) > 4 else ""

        # Skip headers or invalid rows
        if service_name.lower() in ("name", "") or ip.lower() == "host" or status.lower() == "status":
            i += 1
            continue

        # Save original values for possible continuation lines
        full_service_name = service_name
        full_tag = tag

        # Append continuation lines
        while i + 1 < len(lines):
            next_line = lines[i + 1].strip()
            if not next_line.startswith("|"):
                break
            next_parts = [p.strip() for p in next_line.strip("|").split("|")]

            # If service name is split across lines
            if next_parts[0] and all(not np for np in next_parts[1:]):
                full_service_name += next_parts[0]
                i += 1
                continue

            # If tag is continued on the next line (and possibly wrapped)
            if not next_parts[0] and len(next_parts) >= 5 and next_parts[4]:
                full_tag += next_parts[4]
                i += 1
                continue

            break

        service_name = full_service_name.strip()
        ip = ip.strip()
        status = status.strip().lower()
        tag = full_tag.strip()

        if ip:
            all_nodes.add(ip)

            if status.startswith("up") or status == "active":
                services[service_name]["up"].add(ip)
            else:
                services[service_name]["down"].add(ip)

            if tag:
                services[service_name]["tags"].add(tag)

        i += 1

    nodes = ",".join(sorted(all_nodes))

    services_dict = {
        svc: {
            "tag": ",".join(sorted(ips["tags"])) if ips["tags"] else "",
            "up": ",".join(sorted(ips["up"])),
            "down": ",".join(sorted(ips["down"]))
        }
        for svc, ips in services.items()
    }

    return {
        "nodes": nodes,
        "services": services_dict
    }

def _get_build_version(host, user, pwd, ui_ip, username, password):
    """Get RDAF build version via API using SSH to run curl commands on the UI host itself."""
    logger.info(f"Attempting to get build version from UI IP: {ui_ip} via SSH to UI host directly")
    logger.info(f"Using UI credentials: username='{username}', password='{'*' * len(password) if password else 'None'}'")
    
    # For airgap environments, SSH directly to the UI host and use localhost
    ui_host = ui_ip  # SSH directly to the UI host
    target_url = "127.0.0.1"  # Use localhost since we're running curl on the UI host itself
    
    try:
        # Create JSON payload and encode it with base64 to avoid all shell escaping issues
        json_payload = json.dumps({"user": username, "password": password})
        encoded_payload = base64.b64encode(json_payload.encode()).decode()
        
        # Use base64 encoding to completely avoid shell parsing issues
        # Since we're on the UI host itself, use localhost (127.0.0.1)
        # Use double quotes to properly handle the Content-Type header
        login_cmd = f'echo \'{encoded_payload}\' | base64 -d | curl -k -L -c cookies.txt -X POST -H "Content-Type: application/json" -d @- "https://{target_url}/api/portal/login"'
        
        logger.info(f"Running login command via SSH to UI host (payload base64 encoded): {login_cmd}")
        login_stdout, login_stderr, login_rc = run_ssh_command(ui_host, user, pwd, login_cmd, logger=logger)
        logger.info(f"Login response: stdout={login_stdout}, stderr={login_stderr}, rc={login_rc}")

        if login_rc != 0:
            logger.warning(f"Login command failed with rc={login_rc}, stderr={login_stderr}")
            return ""

        try:
            login_data = json.loads(login_stdout)
            logger.info(f"Login data parsed: {login_data}")
            
            # Check for login error messages
            if login_data.get("serviceError"):
               logger.warning(f"Login failed: {login_data['serviceError']}")
               return ""
            # Check for 'status' and 'reason'
            if login_data.get("status") == "failed":
                reason = login_data.get("reason", "Unknown reason")
                logger.warning(f"Login failed with status 'failed': {reason}")
                return ""
            # Check for authentication status
            if not login_data.get("authenticated", False) and not login_data.get("is_authenticated", False):
                logger.warning(f"Login authentication failed. Response: {login_data}")
                return ""
                
            # Login successful
            logger.info(f"Login successful! Authentication status: authenticated={login_data.get('authenticated')}, is_authenticated={login_data.get('is_authenticated')}")
            
        except json.JSONDecodeError:
           logger.warning(f"Could not parse login response as JSON: {login_stdout}")
           return ""

        # Run version command via SSH - use simple single line command with localhost
        version_cmd = f'curl -k -b cookies.txt "https://{target_url}/api/portal/portal_build_version"'
        logger.info(f"Running version command via SSH to UI host: {version_cmd}")
        version_stdout, version_stderr, version_rc = run_ssh_command(ui_host, user, pwd, version_cmd, logger=logger)
        logger.info(f"Version response: stdout={version_stdout}, stderr={version_stderr}, rc={version_rc}")

        if version_rc != 0:
            logger.warning(f"Version command failed with rc={version_rc}, stderr={version_stderr}")
            return ""

        if not version_stdout:
            logger.warning("No output received for build version.")
            return ""

        try:
            data = json.loads(version_stdout)
            logger.info(f"Version data parsed: {data}")
        except json.JSONDecodeError:
            logger.warning("Failed to parse build version JSON output.")
            return ""

        # Safely handle missing or None data
        if not data or "serviceResult" not in data or data["serviceResult"] is None:
            logger.warning("Login failed or no valid build version data returned from server.")
            return ""

        # Extract build_version safely
        build_version = data["serviceResult"].get("build_version", "")
        logger.info(f"Extracted build version: '{build_version}'")
        return build_version.strip() if build_version else ""
        
    finally:
        # Always clean up cookies via SSH - regardless of success or failure
        logger.info("Cleaning up cookies file...")
        cleanup_stdout, cleanup_stderr, cleanup_rc = run_ssh_command(ui_host, user, pwd, "rm -f cookies.txt", logger=logger)
        if cleanup_rc == 0:
            logger.info("Successfully cleaned up cookies file")
        else:
            logger.warning(f"Failed to clean up cookies file: rc={cleanup_rc}, stderr={cleanup_stderr}")

@check_for(APP_ID, stage=STAGE)
def check_rdaf_services_status(spec: Any) -> Result:
    """Check RDAF services status across all service types."""
    hosts, user, pwd, ui_ip = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_rdaf_services_status")
    if prereq_result:
        return prereq_result

    failed = []
    outputs = []
    all_services_data = {}

    # Check all RDAF service types
    service_types = ["infra", "platform", "app", "worker", "event_gateway", "opensearch_external"]
    
    for service_type in service_types:
        cmd = f"/home/rdauser/.local/bin/rdaf {service_type} status"
        stdout, stderr, rc = run_ssh_command(hosts[0], user, pwd, cmd, logger=logger)
        
        if rc != 0:
            failed.append(f"{service_type}: Command failed - {stderr or 'No error message'}")
            outputs.append(f"{service_type} output:\nstdout: {stdout}\nstderr: {stderr}")
            continue
            
        # Parse the status output
        status_data = _parse_status_output(stdout)
        all_services_data[service_type] = status_data
        
        # Check for any down services
        for svc_name, svc_info in status_data["services"].items():
            if svc_info["down"]:
                failed.append(f"{service_type}.{svc_name}: Services down on {svc_info['down']}")
        
        outputs.append(f"{service_type} output:\n{stdout}")

    if not failed:
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_services_status", True, 
                     "All RDAF services are running properly across all service types.", 
                     output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            "Requirement: All RDAF services must be in 'up' or 'active' state.\n"
            "Observed: The following services are not running properly:\n"
            + "\n".join(failed) +
            "\nTo pass: Ensure all RDAF services are healthy and running."
        )
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_services_status", False, reason, 
                     output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE)
def check_rdaf_build_version(spec: Any) -> Result:
    """Check RDAF build version via UI API."""
    hosts, user, pwd, ui_ip = _extract_hosts_creds(spec)
    rdaf_config = _extract_rdaf_config(spec)
    
    if not ui_ip:
        # Try to extract from rdaf.cfg via SSH
        cfg_stdout, cfg_stderr, cfg_rc = run_ssh_command(hosts[0], user, pwd, "cat /opt/rdaf/rdaf.cfg", logger=logger)
        if cfg_rc == 0 and cfg_stdout:
            match = re.search(r'advertised_external_host\s*=\s*([\d.]+)', cfg_stdout)
            if match:
                ui_ip = match.group(1)
    
    if not ui_ip:
        reason = (
            "Requirement: UI IP must be available for build version check.\n"
            "Observed: No UI IP found in spec or rdaf.cfg\n"
            "Remediation: Ensure ui_ip is specified in the spec or advertised_external_host is set in rdaf.cfg."
        )
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_build_version", False, reason, output=None)

    username = rdaf_config["ui_username"]
    password = rdaf_config["ui_password"]
    
    if not password:
        reason = (
            "Requirement: RDAF UI password must be specified in the spec.\n"
            "Observed: No UI password found in RDAF app configuration\n"
            "Remediation: Ensure rdaf_ui_password or rdaf_download_server_password is specified in the RDAF app section of the spec."
        )
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_build_version", False, reason, output=None)

    build_version = _get_build_version(ui_ip, user, pwd, ui_ip, username, password)
    
    if not build_version:
        reason = (
            "Requirement: RDAF build version must be retrievable via UI API.\n"
            f"Observed: Could not retrieve build version using UI credentials username='{username}', password='{'*' * len(password) if password else 'None'}'\n"
            "To pass: Verify RDAF UI credentials are correct. Check RDAF logs for authentication errors.\n"
            "Note: Using rdaf_download_server_username/password as UI credentials. Add rdaf_ui_username/rdaf_ui_password if different.\n"
            "Common RDAF default credentials: admin/admin, admin@cfx.com/admin, or check your installation documentation."
        )
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_build_version", False, reason, output=None)
    
    return Result(f"{APP_ID}.{STAGE}.check_rdaf_build_version", True, 
                 f"RDAF build version retrieved successfully: {build_version}", 
                 output=f"Build Version: {build_version}")

@check_for(APP_ID, stage=STAGE)
def check_rdaf_system_versions(spec: Any) -> Result:
    """Check RDAF system component versions (OS, CLI, Python)."""
    hosts, user, pwd, ui_ip = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_rdaf_system_versions")
    if prereq_result:
        return prereq_result

    failed = []
    outputs = []
    version_info = {}

    # Check OS version - use multiple fallback methods
    os_commands = [
        "hostnamectl | grep 'Operating System' | cut -d: -f2 | xargs",
        "cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2 | tr -d '\"'",
        "lsb_release -d | cut -d: -f2 | xargs",
        "uname -a"
    ]
    
    os_version_found = False
    for cmd in os_commands:
        stdout, stderr, rc = run_ssh_command(hosts[0], user, pwd, cmd, logger=logger)
        if rc == 0 and stdout.strip():
            version_info["os_version"] = stdout.strip()
            outputs.append(f"OS Version: {stdout.strip()}")
            os_version_found = True
            break
    
    if not os_version_found:
        failed.append("OS version check failed - tried multiple methods")
        outputs.append(f"OS version check failed - all methods failed")

    # Check RDAF CLI version
    cmd = "/home/rdauser/.local/bin/rdaf --version"
    stdout, stderr, rc = run_ssh_command(hosts[0], user, pwd, cmd, logger=logger)
    if rc == 0 and stdout:
        parts = stdout.strip().split(":")
        if len(parts) >= 2:
            version_info["rdaf_cli_version"] = parts[1].strip()
            outputs.append(f"RDAF CLI Version: {parts[1].strip()}")
        else:
            failed.append("Unexpected format in rdaf --version output")
    else:
        failed.append("RDAF CLI version check failed")
        outputs.append(f"RDAF CLI version check output:\nstdout: {stdout}\nstderr: {stderr}")

    # Check Python version
    cmd = "python3 --version"
    stdout, stderr, rc = run_ssh_command(hosts[0], user, pwd, cmd, logger=logger)
    if rc == 0 and stdout:
        match = re.search(r"Python\s+([\d.]+)", stdout)
        if match:
            version_info["python_version"] = match.group(1)
            outputs.append(f"Python Version: {match.group(1)}")
        else:
            failed.append("Could not parse Python version")
    else:
        failed.append("Python version check failed")
        outputs.append(f"Python version check output:\nstdout: {stdout}\nstderr: {stderr}")

    if not failed:
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_system_versions", True, 
                     "All RDAF system component versions retrieved successfully.", 
                     output="\n".join(outputs))
    else:
        reason = (
            "Requirement: All system component versions must be retrievable.\n"
            "Observed: The following version checks failed:\n"
            + "\n".join(failed) +
            "\nTo pass: Ensure all system components are properly installed and accessible."
        )
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_system_versions", False, reason, 
                     output="\n".join(outputs))

@check_for(APP_ID, stage=STAGE)
def check_rdaf_configuration_files(spec: Any) -> Result:
    """Check RDAF configuration files accessibility."""
    hosts, user, pwd, ui_ip = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_rdaf_configuration_files")
    if prereq_result:
        return prereq_result

    failed = []
    outputs = []
    config_files = [
        "/opt/rdaf/rdaf.cfg",
        "/opt/rdaf/config/network_config/geodr_config.json",
        "/etc/keepalived/keepalived.conf"
    ]

    for config_file in config_files:
        cmd = f"cat {config_file}"
        stdout, stderr, rc = run_ssh_command(hosts[0], user, pwd, cmd, logger=logger)
        
        if rc == 0 and stdout:
            outputs.append(f"{config_file}: Accessible (size: {len(stdout)} chars)")
            
            # Extract specific values based on file type
            if "rdaf.cfg" in config_file:
                match = re.search(r'advertised_external_host\s*=\s*([\d.]+)', stdout)
                if match:
                    outputs.append(f"  - advertised_external_host: {match.group(1)}")
                    
            elif "geodr_config.json" in config_file:
                try:
                    config_data = json.loads(stdout)
                    geodr_enabled = config_data.get("geodr_enabled", False)
                    outputs.append(f"  - geodr_enabled: {geodr_enabled}")
                except json.JSONDecodeError:
                    outputs.append(f"  - Warning: Could not parse JSON")
                    
            elif "keepalived.conf" in config_file:
                match = re.search(r"virtual_ipaddress\s*{\s*([\d.]+)/\d+\s*}", stdout, re.M)
                if match:
                    outputs.append(f"  - virtual_ip: {match.group(1)}")
        else:
            # Some files might not exist in all environments, so don't fail for missing optional files
            if "keepalived.conf" in config_file:
                outputs.append(f"{config_file}: Not found (optional)")
            elif "geodr_config.json" in config_file:
                outputs.append(f"{config_file}: Not found (optional - Geo-DR not configured)")
            else:
                failed.append(f"{config_file}: Not accessible")
                outputs.append(f"{config_file} check output:\nstdout: {stdout}\nstderr: {stderr}")

    if not failed:
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_configuration_files", True, 
                     "RDAF configuration files are accessible.", 
                     output="\n".join(outputs))
    else:
        reason = (
            "Requirement: Critical RDAF configuration files must be accessible.\n"
            "Observed: The following files are not accessible:\n"
            + "\n".join(failed) +
            "\nTo pass: Ensure RDAF configuration files are properly created and accessible."
        )
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_configuration_files", False, reason, 
                     output="\n".join(outputs))

@check_for(APP_ID, stage=STAGE)
def check_rdaf_geo_ha_configuration(spec: Any) -> Result:
    """Check RDAF Geo-HA configuration if enabled."""
    hosts, user, pwd, ui_ip = _extract_hosts_creds(spec)
    rdaf_config = _extract_rdaf_config(spec)
    
    # Check if Geo-HA is enabled in spec
    if not rdaf_config.get("geo_ha_enabled", False):
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_geo_ha_configuration", True, 
                     "Geo-HA is not enabled in the spec. Skipping Geo-HA checks.", 
                     output="Geo-HA configuration check skipped.")
    
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_rdaf_geo_ha_configuration")
    if prereq_result:
        return prereq_result

    failed = []
    outputs = []
    
    # Check geodr_config.json
    cmd = "cat /opt/rdaf/config/network_config/geodr_config.json"
    stdout, stderr, rc = run_ssh_command(hosts[0], user, pwd, cmd, logger=logger)
    
    if rc != 0:
        failed.append("geodr_config.json not found or not accessible")
        outputs.append(f"geodr_config.json check output:\nstdout: {stdout}\nstderr: {stderr}")
    else:
        try:
            config_data = json.loads(stdout)
            geodr_enabled = config_data.get("geodr_enabled", False)
            preferred_primary = config_data.get("preferred_primary", False)
            
            if not geodr_enabled:
                failed.append("geodr_enabled is false in configuration file")
            
            outputs.append(f"Geo-DR Configuration:")
            outputs.append(f"  - geodr_enabled: {geodr_enabled}")
            outputs.append(f"  - preferred_primary: {preferred_primary}")
            
        except json.JSONDecodeError:
            failed.append("Could not parse geodr_config.json")
            outputs.append(f"geodr_config.json parsing failed")

    # Check Site B host if specified
    site_b_host = rdaf_config.get("site_b_host")
    if site_b_host:
        cmd = "/home/rdauser/.local/bin/rdaf infra status"
        stdout, stderr, rc = run_ssh_command(site_b_host, user, pwd, cmd, logger=logger)
        
        if rc == 0:
            outputs.append(f"Site B ({site_b_host}) is accessible and RDAF is running")
        else:
            failed.append(f"Site B ({site_b_host}) is not accessible or RDAF is not running")
            outputs.append(f"Site B check output:\nstdout: {stdout}\nstderr: {stderr}")
    else:
        outputs.append("Site B host not specified in spec")

    if not failed:
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_geo_ha_configuration", True, 
                     "RDAF Geo-HA configuration is valid.", 
                     output="\n".join(outputs))
    else:
        reason = (
            "Requirement: RDAF Geo-HA configuration must be properly set up when enabled.\n"
            "Observed: The following Geo-HA configuration issues were found:\n"
            + "\n".join(failed) +
            "\nTo pass: Ensure Geo-HA is properly configured and both sites are accessible."
        )
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_geo_ha_configuration", False, reason, 
                     output="\n".join(outputs))

