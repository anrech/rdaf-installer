"""
RDAF Pre-installation validation checks
Adapted from existing RDAF precheck script to match validation framework
"""

import socket
import re
from typing import Any, Dict, List, Tuple

import validation_checks.check_log_utils as check_log_utils
from validation_checks.check_core import Result, check_for
from validation_checks.checks.common.ssh_utils import run_ssh_command

logger = check_log_utils.setup_logger()

APP_ID, STAGE = "rdaf", "pre"

# Define minimum partition sizes in GB by role (from your original script)
PARTITION_REQUIREMENTS = {
    "infra": {
        "/": 75,
        "/opt": 50,
        "/var/lib/docker": 50,
        "/minio-data": 50,
        "/kafka-logs": 25,
        "/var/mysql": 50,
        "/opensearch": 50,
        "/graphdb": 50,
    },
    "platform": {
        "/": 75,
        "/opt": 50,
        "/var/lib/docker": 50,
    },
    "worker": {
        "/": 75,
        "/opt": 25,
        "/var/lib/docker": 25,
    }
}

def _extract_hosts_creds(spec):
    """Extract RDAF hosts and credentials from spec file."""
    for plat in spec.get("platforms", []):
        if plat.get("type") == "VanillaVM":
            creds = plat.get("creds", {})
            hosts = plat.get("hosts", [])
            user = creds.get("user")
            pwd = creds.get("password")
            return hosts, user, pwd
    return [], None, None

def _extract_rdaf_roles(spec):
    """Extract RDAF node roles from spec."""
    roles = {}
    for plat in spec.get("platforms", []):
        if plat.get("type") == "VanillaVM":
            for app in plat.get("apps", []):
                if app.get("type") == "RDAF":
                    node_roles = app.get("node_roles", {})
                    for role, hosts in node_roles.items():
                        for host in hosts:
                            roles[host] = role.lower()
    return roles

def _check_ssh_prereqs(hosts, user, pwd, check_name):
    """Check SSH prerequisites."""
    if not hosts or not user or not pwd:
        reason = (
            f"Requirement: hosts, user, and password must be defined in the spec.\n"
            f"Observed: hosts={hosts}, user={user}, password={'set' if pwd else 'not set'}\n"
            f"Remediation: Ensure all required fields are present in the spec."
        )
        return Result(f"{APP_ID}.{STAGE}.{check_name}", False, reason, output=None)
    return None

def _check_reachability(host):
    """Check if host is reachable on SSH port."""
    try:
        socket.setdefaulttimeout(3)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, 22))
        return True
    except Exception:
        return False

def _check_partitions(host, user, pwd, role):
    """Check partition requirements for specific RDAF role (adapted from your script)."""
    required_partitions = PARTITION_REQUIREMENTS.get(role)
    if not required_partitions:
        return True, f"No partition requirements defined for role '{role}'"

    # Get disk usage in GB for all mounted filesystems
    cmd = "df -BG --output=target,size | tail -n +2"
    stdout, stderr, rc = run_ssh_command(host, user, pwd, cmd, logger=logger)
    
    if rc != 0:
        return False, f"Failed to get partition info: {stderr}"

    # Parse output into dict {mount_point: available_size_in_GB}
    available = {}
    for line in stdout.splitlines():
        parts = line.split()
        if len(parts) != 2:
            continue
        mount_point, avail_str = parts
        if avail_str.endswith("G"):
            try:
                available[mount_point] = int(avail_str[:-1])
            except:
                pass

    # Check each required partition
    failures = []
    successes = []
    for partition, min_size in required_partitions.items():
        avail = available.get(partition)
        if avail is None:
            failures.append(f"Partition {partition}: NOT MOUNTED or NOT FOUND")
        elif avail < min_size:
            failures.append(f"Partition {partition}: {avail}GB available, LESS than required {min_size}GB")
        else:
            successes.append(f"Partition {partition}: OK ({avail}GB available)")

    if failures:
        result_msg = "Partition check failures:\n" + "\n".join(failures)
        if successes:
            result_msg += "\nPassed partitions:\n" + "\n".join(successes)
        return False, result_msg
    else:
        return True, "All partition requirements met:\n" + "\n".join(successes)

@check_for(APP_ID, stage=STAGE)
def check_network_reachability(spec: Any) -> Result:
    """Check network reachability to all RDAF hosts."""
    hosts, user, pwd = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_network_reachability")
    if prereq_result:
        return prereq_result

    failed = []
    outputs = []
    
    for host in hosts:
        if _check_reachability(host):
            outputs.append(f"{host}: Reachable on SSH port 22")
        else:
            failed.append(f"{host}: NOT reachable on SSH port 22")
            outputs.append(f"{host}: Connection failed (timeout or port closed)")

    if not failed:
        return Result(f"{APP_ID}.{STAGE}.check_network_reachability", True, 
                     "All RDAF hosts are reachable on SSH port.", 
                     output="\n".join(outputs))
    else:
        reason = (
            "Requirement: All RDAF hosts must be reachable on SSH port 22.\n"
            "Observed: The following hosts are not reachable:\n"
            + "\n".join(failed) +
            "\nTo pass: Ensure network connectivity and SSH service is running on all hosts."
        )
        return Result(f"{APP_ID}.{STAGE}.check_network_reachability", False, reason, 
                     output="\n".join(outputs))

@check_for(APP_ID, stage=STAGE)
def check_rdaf_partition_requirements(spec: Any) -> Result:
    """Check RDAF-specific partition requirements by role."""
    hosts, user, pwd = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_rdaf_partition_requirements")
    if prereq_result:
        return prereq_result

    roles = _extract_rdaf_roles(spec)
    failed = []
    outputs = []
    
    for host in hosts:
        role = roles.get(host, "worker")  # Default to worker if role not specified
        success, message = _check_partitions(host, user, pwd, role)
        
        outputs.append(f"{host} (role: {role}):\n{message}")
        
        if not success:
            failed.append(f"{host} (role: {role}): Partition requirements not met")

    if not failed:
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_partition_requirements", True, 
                     "All RDAF partition requirements are met.", 
                     output="\n\n".join(outputs))
    else:
        reason = (
            "Requirement: All RDAF hosts must meet role-specific partition requirements.\n"
            "Observed: The following hosts do not meet requirements:\n"
            + "\n".join(failed) +
            "\nTo pass: Ensure adequate disk space is allocated to required partitions."
        )
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_partition_requirements", False, reason, 
                     output="\n\n".join(outputs))

@check_for(APP_ID, stage=STAGE)
def check_rdaf_system_requirements(spec: Any) -> Result:
    """Check basic system requirements (OS, Python, resources)."""
    hosts, user, pwd = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_rdaf_system_requirements")
    if prereq_result:
        return prereq_result

    failed = []
    outputs = []
    
    for host in hosts:
        host_failures = []
        host_outputs = []
        
        # Check OS version
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "cat /etc/os-release | grep PRETTY_NAME", 
                                           logger=logger)
        if rc == 0 and stdout:
            host_outputs.append(f"OS: {stdout}")
        else:
            host_failures.append("OS version check failed")
            host_outputs.append(f"OS: FAILED - {stderr}")

        # Check Python version
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "python3 --version || python --version", 
                                           logger=logger)
        if rc == 0 and stdout:
            host_outputs.append(f"Python: {stdout}")
        else:
            host_failures.append("Python not available")
            host_outputs.append(f"Python: FAILED - {stderr}")

        # Check CPU cores
        stdout, stderr, rc = run_ssh_command(host, user, pwd, "nproc", logger=logger)
        if rc == 0 and stdout:
            try:
                cores = int(stdout.strip())
                if cores < 4:  # Minimum 4 cores for RDAF
                    host_failures.append(f"Insufficient CPU cores: {cores} (minimum 4)")
                host_outputs.append(f"CPU cores: {cores}")
            except:
                host_failures.append("Could not determine CPU count")
                host_outputs.append(f"CPU cores: FAILED - {stdout}")
        else:
            host_failures.append("CPU check failed")
            host_outputs.append(f"CPU cores: FAILED - {stderr}")

        # Check memory
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "free -m | grep Mem | awk '{print $2}'", 
                                           logger=logger)
        if rc == 0 and stdout:
            try:
                mem_mb = int(stdout.strip())
                mem_gb = mem_mb / 1024
                if mem_gb < 8:  # Minimum 8GB for RDAF
                    host_failures.append(f"Insufficient memory: {mem_gb:.1f}GB (minimum 8GB)")
                host_outputs.append(f"Memory: {mem_gb:.1f}GB")
            except:
                host_failures.append("Could not determine memory size")
                host_outputs.append(f"Memory: FAILED - {stdout}")
        else:
            host_failures.append("Memory check failed")
            host_outputs.append(f"Memory: FAILED - {stderr}")

        # Check time synchronization
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "timedatectl status | grep 'System clock synchronized'", 
                                           logger=logger)
        if rc == 0 and "yes" in stdout.lower():
            host_outputs.append("Time sync: YES")
        else:
            host_failures.append("Time synchronization not enabled")
            host_outputs.append("Time sync: NO")

        outputs.append(f"{host}:\n  " + "\n  ".join(host_outputs))
        
        if host_failures:
            failed.extend([f"{host}: {failure}" for failure in host_failures])

    if not failed:
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_system_requirements", True, 
                     "All RDAF system requirements are met.", 
                     output="\n\n".join(outputs))
    else:
        reason = (
            "Requirement: All RDAF hosts must meet minimum system requirements.\n"
            "Observed: The following issues were found:\n"
            + "\n".join(failed) +
            "\nTo pass: Ensure all hosts meet CPU (≥4 cores), memory (≥8GB), and have Python and time sync configured."
        )
        return Result(f"{APP_ID}.{STAGE}.check_rdaf_system_requirements", False, reason, 
                     output="\n\n".join(outputs))

@check_for(APP_ID, stage=STAGE)
def check_docker_requirements(spec: Any) -> Result:
    """Check Docker service and container runtime requirements."""
    hosts, user, pwd = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_docker_requirements")
    if prereq_result:
        return prereq_result

    failed = []
    outputs = []
    
    for host in hosts:
        host_failures = []
        host_outputs = []
        
        # Check Docker service status
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "systemctl is-active docker", 
                                           logger=logger)
        if rc == 0 and stdout.strip() == "active":
            host_outputs.append("Docker service: ACTIVE")
        else:
            host_failures.append("Docker service not active")
            host_outputs.append(f"Docker service: INACTIVE - {stdout}")

        # Check Docker version
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "docker --version", 
                                           logger=logger)
        if rc == 0 and stdout:
            host_outputs.append(f"Docker version: {stdout}")
        else:
            host_failures.append("Docker command not available")
            host_outputs.append(f"Docker version: FAILED - {stderr}")

        # Check if user can run docker commands
        stdout, stderr, rc = run_ssh_command(host, user, pwd, 
                                           "docker info > /dev/null 2>&1 && echo OK || echo FAILED", 
                                           logger=logger)
        if stdout.strip() == "OK":
            host_outputs.append("Docker access: OK")
        else:
            host_failures.append("User cannot run docker commands (may need docker group membership)")
            host_outputs.append("Docker access: FAILED")

        outputs.append(f"{host}:\n  " + "\n  ".join(host_outputs))
        
        if host_failures:
            failed.extend([f"{host}: {failure}" for failure in host_failures])

    if not failed:
        return Result(f"{APP_ID}.{STAGE}.check_docker_requirements", True, 
                     "Docker requirements are met on all hosts.", 
                     output="\n\n".join(outputs))
    else:
        reason = (
            "Requirement: Docker must be installed, active, and accessible to the deployment user.\n"
            "Observed: The following Docker issues were found:\n"
            + "\n".join(failed) +
            "\nTo pass: Install Docker, start the service, and add the deployment user to the docker group."
        )
        return Result(f"{APP_ID}.{STAGE}.check_docker_requirements", False, reason, 
                     output="\n\n".join(outputs))

