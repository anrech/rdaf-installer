import re

import check_log_utils

from validation_checks.check_core import Result, check_for
from validation_checks.checks.common.ssh_utils import run_ssh_command

logger = check_log_utils.setup_logger()

APP_ID, STAGE = "nso", "pre"

def _extract_hosts_creds(spec):
    """Extract hosts and credentials from spec, ensuring proper types."""
    for plat in spec.get("platforms", []):
        if plat.get("type") == "VanillaVM":
            creds = plat.get("creds", {})
            hosts = plat.get("hosts", [])
            user = creds.get("user")
            pwd = creds.get("password")
            return hosts, user, pwd
    return [], None, None

def _check_ssh_prereqs(hosts, user, pwd, check_name):
    """Check SSH prerequisites and return error Result if validation fails."""
    if not hosts or not user or not pwd:
        reason = (
            f"Requirement: hosts, user, and password must be defined in the spec.\n"
            f"Observed: hosts={hosts}, user={user}, password={'set' if pwd else 'not set'}\n"
            f"Remediation: Ensure all required fields are present in the spec."
        )
        return Result(f"{APP_ID}.{STAGE}.{check_name}", False, reason, output=None)
    return None

def _safe_run_ssh_command(host, user, pwd, command, logger=None):
    """Safely run SSH command with proper error handling."""
    try:
        return run_ssh_command(host, user, pwd, command, logger=logger)
    except Exception as e:
        logger.error(f"SSH command failed on {host}: {e}") if logger else None
        return "", f"SSH Error: {str(e)}", -1

def hw_get_nic_count(stdout):
    """
    Count lines starting with digits + colon (e.g. '1: lo:', '2: eth0:').
    """
    nb_nic_count, sb_nic_count = 0,0
    for line in stdout.splitlines():
        if re.match(r"^\d+:\s", line.strip()):
            if re.search(",UP", line):
                nb_nic_count += 1
            if re.search(",LOWER_UP", line):
                sb_nic_count += 1

    if nb_nic_count >= 1 and sb_nic_count >= 1:
        return True
    else:
        return False

@check_for(APP_ID, stage=STAGE)
def uname_architecture_check(spec):
    arch = spec.get("arch", "x86_64")
    output = f"arch: {arch}"
    if arch == "x86_64":
        return Result(f"{APP_ID}.{STAGE}.uname_architecture_check", True, "Architecture is x86_64.", output=output)
    else:
        reason = (
            "Requirement: Architecture must be x86_64.\n"
            f"Observed: arch={arch}\n"
            "To pass: Ensure the system architecture is x86_64."
        )
        return Result(f"{APP_ID}.{STAGE}.uname_architecture_check", False, reason, output=output)

@check_for(APP_ID, stage=STAGE)
def glibc_version_check(spec):
    hosts, user, pwd = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "glibc_version_check")
    if prereq_result:
        return prereq_result
    results = []
    for host in hosts:
        stdout, stderr, rc = run_ssh_command(host, user, pwd, "ldd --version | head -n1", logger=logger)
        output = f"stdout: {stdout}\nstderr: {stderr}\nrc: {rc}"
        if rc != 0:
            reason = (
                "Requirement: glibc must be installed and accessible.\n"
                f"Observed: SSH or command failed on {host}.\n"
                f"Remediation: Ensure glibc is installed and accessible.\nOutput: {output}"
            )
            results.append((False, reason, output))
        else:
            results.append((True, f"glibc version OK on {host}.", output))
    if all(r[0] for r in results):
        return Result(f"{APP_ID}.{STAGE}.glibc_version_check", True, "glibc version check passed on all hosts.", output="\n\n".join(r[2] for r in results))
    else:
        fail_reasons = "\n\n".join(r[1] for r in results if not r[0])
        return Result(f"{APP_ID}.{STAGE}.glibc_version_check", False, fail_reasons, output="\n\n".join(r[2] for r in results))

@check_for(APP_ID, stage=STAGE)
def ant_version_check(spec):
    return _multi_host_check(
        spec,
        "ant_version_check",
        "ant -version",
        "Apache Ant must be installed and accessible.",
        "Install Apache Ant and ensure it is in the PATH."
    )

@check_for(APP_ID, stage=STAGE)
def tar_version_check(spec):
    return _multi_host_check(
        spec,
        "tar_version_check",
        "tar --version | head -n1",
        "tar must be installed and accessible.",
        "Install tar and ensure it is in the PATH."
    )

@check_for(APP_ID, stage=STAGE)
def gzip_version_check(spec):
    return _multi_host_check(
        spec,
        "gzip_version_check",
        "gzip --version | head -n1",
        "gzip must be installed and accessible.",
        "Install gzip and ensure it is in the PATH."
    )

@check_for(APP_ID, stage=STAGE)
def openssl_version_check(spec):
    return _multi_host_check(
        spec,
        "openssl_version_check",
        "openssl version",
        "OpenSSL must be installed and accessible.",
        "Install OpenSSL and ensure it is in the PATH."
    )

@check_for(APP_ID, stage=STAGE)
def find_version_check(spec):
    return _multi_host_check(
        spec,
        "find_version_check",
        "find --version | head -n1",
        "find must be installed and accessible.",
        "Install find and ensure it is in the PATH."
    )

@check_for(APP_ID, stage=STAGE)
def which_version_check(spec):
    return _multi_host_check(
        spec,
        "which_version_check",
        "which --version | head -n1",
        "which must be installed and accessible.",
        "Install which and ensure it is in the PATH."
    )

@check_for(APP_ID, stage=STAGE)
def libpam_presence_check(spec):
    return _multi_host_check(
        spec,
        "libpam_presence_check",
        "ldd /bin/login | grep libpam.so.0",
        "libpam must be present on the system.",
        "Install libpam and ensure /bin/login is linked against it."
    )

@check_for(APP_ID, stage=STAGE)
def libexpat_presence_check(spec):
    return _library_presence_check(
        spec,
        "libexpat_presence_check",
        r"find /usr/lib64 /usr/lib /lib64 /lib -name 'libexpat.so*' 2>/dev/null | head -1 || ldconfig -p 2>/dev/null | grep -E 'libexpat\.so' | head -1 | awk '{print $NF}'",
        "libexpat must be present on the system.",
        "Install libexpat development package (e.g., 'yum install expat-devel' on Red Hat/CentOS)."
    )

@check_for(APP_ID, stage=STAGE)
def libz_presence_check(spec):
    return _library_presence_check(
        spec,
        "libz_presence_check", 
        r"find /usr/lib64 /usr/lib /lib64 /lib -name 'libz.so*' 2>/dev/null | head -1 || ldconfig -p 2>/dev/null | grep -E 'libz\.so' | head -1 | awk '{print $NF}'",
        "libz must be present on the system.",
        "Install zlib development package (e.g., 'yum install zlib-devel' on Red Hat/CentOS)."
    )

@check_for(APP_ID, stage=STAGE)
def cpu_check(spec):
    hosts, user, pwd = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "cpu_check")
    if prereq_result:
        return prereq_result

    results = []
    for host in hosts:
        try:
            stdout, stderr, rc = run_ssh_command(host, user, pwd, "nproc", logger=logger)
            output = f"stdout: {stdout}\nstderr: {stderr}\nrc: {rc}"
            try:
                cpu_count = int(stdout.strip()) if stdout else 0
            except Exception:
                cpu_count = 0
            if rc != 0 or cpu_count < 8:
                reason = (
                    "Requirement: At least 8 CPUs.\n"
                    f"Observed: {cpu_count} CPUs on {host}.\n"
                    f"Remediation: Add more CPUs.\nOutput: {output}"
                )
                results.append((False, reason, output))
            else:
                results.append((True, f"CPU check OK on {host}.", output))
        except Exception as e:
            reason = f"Error during CPU check on {host}: {str(e)}"
            results.append((False, reason, ""))

    if all(r[0] for r in results):
        return Result(f"{APP_ID}.{STAGE}.cpu_check", True, "CPU check passed on all hosts.", output="\n\n".join(r[2] for r in results if r[2]))
    else:
        fail_reasons = "\n\n".join(r[1] for r in results if not r[0])
        return Result(f"{APP_ID}.{STAGE}.cpu_check", False, fail_reasons, output="\n\n".join(r[2] for r in results if r[2]))

@check_for(APP_ID, stage=STAGE)
def nic_check(spec):
    hosts, user, pwd = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "nic_check")
    if prereq_result:
        return prereq_result

    results = []
    cmd = "ip link show"
    for host in hosts:
        try:
            stdout, stderr, rc = _safe_run_ssh_command(host, user, pwd, cmd)
            output = f"stdout: {stdout}\nstderr: {stderr}\nrc: {rc}"
            nic_ok = hw_get_nic_count(stdout)
            if nic_ok:
                results.append((True, f"NIC check OK on {host}.", output))
            else:
                reason = (
                    f"Requirement: At least one southbound NIC and one northbound NIC should be present on host={host}\n"
                    f"Observed: NIC count is not sufficient as per requirement\n"
                    f"Remediation: Use cmd={cmd} on host={host} to check the NIC status and take further action to remove or add NIC"
                )
                results.append((False, reason, output))
        except Exception as e:
            reason = f"Error during NIC check on {host}: {str(e)}"
            results.append((False, reason, ""))

    if all(r[0] for r in results):
        return Result(f"{APP_ID}.{STAGE}.nic_check", True, "Sufficient NIC count present on all hosts", output="\n\n".join(r[2] for r in results if r[2]))
    else:
        fail_reasons = "\n\n".join(r[1] for r in results if not r[0])
        return Result(f"{APP_ID}.{STAGE}.nic_check", False, fail_reasons, output="\n\n".join(r[2] for r in results if r[2]))


@check_for(APP_ID, stage=STAGE)
def ram_check(spec):
    hosts, user, pwd = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "ram_check")
    if prereq_result:
        return prereq_result

    results = []
    for host in hosts:
        try:
            stdout, stderr, rc = _safe_run_ssh_command(host, user, pwd, "free -b", logger)
            mem_bytes = 0
            for line in stdout.splitlines():
                if line.startswith("Mem:"):
                    parts = line.split()
                    if len(parts) > 1:
                        try:
                            mem_bytes = int(parts[1])
                        except Exception:
                            mem_bytes = 0
            mem_gb = mem_bytes / (1024 ** 3)
            output = f"stdout: {stdout}\nstderr: {stderr}\nrc: {rc}"
            if rc != 0 or mem_gb < 4:
                reason = (
                    "Requirement: At least 4Gi RAM.\n"
                    f"Observed: {mem_gb:.2f}Gi RAM on {host}.\n"
                    f"Remediation: Add more RAM.\nOutput: {output}"
                )
                results.append((False, reason, output))
            else:
                results.append((True, f"RAM check OK on {host}.", output))
        except Exception as e:
            reason = f"Error during RAM check on {host}: {str(e)}"
            results.append((False, reason, ""))

    if all(r[0] for r in results):
        return Result(f"{APP_ID}.{STAGE}.ram_check", True, "RAM check passed on all hosts.", output="\n\n".join(r[2] for r in results if r[2]))
    else:
        fail_reasons = "\n\n".join(r[1] for r in results if not r[0])
        return Result(f"{APP_ID}.{STAGE}.ram_check", False, fail_reasons, output="\n\n".join(r[2] for r in results if r[2]))

@check_for(APP_ID, stage=STAGE)
def disk_space_check(spec):
    hosts, user, pwd = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "disk_space_check")
    if prereq_result:
        return prereq_result

    results = []
    for host in hosts:
        try:
            # Check total disk space
            cmd = "df -BG --total | grep total | awk '{print $2}'"
            stdout, stderr, rc = _safe_run_ssh_command(host, user, pwd, cmd)
            output = f"stdout: {stdout}\nstderr: {stderr}\nrc: {rc}"

            total_space_str = stdout.strip().rstrip('G') if stdout else "0"
            try:
                total_space = float(total_space_str)
            except ValueError:
                total_space = 0

            if total_space < 100:
                reason = (
                    f"Requirement: Total disk space on host={host} should be at least 100 G\n"
                    f"Observed: Total hard disk space is {total_space} G\n"
                    f"Remediation: Increase hard disk space on host={host}"
                )
                results.append((False, reason, output))
                continue

            # Check available disk space
            cmd = "df -BM --total | grep total | awk '{print $4}'"
            stdout, stderr, rc = _safe_run_ssh_command(host, user, pwd, cmd)
            output += f"\n\nstdout: {stdout}\nstderr: {stderr}\nrc: {rc}"

            available_space_str = stdout.strip().rstrip('M') if stdout else "0"
            try:
                available_space = float(available_space_str)
            except ValueError:
                available_space = 0

            if available_space < 250:
                reason = (
                    f"Requirement: Total available disk space on host={host} should be at least 250 M\n"
                    f"Observed: Total available hard disk space is {available_space} M\n"
                    f"Remediation: Free some hard disk space on host={host}"
                )
                results.append((False, reason, output))
            else:
                results.append((True, f"Hard disk check OK on {host}.", output))

        except Exception as e:
            reason = f"Error during disk space check on {host}: {str(e)}"
            results.append((False, reason, ""))

    if all(r[0] for r in results):
        return Result(f"{APP_ID}.{STAGE}.disk_space_check", True, "Hard disk check passed on all hosts.", output="\n\n".join(r[2] for r in results if r[2]))
    else:
        fail_reasons = "\n\n".join(r[1] for r in results if not r[0])
        return Result(f"{APP_ID}.{STAGE}.disk_space_check", False, fail_reasons, output="\n\n".join(r[2] for r in results if r[2]))

def _library_presence_check(spec, check_name, command, requirement, remediation):
    """
    Specialized library presence check that validates both command success AND output content.
    For library checks, we need to ensure the command not only succeeds but also finds actual files.
    """
    hosts, user, pwd = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, check_name)
    if prereq_result:
        return prereq_result

    results = []
    for host in hosts:
        try:
            stdout, stderr, rc = _safe_run_ssh_command(host, user, pwd, command, logger)
            output = f"stdout: {stdout}\nstderr: {stderr}\nrc: {rc}"
            
            # For library presence, we need BOTH: rc == 0 AND stdout contains actual file paths
            if rc != 0:
                reason = (
                    f"Requirement: {requirement}\n"
                    f"Observed: Command failed on {host} with return code {rc}.\n"
                    f"Remediation: {remediation}\nOutput: {output}"
                )
                results.append((False, reason, output))
            elif not stdout or not stdout.strip():
                reason = (
                    f"Requirement: {requirement}\n"
                    f"Observed: Library not found on {host}.\n"
                    f"Remediation: {remediation}\nOutput: {output}"
                )
                results.append((False, reason, output))
            else:
                # Success: command succeeded and found library files
                library_path = stdout.strip().split('\n')[0]  # Get first match
                results.append((True, f"{check_name} OK on {host}. Found: {library_path}", output))
        except Exception as e:
            reason = f"Error during {check_name} on {host}: {str(e)}"
            results.append((False, reason, ""))

    if all(r[0] for r in results):
        return Result(f"{APP_ID}.{STAGE}.{check_name}", True, f"{check_name} passed on all hosts.", output="\n\n".join(r[2] for r in results if r[2]))
    else:
        fail_reasons = "\n\n".join(r[1] for r in results if not r[0])
        return Result(f"{APP_ID}.{STAGE}.{check_name}", False, fail_reasons, output="\n\n".join(r[2] for r in results if r[2]))

def _multi_host_check(spec, check_name, command, requirement, remediation):
    """Unified multi-host check function with consistent error handling."""
    hosts, user, pwd = _extract_hosts_creds(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, check_name)
    if prereq_result:
        return prereq_result

    results = []
    for host in hosts:
        try:
            stdout, stderr, rc = _safe_run_ssh_command(host, user, pwd, command, logger)
            output = f"stdout: {stdout}\nstderr: {stderr}\nrc: {rc}"
            if rc != 0:
                reason = (
                    f"Requirement: {requirement}\n"
                    f"Observed: SSH or command failed on {host}.\n"
                    f"Remediation: {remediation}\nOutput: {output}"
                )
                results.append((False, reason, output))
            else:
                results.append((True, f"{check_name} OK on {host}.", output))
        except Exception as e:
            reason = f"Error during {check_name} on {host}: {str(e)}"
            results.append((False, reason, ""))

    if all(r[0] for r in results):
        return Result(f"{APP_ID}.{STAGE}.{check_name}", True, f"{check_name} passed on all hosts.", output="\n\n".join(r[2] for r in results if r[2]))
    else:
        fail_reasons = "\n\n".join(r[1] for r in results if not r[0])
        return Result(f"{APP_ID}.{STAGE}.{check_name}", False, fail_reasons, output="\n\n".join(r[2] for r in results if r[2]))
