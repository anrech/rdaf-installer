from typing import Any

import check_log_utils

from validation_checks.check_core import Result, check_for
from validation_checks.checks.common.ssh_utils import run_ssh_command

logger = check_log_utils.setup_logger()

APP_ID, STAGE = "nso", "post"

def _extract_hosts_creds(spec):
    for plat in spec.get("platforms", []):
        if plat.get("type") == "VanillaVM":
            creds = plat.get("creds", {})
            hosts = plat.get("hosts", [])
            user = creds.get("user")
            pwd = creds.get("password")
            return hosts, user, pwd
    return [], None, None

def _check_ssh_prereqs(hosts, user, pwd, check_name):
    if not hosts or not user or not pwd:
        reason = (
            f"Requirement: hosts, user, and password must be defined in the spec.\n"
            f"Observed: hosts={hosts}, user={user}, password={'set' if pwd else 'not set'}\n"
            f"Remediation: Ensure all required fields are present in the spec."
        )
        return Result(f"{APP_ID}.{STAGE}.{check_name}", False, reason, output=None)
    return None

@check_for(APP_ID, stage=STAGE)
def check_tailf_hcc_oper_status(spec: Any) -> Result:
    hosts, user, pwd = _extract_hosts_creds(spec)
    # Check for HA enable
    ha_enable = False
    for plat in spec.get("platforms", []):
        if plat.get("type") == "VanillaVM":
            for app in plat.get("apps", []):
                if app.get("type") == "NSO":
                    ha = app.get("HA", {})
                    ha_enable = ha.get("ha_enable", False)
    if not ha_enable:
        return Result(f"{APP_ID}.{STAGE}.check_tailf_hcc_oper_status", False, "NSO HA is not enabled in the spec (ha_enable: false). This check requires HA to be enabled.")
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_tailf_hcc_oper_status")
    if prereq_result:
        return prereq_result
    if not user or not pwd:
        reason = (
            f"Requirement: user and password must be defined in the spec.\n"
            f"Observed: user={user}, password={'set' if pwd else 'not set'}\n"
            f"Remediation: Ensure all required fields are present in the spec."
        )
        return Result(f"{APP_ID}.{STAGE}.check_tailf_hcc_oper_status", False, reason, output=None)
    failed = []
    outputs = []
    for host in hosts:
        # Use a here-document to simulate interactive su + ncs_cli + show command
        cmd = (
            "su nsoadmin <<'EOF'\n"
            "ncs_cli -C <<'EON'\n"
            "show packages package oper-status\n"
            "exit\n"
            "EON\n"
            "exit\n"
            "EOF"
        )
        stdout, stderr, rc = run_ssh_command(host, user, pwd, cmd, logger=logger)
        found = False
        if rc == 0:
            for block in stdout.split('packages package'):
                if 'tailf-hcc' in block and 'oper-status up' in block:
                    found = True
                    break
        if rc != 0 or not found:
            failed.append(f"{host}: {stdout or stderr or 'No output'}")
            outputs.append(f"{host} output:\nstdout: {stdout}\nstderr: {stderr}")
    if not failed:
        return Result(f"{APP_ID}.{STAGE}.check_tailf_hcc_oper_status", True, "tailf-hcc package oper-status is UP on all hosts.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            "Requirement: The operation status of the tailf-hcc package must be UP (output should contain 'oper-status up').\n"
            "Observed: Output did not contain 'oper-status up' on the following hosts:\n"
            + "\n".join(failed) +
            "\nTo pass: Ensure the tailf-hcc package is installed and operational on all NSO nodes."
        )
        return Result(f"{APP_ID}.{STAGE}.check_tailf_hcc_oper_status", False, reason, output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE)
def check_tailf_hcc_package_version(spec: Any) -> Result:
    expected = None
    hosts, user, pwd = _extract_hosts_creds(spec)
    # Check for HA enable
    ha_enable = False
    for plat in spec.get("platforms", []):
        if plat.get("type") == "VanillaVM":
            for app in plat.get("apps", []):
                if app.get("type") == "NSO":
                    ha = app.get("HA", {})
                    ha_enable = ha.get("ha_enable", False)
                    expected = ha.get("hcc_version")
    if not ha_enable:
        return Result(f"{APP_ID}.{STAGE}.check_tailf_hcc_package_version", False, "NSO HA is not enabled in the spec (ha_enable: false). This check requires HA to be enabled.")
    if not expected:
        return Result(f"{APP_ID}.{STAGE}.check_tailf_hcc_package_version", False, "hcc_version not found in spec.")
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_tailf_hcc_package_version")
    if prereq_result:
        return prereq_result
    if not user or not pwd:
        reason = (
            f"Requirement: user and password must be defined in the spec.\n"
            f"Observed: user={user}, password={'set' if pwd else 'not set'}\n"
            f"Remediation: Ensure all required fields are present in the spec."
        )
        return Result(f"{APP_ID}.{STAGE}.check_tailf_hcc_package_version", False, reason, output=None)
    failed = []
    outputs = []
    for host in hosts:
        # Use a here-document to simulate interactive su + ncs_cli + show command
        cmd = (
            "su nsoadmin <<'EOF'\n"
            "ncs_cli -C <<'EON'\n"
            "show packages package package-version\n"
            "exit\n"
            "EON\n"
            "exit\n"
            "EOF"
        )
        stdout, stderr, rc = run_ssh_command(host, user, pwd, cmd, logger=logger)
        actual = None
        if rc == 0:
            for block in stdout.split('packages package'):
                if 'tailf-hcc' in block:
                    for line in block.splitlines():
                        if line.strip().startswith('package-version'):
                            actual = line.strip().split()[-1]
                            break
        if rc != 0 or actual != expected:
            failed.append(f"{host}: expected {expected}, got {actual or stdout or stderr or 'No output'}")
            outputs.append(f"{host} output:\nstdout: {stdout}\nstderr: {stderr}")
    if not failed:
        return Result(f"{APP_ID}.{STAGE}.check_tailf_hcc_package_version", True, f"tailf-hcc package version matches ({expected}) on all hosts.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            f"Requirement: The tailf-hcc package version must match the expected version from the spec (hcc_version: {expected}).\n"
            "Observed: Version mismatch on the following hosts:\n"
            + "\n".join(failed) +
            "\nTo pass: Ensure the installed tailf-hcc package version matches the spec."
        )
        return Result(f"{APP_ID}.{STAGE}.check_tailf_hcc_package_version", False, reason, output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE) 
def check_ncs_state_version(spec: Any) -> Result:
    expected = None
    hosts, user, pwd = _extract_hosts_creds(spec)
    # Check for HA enable
    ha_enable = False
    for plat in spec.get("platforms", []):
        if plat.get("type") == "VanillaVM":
            for app in plat.get("apps", []):
                if app.get("type") == "NSO":
                    expected = app.get("version")
    '''if not ha_enable:
        return Result(f"{APP_ID}.{STAGE}.check_tailf_hcc_package_version", False, "NSO HA is not enabled in the spec (ha_enable: false). This check requires HA to be enabled.")'''
    if not expected:
        return Result(f"{APP_ID}.{STAGE}.check_ncs_state_version", False, "ncs_version not found in spec.")
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_ncs_state_version")
    if prereq_result:
        return prereq_result
    if not user or not pwd:
        reason = (
            f"Requirement: user and password must be defined in the spec.\n"
            f"Observed: user={user}, password={'set' if pwd else 'not set'}\n"
            f"Remediation: Ensure all required fields are present in the spec."
        )
        return Result(f"{APP_ID}.{STAGE}.check_ncs_state_version", False, reason, output=None)
    failed = []
    outputs = []
    for host in hosts:
        # Use a here-document to simulate interactive su + ncs_cli + show command
        cmd = (
            "su nsoadmin <<'EOF'\n"
            "ncs_cli -C <<'EON'\n"
            "show ncs-state version\n"
            "exit\n"
            "EON\n"
            "exit\n"
            "EOF"
        )
        stdout, stderr, rc = run_ssh_command(host, user, pwd, cmd, logger=logger)
        actual = None
        if rc == 0:
            output = stdout.split(' ')
            if output:
                actual = output[-1]
                break
        if rc != 0 or actual != expected:
            failed.append(f"{host}: expected {expected}, got {actual or stdout or stderr or 'No output'}")
            outputs.append(f"{host} output:\nstdout: {stdout}\nstderr: {stderr}")
    if not failed:
        return Result(f"{APP_ID}.{STAGE}.check_ncs_state_version", True, f"ncs-state matches ({expected}) on all hosts.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            f"Requirement: The ncs-state version must match the expected version from the spec (ncs-state version: {expected}).\n"
            "Observed: Version mismatch on the following hosts:\n"
            + "\n".join(failed) +
            "\nTo pass: Ensure the installed ncs-state version matches the spec."
        )
        return Result(f"{APP_ID}.{STAGE}.check_ncs_state_version", False, reason, output="\n\n".join(outputs) if outputs else None)
