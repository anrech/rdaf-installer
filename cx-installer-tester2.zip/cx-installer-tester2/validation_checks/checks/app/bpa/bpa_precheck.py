"""
validation_checks.checks.app.bpa.bpa_precheck
=============================================
BPA  ·  PRE-install checks (software + hardware)

"""

from __future__ import annotations

import check_log_utils

from validation_checks.check_core import Result, check_for

logger = check_log_utils.setup_logger()
from typing import Any, Dict, List, Tuple

from validation_checks.checks.common.ssh_utils import run_ssh_command

APP_ID, STAGE = "bpa", "pre"

def _check_ssh_prereqs(hosts, user, pwd, check_name):
    if not hosts or not user or not pwd:
        reason = (
            f"Requirement: hosts, user, and password must be defined in the spec.\n"
            f"Observed: hosts={hosts}, user={user}, password={'set' if pwd else 'not set'}\n"
            f"Remediation: Ensure all required fields are present in the spec."
        )
        return Result(f"{APP_ID}.{STAGE}.{check_name}", False, reason, output=None)
    return None

# ---------------------------------------------------------------------------
# Low-level SSH helper (unchanged)
# ---------------------------------------------------------------------------
# def run_ssh_command(host: str, user: str, pwd: str, command: str, timeout: int = 20):
#     import subprocess
#     # Add SSH and command timeout
#     cmd = f"timeout {timeout}s sshpass -p '{pwd}' ssh -o ConnectTimeout=10 -o StrictHostKeyChecking=no {user}@{host} '{command}'"
#     res = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE,
#                          stderr=subprocess.PIPE, text=True)
#     return res.stdout.strip(), res.stderr.strip(), res.returncode


# ---------------------------------------------------------------------------
# Spec utilities
# ---------------------------------------------------------------------------
def _extract_hosts_creds_flavour(spec: Dict[str, Any]) -> Tuple[List[str], str, str, str]:
    """
    Return ([hosts], user, pwd, flavour) for the first RKE2 platform.
    """
    plat = next(p for p in spec["platforms"] if p["type"] == "RKE2")
    hosts = plat["hosts"]
    creds = plat["creds"]
    flavour = "Regular"
    for app in plat["apps"]:
        if app.get("name") == "BPA":
            for ent in app.get("entitlements", []):
                if isinstance(ent, dict) and "deploymentType" in ent:
                    flavour = ent["deploymentType"]
    return hosts, creds["user"], creds["password"], flavour


# ---------------------------------------------------------------------------
# -------------------- SOFTWARE single-host helpers -------------------------
# ---------------------------------------------------------------------------
def _ntp_host(host, user, pwd):      # chronyd running?
    out, err, rc = run_ssh_command(host, user, pwd, "systemctl is-active chronyd", logger=logger)
    if rc != 0:
        return False, f"SSH or command failed. stderr: {err or 'No error message'}"
    return out.strip() == "active", out or err

def _dns_host(host, user, pwd):      # DNS configured?
    out, err, rc = run_ssh_command(host, user, pwd, "nmcli dev show | grep DNS", logger=logger)
    if rc != 0:
        # SSH or command failed
        return False, f"SSH or command failed. stderr: {err or 'No error message'}"
    return ("IP4.DNS" in out), out or err

def _smtp_host(host, user, pwd):     # port 25 open?
    out, err, rc = run_ssh_command(host, user, pwd, f"nc -zv {host} 25", logger=logger)
    if rc != 0:
        return False, f"SSH or command failed. stderr: {err or 'No error message'}"
    return rc == 0 and "succeeded" in out, out or err

def _proxy_host(host, user, pwd):    # proxy env present?
    out, err, rc = run_ssh_command(host, user, pwd, "env | grep -i proxy", logger=logger)
    if rc != 0:
        return False, f"SSH or command failed. stderr: {err or 'No error message'}"
    return bool(out), out or err


# ---------------------------------------------------------------------------
# -------------------- SOFTWARE wrappers (decorated) ------------------------
# ---------------------------------------------------------------------------
def _wrap_bool(id_tail: str, fn_single, spec) -> Result:
    hosts, user, pwd, _ = _extract_hosts_creds_flavour(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, id_tail)
    if prereq_result:
        return prereq_result
    msgs, ok_all, outputs, failed = [], True, [], []
    for h in hosts:
        ok, output = fn_single(h, user, pwd)
        ok_all &= ok if isinstance(ok, bool) else ok[0]
        msgs.append(f"{h}: {'OK' if ok else 'FAIL'}")
        if not ok:
            failed.append(h)
            outputs.append(f"{h} output:\n{output}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.{id_tail}", True, "All hosts passed the check.")
    else:
        reason = (
            f"Requirement: {id_tail.replace('_', ' ').capitalize()} must succeed on all hosts.\n"
            f"Observed: The following hosts failed: {', '.join(failed)}\n"
            f"To pass: Ensure all hosts meet the requirement for {id_tail.replace('_', ' ')}."
        )
        return Result(f"{APP_ID}.{STAGE}.{id_tail}", False, reason, output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE)
def check_ntp(spec):
    hosts, user, pwd, _ = _extract_hosts_creds_flavour(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_ntp")
    if prereq_result:
        return prereq_result
    msgs, ok_all, outputs, failed = [], True, [], []
    for h in hosts:
        out, err, rc = run_ssh_command(h, user, pwd, "systemctl is-active chronyd", logger=logger)
        ok = out.strip() == "active"
        ok_all &= ok
        msgs.append(f"{h}: {'OK' if ok else 'FAIL'}")
        if not ok:
            failed.append(h)
            outputs.append(f"{h} output:\nstdout: {out}\nstderr: {err}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.check_ntp", True, "NTP is enabled on all hosts.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            f"Requirement: NTP (chronyd) must be active on all hosts.\n"
            f"Observed: The following hosts failed: {', '.join(failed)}\n"
            f"To pass: Ensure chronyd is installed and running on all hosts."
        )
        return Result(f"{APP_ID}.{STAGE}.check_ntp", False, reason, output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE)
def check_dns(spec):
    hosts, user, pwd, _ = _extract_hosts_creds_flavour(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_dns")
    if prereq_result:
        return prereq_result
    msgs, ok_all, outputs, failed = [], True, [], []
    for h in hosts:
        out, err, rc = run_ssh_command(h, user, pwd, "nmcli dev show | grep DNS", logger=logger)
        ok = "IP4.DNS" in out
        ok_all &= ok
        msgs.append(f"{h}: {'OK' if ok else 'FAIL'}")
        if not ok:
            failed.append(h)
            outputs.append(f"{h} output:\nstdout: {out}\nstderr: {err}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.check_dns", True, "DNS is configured on all hosts.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            f"Requirement: DNS must be configured on all hosts.\n"
            f"Observed: The following hosts failed: {', '.join(failed)}\n"
            f"To pass: Ensure all hosts have DNS configured."
        )
        return Result(f"{APP_ID}.{STAGE}.check_dns", False, reason, output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE)
def check_smtp(spec):
    hosts, user, pwd, _ = _extract_hosts_creds_flavour(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_smtp")
    if prereq_result:
        return prereq_result
    msgs, ok_all, outputs, failed = [], True, [], []
    for h in hosts:
        out, err, rc = run_ssh_command(h, user, pwd, f"nc -zv {h} 25", logger=logger)
        ok = rc == 0 and "succeeded" in out
        ok_all &= ok
        msgs.append(f"{h}: {'OK' if ok else 'FAIL'}")
        if not ok:
            failed.append(h)
            outputs.append(f"{h} output:\nstdout: {out}\nstderr: {err}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.check_smtp", True, "SMTP port 25 is open on all hosts.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            f"Requirement: SMTP port 25 must be open on all hosts.\n"
            f"Observed: The following hosts failed: {', '.join(failed)}\n"
            f"To pass: Ensure port 25 is open and reachable on all hosts."
        )
        return Result(f"{APP_ID}.{STAGE}.check_smtp", False, reason, output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE)
def check_proxy(spec):
    hosts, user, pwd, _ = _extract_hosts_creds_flavour(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "check_proxy")
    if prereq_result:
        return prereq_result
    msgs, ok_all, outputs, failed = [], True, [], []
    for h in hosts:
        out, err, rc = run_ssh_command(h, user, pwd, "env | grep -i proxy", logger=logger)
        ok = bool(out)
        ok_all &= ok
        msgs.append(f"{h}: {'OK' if ok else 'FAIL'}")
        if not ok:
            failed.append(h)
            outputs.append(f"{h} output:\nstdout: {out}\nstderr: {err}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.check_proxy", True, "Proxy is configured on all hosts.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            f"Requirement: Proxy must be configured on all hosts.\n"
            f"Observed: The following hosts failed: {', '.join(failed)}\n"
            f"To pass: Ensure all hosts have the required proxy environment variables set."
        )
        return Result(f"{APP_ID}.{STAGE}.check_proxy", False, reason, output="\n\n".join(outputs) if outputs else None)


# ---------------------------------------------------------------------------
# -------------------- HARDWARE thresholds ----------------------------------
# ---------------------------------------------------------------------------
FLAVOR_REQ = {
    "Regular": {
        "cpu": 8, "mem": 8,
        "disk": {"/": 150, "/home": 50, "/opt": 500},
        "ports": [], "nics": 0,
    },
    "Medium": { "cpu": 16, "mem": 32, "disk": {"/": 500}, "ports": [443], "nics": 1 },
    "Large":  { "cpu": 32, "mem": 64, "disk": {"/": 1000}, "ports": [443], "nics": 2 },
}

def _req(spec): return FLAVOR_REQ.get(_extract_hosts_creds_flavour(spec)[3],
                                      FLAVOR_REQ["Regular"])


# -------------------- HARDWARE single-host helpers -------------------------
def _cpu_host(h,u,p,r): cores=int(run_ssh_command(h,u,p,"nproc", logger=logger)[0] or 0);return cores>=r["cpu"],cores
def _mem_host(h,u,p,r): kb=int(run_ssh_command(h,u,p,"awk '/MemTotal/{print $2}' /proc/meminfo", logger=logger)[0] or 0); gb=kb/1048576;return gb>=r["mem"],gb
def _disk_host(h,u,p,m,th): gb=int(run_ssh_command(h,u,p,f"df -BG --output=avail,target | awk '$2==\"{m}\"{{print $1}}'", logger=logger)[0].strip("G") or 0);return gb>=th,gb
def _nics_host(h,u,p,r): n=int(run_ssh_command(h,u,p,"ls -1 /sys/class/net | grep -vc lo", logger=logger)[0] or 0);return n>=r["nics"],n
def _ports_host(h,u,p,plist): miss=[port for port in plist if run_ssh_command(h,u,p,f"netstat -tuln | grep -q ':{port} '", logger=logger)[2]!=0];return not miss,miss


# -------------------- HARDWARE wrappers ------------------------------------
def _hw_wrap(id_tail: str, checker, spec, *args):
    hosts, user, pwd, flav = _extract_hosts_creds_flavour(spec)
    req   = _req(spec)
    msgs, ok_all, failed, outputs = [], True, [], []
    for h in hosts:
        ok, val = checker(h, user, pwd, req, *args) if args else checker(h, user, pwd, req)
        ok_all &= ok
        msgs.append(f"{h}: {val}")
        if not ok:
            failed.append(f"{h}: {val}")
            # Try to get command output if possible
            out, err, rc = run_ssh_command(h, user, pwd, 'echo $LASTCMD', logger=logger)
            outputs.append(f"{h}:\nstdout: {out}\nstderr: {err}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.{id_tail}", True, f"flavour={flav}\nAll hosts meet the requirement.")
    else:
        req_desc = id_tail.replace('hw_', '').replace('_', ' ').capitalize()
        reason = (
            f"Requirement: {req_desc} must meet the minimum required threshold for flavour '{flav}'.\n"
            f"Observed: The following hosts did not meet the requirement:\n" +
            "\n".join(failed) +
            f"\nTo pass: Ensure all hosts meet the minimum {req_desc.lower()} for the selected deployment flavour."
        )
        return Result(f"{APP_ID}.{STAGE}.{id_tail}", False, reason, output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE)
def hw_cpu(spec):
    hosts, user, pwd, flav = _extract_hosts_creds_flavour(spec)
    req = _req(spec)
    msgs, ok_all, outputs, failed = [], True, [], []
    for h in hosts:
        out, err, rc = run_ssh_command(h, user, pwd, "nproc", logger=logger)
        try:
            cores = int(out or 0)
        except Exception:
            cores = 0
        ok = cores >= req["cpu"]
        ok_all &= ok
        msgs.append(f"{h}: {cores}")
        if not ok:
            failed.append(f"{h}: {cores}")
            outputs.append(f"{h} output:\nstdout: {out}\nstderr: {err}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.hw_cpu", True, f"flavour={flav}\nAll hosts meet the CPU requirement.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            f"Requirement: CPU must meet the minimum required threshold for flavour '{flav}'.\n"
            f"Observed: The following hosts did not meet the requirement:\n" +
            "\n".join(failed) +
            f"\nTo pass: Ensure all hosts meet the minimum CPU for the selected deployment flavour."
        )
        return Result(f"{APP_ID}.{STAGE}.hw_cpu", False, reason, output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE)
def hw_memory(spec):
    hosts, user, pwd, flav = _extract_hosts_creds_flavour(spec)
    req = _req(spec)
    msgs, ok_all, outputs, failed = [], True, [], []
    for h in hosts:
        out, err, rc = run_ssh_command(h, user, pwd, "awk '/MemTotal/{print $2}' /proc/meminfo", logger=logger)
        try:
            kb = int(out or 0)
            gb = kb / 1048576
        except Exception:
            gb = 0
        ok = gb >= req["mem"]
        ok_all &= ok
        msgs.append(f"{h}: {gb:.2f} GB")
        if not ok:
            failed.append(f"{h}: {gb:.2f} GB")
            outputs.append(f"{h} output:\nstdout: {out}\nstderr: {err}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.hw_memory", True, f"flavour={flav}\nAll hosts meet the memory requirement.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            f"Requirement: Memory must meet the minimum required threshold for flavour '{flav}'.\n"
            f"Observed: The following hosts did not meet the requirement:\n" +
            "\n".join(failed) +
            f"\nTo pass: Ensure all hosts meet the minimum memory for the selected deployment flavour."
        )
        return Result(f"{APP_ID}.{STAGE}.hw_memory", False, reason, output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE)
def hw_disk_root(spec):
    hosts, user, pwd, flav = _extract_hosts_creds_flavour(spec)
    req = _req(spec)
    prereq_result = _check_ssh_prereqs(hosts, user, pwd, "hw_disk_root")
    if prereq_result:
        return prereq_result
    msgs, ok_all, outputs, failed = [], True, [], []
    for h in hosts:
        out, err, rc = run_ssh_command(h, user, pwd, 'df -BG --output=avail,target | awk "$2==\"/\"{print $1}"', logger=logger)
        try:
            gb = int(out.strip("G") or 0)
        except Exception:
            gb = 0
        ok = gb >= req["disk"]["/"]
        ok_all &= ok
        msgs.append(f"{h}: {gb} GB")
        if not ok:
            failed.append(f"{h}: {gb} GB")
            outputs.append(f"{h} output:\nstdout: {out}\nstderr: {err}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.hw_disk_root", True, f"flavour={flav}\nAll hosts meet the root disk requirement.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            f"Requirement: Root disk must meet the minimum required threshold for flavour '{flav}'.\n"
            f"Observed: The following hosts did not meet the requirement:\n" +
            "\n".join(failed) +
            f"\nTo pass: Ensure all hosts meet the minimum root disk for the selected deployment flavour."
        )
        return Result(f"{APP_ID}.{STAGE}.hw_disk_root", False, reason, output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE)
def hw_disk_home(spec):
    hosts, user, pwd, flav = _extract_hosts_creds_flavour(spec)
    req = _req(spec)
    msgs, ok_all, outputs, failed = [], True, [], []
    for h in hosts:
        out, err, rc = run_ssh_command(h, user, pwd, "df -BG --output=avail,target | awk '$2==\"/home\"{print $1}'", logger=logger)
        try:
            gb = int(out.strip("G") or 0)
        except Exception:
            gb = 0
        ok = gb >= req["disk"]["/home"]
        ok_all &= ok
        msgs.append(f"{h}: {gb} GB")
        if not ok:
            failed.append(f"{h}: {gb} GB")
            outputs.append(f"{h} output:\nstdout: {out}\nstderr: {err}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.hw_disk_home", True, f"flavour={flav}\nAll hosts meet the /home disk requirement.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            f"Requirement: /home disk must meet the minimum required threshold for flavour '{flav}'.\n"
            f"Observed: The following hosts did not meet the requirement:\n" +
            "\n".join(failed) +
            f"\nTo pass: Ensure all hosts meet the minimum /home disk for the selected deployment flavour."
        )
        return Result(f"{APP_ID}.{STAGE}.hw_disk_home", False, reason, output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE)
def hw_disk_opt(spec):
    hosts, user, pwd, flav = _extract_hosts_creds_flavour(spec)
    req = _req(spec)
    msgs, ok_all, outputs, failed = [], True, [], []
    for h in hosts:
        out, err, rc = run_ssh_command(h, user, pwd, "df -BG --output=avail,target | awk '$2==\"/opt\"{print $1}'", logger=logger)
        try:
            gb = int(out.strip("G") or 0)
        except Exception:
            gb = 0
        ok = gb >= req["disk"]["/opt"]
        ok_all &= ok
        msgs.append(f"{h}: {gb} GB")
        if not ok:
            failed.append(f"{h}: {gb} GB")
            outputs.append(f"{h} output:\nstdout: {out}\nstderr: {err}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.hw_disk_opt", True, f"flavour={flav}\nAll hosts meet the /opt disk requirement.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            f"Requirement: /opt disk must meet the minimum required threshold for flavour '{flav}'.\n"
            f"Observed: The following hosts did not meet the requirement:\n" +
            "\n".join(failed) +
            f"\nTo pass: Ensure all hosts meet the minimum /opt disk for the selected deployment flavour."
        )
        return Result(f"{APP_ID}.{STAGE}.hw_disk_opt", False, reason, output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE)
def hw_ports(spec):
    hosts, user, pwd, flav = _extract_hosts_creds_flavour(spec)
    req = _req(spec)
    msgs, ok_all, outputs, failed = [], True, [], []
    for h in hosts:
        miss = []
        for port in req["ports"]:
            out, err, rc = run_ssh_command(h, user, pwd, f"netstat -tuln | grep -q ':{port} '")
            if rc != 0:
                miss.append(port)
                outputs.append(f"{h} port {port} output:\nstdout: {out}\nstderr: {err}")
        ok = not miss
        ok_all &= ok
        msgs.append(f"{h}: {'OK' if ok else 'Missing ports: ' + ', '.join(map(str, miss))}")
        if not ok:
            failed.append(f"{h}: {', '.join(map(str, miss))}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.hw_ports", True, f"flavour={flav}\nAll hosts meet the port requirement.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            f"Requirement: All required ports must be open for flavour '{flav}'.\n"
            f"Observed: The following hosts did not meet the requirement:\n" +
            "\n".join(failed) +
            f"\nTo pass: Ensure all required ports are open for the selected deployment flavour."
        )
        return Result(f"{APP_ID}.{STAGE}.hw_ports", False, reason, output="\n\n".join(outputs) if outputs else None)

@check_for(APP_ID, stage=STAGE)
def hw_nic(spec):
    hosts, user, pwd, flav = _extract_hosts_creds_flavour(spec)
    req = _req(spec)
    msgs, ok_all, outputs, failed = [], True, [], []
    for h in hosts:
        out, err, rc = run_ssh_command(h, user, pwd, "ls -1 /sys/class/net | grep -vc lo")
        try:
            nics = int(out or 0)
        except Exception:
            nics = 0
        ok = nics >= req["nics"]
        ok_all &= ok
        msgs.append(f"{h}: {nics}")
        if not ok:
            failed.append(f"{h}: {nics}")
            outputs.append(f"{h} output:\nstdout: {out}\nstderr: {err}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.hw_nic", True, f"flavour={flav}\nAll hosts meet the NIC requirement.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            f"Requirement: NIC count must meet the minimum required threshold for flavour '{flav}'.\n"
            f"Observed: The following hosts did not meet the requirement:\n" +
            "\n".join(failed) +
            f"\nTo pass: Ensure all hosts meet the minimum NIC count for the selected deployment flavour."
        )
        return Result(f"{APP_ID}.{STAGE}.hw_nic", False, reason, output="\n\n".join(outputs) if outputs else None)


# ---------------------------------------------------------------------------
# Optional CLI for manual run
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse
    import pathlib
    import sys

    import yaml
    ap = argparse.ArgumentParser(description="Manual BPA pre-check run")
    ap.add_argument("--spec", required=True, help="YAML spec path")
    args = ap.parse_args()

    _spec = yaml.safe_load(pathlib.Path(args.spec).read_text())
    results = [check_ntp(_spec), check_dns(_spec), check_smtp(_spec),
               check_proxy(_spec), hw_cpu(_spec), hw_memory(_spec),
               hw_disk_root(_spec), hw_disk_home(_spec), hw_disk_opt(_spec),
               hw_ports(_spec), hw_nic(_spec)]

    for r in results:
        print(f"{r.id}: {'OK' if r.success else 'FAIL'}")
        if r.message: print("   ", r.message.replace("\n", "\n    "))
    sys.exit(0 if all(r.success for r in results) else 1)
