"""
BPA – POST-installation checks
Runs on every master node defined in the deployment spec.

Each public function:
    • is decorated with @check_for("bpa", stage="post")
    • accepts a single argument: spec (parsed YAML)
    • returns a validation_checks.check_core.Result
"""

from __future__ import annotations

import check_log_utils

from validation_checks.check_core import Result, check_for
from validation_checks.checks.common.ssh_utils import run_ssh_command

logger = check_log_utils.setup_logger()

APP_ID, STAGE = "bpa", "post"


def _check_ssh_prereqs(masters, check_name):
    if not masters or any(not h or not u or not p for h, u, p in masters):
        reason = (
            f"Requirement: master hosts, user, and password must be defined in the spec.\n"
            f"Observed: masters={masters}\n"
            f"Remediation: Ensure all required fields are present in the spec."
        )
        return Result(f"{APP_ID}.{STAGE}.{check_name}", False, reason, output=None)
    return None


def _master_creds(spec):
    masters = []
    for plat in spec.get("platforms", []):
        if plat.get("type") != "RKE2":
            continue
        creds = plat["creds"]
        for host in plat.get("hosts", []):
            masters.append((host, creds["user"], creds["password"]))
    return masters


def _check_nodes_host(host: str, user: str, pwd: str) -> tuple[bool, str]:
    cmd = "kubectl get nodes --no-headers"
    stdout, stderr, rc = run_ssh_command(host, user, pwd, cmd, logger=logger)
    if rc != 0:
        logger.warning("Node check failed on %s: %s %s", host, stdout, stderr)
        return False, f"SSH or command failed. stderr: {stderr or 'No error message'}"
    if "Ready" not in stdout:
        logger.warning("Node check failed on %s: %s %s", host, stdout, stderr)
        return False, stdout or stderr
    return True, stdout


@check_for(APP_ID, stage=STAGE)
def check_nodes(spec) -> Result:
    masters = _master_creds(spec)
    prereq_result = _check_ssh_prereqs(masters, "check_nodes")
    if prereq_result:
        return prereq_result
    ok_all  = True
    details = []
    outputs = []
    for host, user, pwd in masters:
        ok, output = _check_nodes_host(host, user, pwd)
        ok_all &= ok
        details.append(f"{host}: {'OK' if ok else 'NOT Ready'}")
        outputs.append(f"{host} output:\n{output}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.check_nodes", True, "All master nodes are Ready.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            "Requirement: All master nodes must be in 'Ready' state (kubectl get nodes).\n"
            "Observed: The following nodes are not Ready:\n" +
            "\n".join([d for d in details if 'NOT Ready' in d]) +
            "\nTo pass: Ensure all master nodes are healthy and reachable by kubelet."
        )
        return Result(f"{APP_ID}.{STAGE}.check_nodes", False, reason, output="\n\n".join(outputs) if outputs else None)


def _check_pods_host(host: str, user: str, pwd: str) -> tuple[bool, str]:
    cmd = "kubectl get pod -n bpa-ns --no-headers"
    stdout, stderr, rc = run_ssh_command(host, user, pwd, cmd, logger=logger)
    if rc != 0:
        logger.warning("Pod check failed on %s: %s %s", host, stdout, stderr)
        return False, f"SSH or command failed. stderr: {stderr or 'No error message'}"
    if "Running" not in stdout:
        logger.warning("Pod check failed on %s: %s %s", host, stdout, stderr)
        return False, stdout or stderr
    return True, stdout


@check_for(APP_ID, stage=STAGE)
def check_pods(spec) -> Result:
    masters = _master_creds(spec)
    prereq_result = _check_ssh_prereqs(masters, "check_pods")
    if prereq_result:
        return prereq_result
    ok_all  = True
    details = []
    outputs = []
    for host, user, pwd in masters:
        ok, output = _check_pods_host(host, user, pwd)
        ok_all &= ok
        details.append(f"{host}: {'Running' if ok else 'NOT Running'}")
        outputs.append(f"{host} output:\n{output}")
    if ok_all:
        return Result(f"{APP_ID}.{STAGE}.check_pods", True, "All BPA pods are Running on all master nodes.", output="\n\n".join(outputs) if outputs else None)
    else:
        reason = (
            "Requirement: All BPA pods must be in 'Running' state (kubectl get pod -n bpa-ns).\n"
            "Observed: The following nodes do not have all pods Running:\n" +
            "\n".join([d for d in details if 'NOT Running' in d]) +
            "\nTo pass: Ensure all BPA pods are deployed and healthy in the bpa-ns namespace."
        )
        return Result(f"{APP_ID}.{STAGE}.check_pods", False, reason, output="\n\n".join(outputs) if outputs else None)
