#!/usr/bin/env python3
"""
Auto-generate validation configuration based on discovered checks
"""

import sys
from pathlib import Path
from typing import Dict, List, Set

import yaml

# Add project root to path
ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from validation_checks.check_core import CHECK_REGISTRY
from validation_checks.run_validation_checks import import_all_modules


def discover_all_checks() -> Dict[str, Dict[str, Set[str]]]:
    """Discover all checks by importing modules and inspecting registry"""
    import_all_modules()

    discovered = {}
    for app, stages in CHECK_REGISTRY.items():
        if app == "*":  # Skip wildcard entries for now
            continue
        discovered[app] = {}
        for stage, functions in stages.items():
            discovered[app][stage] = {fn.__name__ for fn in functions}

    return discovered

def load_existing_config(config_path: Path) -> Dict:
    """Load existing validation control config if it exists"""
    if config_path.exists():
        with open(config_path, 'r') as f:
            return yaml.safe_load(f) or {}
    return {}

def merge_config(existing: Dict, discovered: Dict[str, Dict[str, Set[str]]]) -> Dict:
    """Merge discovered checks with existing configuration"""
    # Initialize structure if not present
    if 'validation_control' not in existing:
        existing['validation_control'] = {
            'global_enabled': True,
            'app_controls': {}
        }

    validation_control = existing['validation_control']
    app_controls = validation_control.setdefault('app_controls', {})

    for app, stages in discovered.items():
        if app not in app_controls:
            app_controls[app] = {
                'enabled': True,
                'stage_controls': {},
                'check_controls': {}
            }

        app_config = app_controls[app]

        # Ensure stage_controls is a dictionary (fix legacy format)
        stage_controls = app_config.setdefault('stage_controls', {})
        if not isinstance(stage_controls, dict):
            # Convert legacy boolean format to new structure
            old_enabled = stage_controls if isinstance(stage_controls, bool) else True
            stage_controls = {}
            app_config['stage_controls'] = stage_controls

        # Add stage controls with proper structure
        for stage in stages:
            if stage not in stage_controls:
                stage_controls[stage] = {
                    'enabled': True,
                    'check_controls': {}
                }
            elif not isinstance(stage_controls[stage], dict):
                # Convert legacy boolean to new structure
                old_enabled = stage_controls[stage] if isinstance(stage_controls[stage], bool) else True
                stage_controls[stage] = {
                    'enabled': old_enabled,
                    'check_controls': {}
                }

        # Add check controls (only add new ones, preserve existing settings)
        check_controls = app_config.setdefault('check_controls', {})
        for stage, checks in stages.items():
            stage_check_controls = stage_controls[stage]['check_controls']
            for check in checks:
                # Add to both app-level and stage-level for backward compatibility
                if check not in check_controls:
                    check_controls[check] = True  # Default to enabled
                if check not in stage_check_controls:
                    stage_check_controls[check] = check_controls.get(check, True)

    return existing

def generate_config(output_path: Path, preserve_existing: bool = True, verbose: bool = False):
    """Generate validation configuration file"""
    discovered = discover_all_checks()

    if verbose:
        print("Discovered checks:")
        for app, stages in discovered.items():
            print(f"  {app}:")
            for stage, checks in stages.items():
                print(f"    {stage}: {len(checks)} checks")
                for check in sorted(checks):
                    print(f"      - {check}")

    if preserve_existing:
        existing = load_existing_config(output_path)
        config = merge_config(existing, discovered)
    else:
        # Start fresh
        config = {
            'critical': [],
            'non_critical': ["*"],
            'default_critical': False,
            'validation_control': {
                'global_enabled': True,
                'app_controls': {}
            }
        }
        config = merge_config(config, discovered)

    # Write the updated configuration
    with open(output_path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=True, indent=2)

    total_checks = sum(len(checks) for stages in discovered.values() for checks in stages.values())
    print(f"Generated validation configuration at: {output_path}")
    print(f"Discovered {total_checks} checks across {len(discovered)} apps")

    if preserve_existing:
        print("Existing configuration preserved and merged with new checks")
    else:
        print("Fresh configuration generated")

def validate_config_schema(config: Dict) -> List[str]:
    """Validate configuration against expected schema and return list of errors"""
    errors = []

    # Check root structure
    if not isinstance(config, dict):
        errors.append("Configuration must be a YAML dictionary")
        return errors

    # Check validation_control section
    if 'validation_control' in config:
        validation_control = config['validation_control']
        if not isinstance(validation_control, dict):
            errors.append("validation_control must be a dictionary")
        else:
            # Check global_enabled
            if 'global_enabled' in validation_control:
                if not isinstance(validation_control['global_enabled'], bool):
                    errors.append("validation_control.global_enabled must be a boolean")

            # Check app_controls
            if 'app_controls' in validation_control:
                app_controls = validation_control['app_controls']
                if not isinstance(app_controls, dict):
                    errors.append("validation_control.app_controls must be a dictionary")
                else:
                    for app_name, app_config in app_controls.items():
                        if not isinstance(app_config, dict):
                            errors.append(f"validation_control.app_controls.{app_name} must be a dictionary")
                            continue

                        # Check app-level enabled flag
                        if 'enabled' in app_config and not isinstance(app_config['enabled'], bool):
                            errors.append(f"validation_control.app_controls.{app_name}.enabled must be a boolean")

                        # Check stage_controls
                        if 'stage_controls' in app_config:
                            stage_controls = app_config['stage_controls']
                            if not isinstance(stage_controls, dict):
                                errors.append(f"validation_control.app_controls.{app_name}.stage_controls must be a dictionary")
                            else:
                                for stage_name, stage_config in stage_controls.items():
                                    if not isinstance(stage_config, dict):
                                        errors.append(f"validation_control.app_controls.{app_name}.stage_controls.{stage_name} must be a dictionary")
                                        continue

                                    # Check stage-level enabled flag
                                    if 'enabled' in stage_config and not isinstance(stage_config['enabled'], bool):
                                        errors.append(f"validation_control.app_controls.{app_name}.stage_controls.{stage_name}.enabled must be a boolean")

                                    # Check check_controls
                                    if 'check_controls' in stage_config:
                                        check_controls = stage_config['check_controls']
                                        if not isinstance(check_controls, dict):
                                            errors.append(f"validation_control.app_controls.{app_name}.stage_controls.{stage_name}.check_controls must be a dictionary")
                                        else:
                                            for check_name, check_enabled in check_controls.items():
                                                if not isinstance(check_enabled, bool):
                                                    errors.append(f"validation_control.app_controls.{app_name}.stage_controls.{stage_name}.check_controls.{check_name} must be a boolean")

    # Check optional sections
    for section_name in ['critical_checks', 'non_critical_checks']:
        if section_name in config:
            if not isinstance(config[section_name], list):
                errors.append(f"{section_name} must be a list")
            else:
                for i, item in enumerate(config[section_name]):
                    if not isinstance(item, str):
                        errors.append(f"{section_name}[{i}] must be a string")

    if 'default_critical' in config and not isinstance(config['default_critical'], bool):
        errors.append("default_critical must be a boolean")

    return errors


def validate_config(config_path: Path) -> bool:
    """Validate that the configuration file is well-formed"""
    try:
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)

        # Enhanced schema validation
        errors = validate_config_schema(config)
        if errors:
            print("Configuration validation errors:")
            for error in errors:
                print(f"  - {error}")
            return False

        print("✅ Configuration file is valid")
        return True

    except yaml.YAMLError as e:
        print(f"ERROR: Invalid YAML syntax: {e}")
        return False
    except Exception as e:
        print(f"ERROR: Failed to validate config: {e}")
        return False

def list_discovered_checks():
    """List all discovered checks without generating config"""
    discovered = discover_all_checks()

    print("Discovered validation checks:")
    print("=" * 50)

    for app in sorted(discovered.keys()):
        stages = discovered[app]
        print(f"\n{app.upper()}:")

        for stage in sorted(stages.keys()):
            checks = stages[stage]
            print(f"  {stage}: {len(checks)} checks")
            for check in sorted(checks):
                print(f"    - {check}")

    total_checks = sum(len(checks) for stages in discovered.values() for checks in stages.values())
    print(f"\nTotal: {total_checks} checks across {len(discovered)} apps")

def main():
    import argparse
    ap = argparse.ArgumentParser(description="Generate validation configuration from discovered checks")
    ap.add_argument("-o", "--output", default="validation_checks/validation_policies/default.yaml",
                   help="Output configuration file path")
    ap.add_argument("--fresh", action="store_true",
                   help="Generate fresh config (don't preserve existing settings)")
    ap.add_argument("-v", "--verbose", action="store_true",
                   help="Show detailed output of discovered checks")
    ap.add_argument("--validate", action="store_true",
                   help="Validate existing configuration file")
    ap.add_argument("--list", action="store_true",
                   help="List all discovered checks without generating config")
    args = ap.parse_args()

    if args.list:
        list_discovered_checks()
        return

    output_path = Path(args.output)

    if args.validate:
        if not output_path.exists():
            print(f"Configuration file does not exist: {output_path}")
            sys.exit(1)
        is_valid = validate_config(output_path)
        sys.exit(0 if is_valid else 1)

    # Create output directory if it doesn't exist
    output_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        generate_config(output_path, preserve_existing=not args.fresh, verbose=args.verbose)
    except Exception as e:
        print(f"ERROR: Failed to generate configuration: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
