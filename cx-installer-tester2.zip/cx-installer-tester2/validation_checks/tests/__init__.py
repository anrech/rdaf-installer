"""
Test suite for the validation checks framework.

This directory contains comprehensive tests for:
- Validation control functionality
- JIRA integration modes
- Enhanced reporting features
"""
