#!/usr/bin/env python3
"""
Test script to verify validation control functionality works correctly
"""

import sys
import tempfile
from pathlib import Path

import yaml

# Add project root to path
ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from validation_checks.run_validation_checks import is_validation_enabled


def test_validation_control():
    """Test the validation control logic"""

    # Test configuration
    validation_control = {
        'global_enabled': True,
        'app_controls': {
            'bpa': {
                'enabled': True,
                'stage_controls': {
                    'pre': True,
                    'post': False  # Disabled
                },
                'check_controls': {
                    'check_smtp': False,  # Disabled
                    'check_dns': True,
                    'hw_cpu': True
                }
            },
            'nso': {
                'enabled': False,  # Completely disabled
                'stage_controls': {
                    'pre': True,
                    'post': True
                },
                'check_controls': {}
            }
        }
    }

    # Test cases
    test_cases = [
        # (app, stage, check_name, expected_result, description)
        ('bpa', 'pre', 'check_dns', True, "BPA pre check_dns should be enabled"),
        ('bpa', 'pre', 'check_smtp', False, "BPA pre check_smtp should be disabled"),
        ('bpa', 'post', 'check_nodes', False, "BPA post checks should be disabled"),
        ('nso', 'pre', 'cpu_check', False, "NSO app is completely disabled"),
        ('bpa', 'pre', 'new_check', True, "New BPA pre check should default to enabled"),
        ('unknown_app', 'pre', 'some_check', True, "Unknown app should default to enabled"),
    ]

    print("Testing validation control logic...")
    print("=" * 60)

    all_passed = True
    for app, stage, check_name, expected, description in test_cases:
        result = is_validation_enabled(app, stage, check_name, validation_control)
        status = "✅ PASS" if result == expected else "❌ FAIL"
        print(f"{status} {description}")
        if result != expected:
            print(f"      Expected: {expected}, Got: {result}")
            all_passed = False

    print("=" * 60)
    if all_passed:
        print("🎉 All tests passed!")
        return True
    else:
        print("💥 Some tests failed!")
        return False

def test_global_disabled():
    """Test when global validation is disabled"""
    validation_control = {
        'global_enabled': False,  # Globally disabled
        'app_controls': {
            'bpa': {
                'enabled': True,
                'stage_controls': {'pre': True},
                'check_controls': {'check_dns': True}
            }
        }
    }

    result = is_validation_enabled('bpa', 'pre', 'check_dns', validation_control)
    assert result == False, "Global disable should override all other settings"
    print("✅ Global disable test passed")

def main():
    print("Validation Control Test Suite")
    print("=" * 60)

    try:
        test_global_disabled()
        success = test_validation_control()

        if success:
            print("\n🎉 All validation control tests passed!")
            sys.exit(0)
        else:
            print("\n💥 Some validation control tests failed!")
            sys.exit(1)

    except Exception as e:
        print(f"\n💥 Test suite failed with error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
