#!/usr/bin/env python3
"""
Test module for library presence validation logic in NSO precheck.
This tests the improved validation logic for libexpat and libz presence checks.
"""

import unittest
import sys
import os

# Add the validation_checks directory to Python path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

class TestLibraryPresenceValidation(unittest.TestCase):
    """Test cases for library presence validation logic."""
    
    def simulate_library_presence_check(self, stdout, stderr, rc):
        """
        Simulate the library presence check validation logic.
        This mirrors the logic in _library_presence_check function.
        """
        # For library presence, we need BOTH: rc == 0 AND stdout contains actual file paths
        if rc != 0:
            return False, f"Command failed with return code {rc}"
        elif not stdout or not stdout.strip():
            return False, "Library not found on system"
        else:
            # Success: command succeeded and found library files
            library_path = stdout.strip().split('\n')[0]  # Get first match
            return True, f"Library found at: {library_path}"
    
    def test_library_found_single(self):
        """Test case: Single library file found."""
        stdout = "/usr/lib64/libz.so.1.2.11\n"
        stderr = ""
        rc = 0
        
        success, message = self.simulate_library_presence_check(stdout, stderr, rc)
        
        self.assertTrue(success, "Should pass when library is found")
        self.assertIn("Library found at:", message)
        self.assertIn("/usr/lib64/libz.so.1.2.11", message)
    
    def test_library_found_multiple(self):
        """Test case: Multiple library files found (should return first)."""
        stdout = "/usr/lib64/libz.so.1\n/usr/lib/libz.so.1\n"
        stderr = ""
        rc = 0
        
        success, message = self.simulate_library_presence_check(stdout, stderr, rc)
        
        self.assertTrue(success, "Should pass when libraries are found")
        self.assertIn("/usr/lib64/libz.so.1", message)
    
    def test_library_not_found(self):
        """Test case: Library not found (empty stdout)."""
        stdout = ""
        stderr = ""
        rc = 0
        
        success, message = self.simulate_library_presence_check(stdout, stderr, rc)
        
        self.assertFalse(success, "Should fail when no library is found")
        self.assertEqual(message, "Library not found on system")
    
    def test_library_whitespace_only(self):
        """Test case: Stdout contains only whitespace."""
        stdout = "   \n  \n"
        stderr = ""
        rc = 0
        
        success, message = self.simulate_library_presence_check(stdout, stderr, rc)
        
        self.assertFalse(success, "Should fail when stdout contains only whitespace")
        self.assertEqual(message, "Library not found on system")
    
    def test_command_error(self):
        """Test case: Command execution error."""
        stdout = ""
        stderr = "find: permission denied"
        rc = 1
        
        success, message = self.simulate_library_presence_check(stdout, stderr, rc)
        
        self.assertFalse(success, "Should fail when command returns error")
        self.assertIn("Command failed with return code 1", message)
    
    def test_command_error_with_output(self):
        """Test case: Command error with some stdout."""
        stdout = "/usr/lib/partial_output"
        stderr = "find: some directories not accessible"
        rc = 2
        
        success, message = self.simulate_library_presence_check(stdout, stderr, rc)
        
        self.assertFalse(success, "Should fail when command returns non-zero exit code")
        self.assertIn("Command failed with return code 2", message)


class TestLibrarySearchCommands(unittest.TestCase):
    """Test cases for the improved library search commands."""
    
    def test_command_patterns(self):
        """Test that the command patterns are properly formatted."""
        libexpat_cmd = r"find /usr/lib64 /usr/lib /lib64 /lib -name 'libexpat.so*' 2>/dev/null | head -1 || ldconfig -p 2>/dev/null | grep -E 'libexpat\.so' | head -1 | awk '{print $NF}'"
        libz_cmd = r"find /usr/lib64 /usr/lib /lib64 /lib -name 'libz.so*' 2>/dev/null | head -1 || ldconfig -p 2>/dev/null | grep -E 'libz\.so' | head -1 | awk '{print $NF}'"
        
        # Verify commands contain expected components
        self.assertIn("find /usr/lib64 /usr/lib /lib64 /lib", libexpat_cmd)
        self.assertIn("libexpat.so*", libexpat_cmd)
        self.assertIn("ldconfig -p", libexpat_cmd)
        self.assertIn("head -1", libexpat_cmd)
        
        self.assertIn("find /usr/lib64 /usr/lib /lib64 /lib", libz_cmd)
        self.assertIn("libz.so*", libz_cmd)
        self.assertIn("ldconfig -p", libz_cmd)
        self.assertIn("head -1", libz_cmd)
    
    def test_library_locations(self):
        """Test that we're searching in the correct Red Hat library locations."""
        expected_locations = ["/usr/lib64", "/usr/lib", "/lib64", "/lib"]
        
        libexpat_cmd = r"find /usr/lib64 /usr/lib /lib64 /lib -name 'libexpat.so*' 2>/dev/null | head -1 || ldconfig -p 2>/dev/null | grep -E 'libexpat\.so' | head -1 | awk '{print $NF}'"
        
        for location in expected_locations:
            self.assertIn(location, libexpat_cmd, f"Command should search in {location}")


if __name__ == '__main__':
    # Run tests with verbose output
    unittest.main(verbosity=2)
