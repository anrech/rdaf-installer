#!/usr/bin/env python3
"""
Test the improved library search commands to verify they work correctly
"""

def test_library_search_commands():
    """Test the library search commands that will be used on Red Hat systems"""
    
    print("Testing library search patterns for Red Hat systems:")
    print("=" * 60)
    
    # Commands we'll use
    test_commands = [
        ("libexpat search", "find /usr/lib* /lib* /opt/lib* -name 'libexpat.so*' 2>/dev/null | head -1"),
        ("libz search", "find /usr/lib* /lib* /opt/lib* -name 'libz.so*' 2>/dev/null | head -1"),
        ("Alternative libexpat", "find /usr/lib64 /usr/lib /lib64 /lib -name 'libexpat.so*' 2>/dev/null | head -1"),
        ("Alternative libz", "find /usr/lib64 /usr/lib /lib64 /lib -name 'libz.so*' 2>/dev/null | head -1"),
        ("Package-based check expat", "rpm -ql expat-devel 2>/dev/null | grep 'libexpat.so' | head -1"),
        ("Package-based check zlib", "rpm -ql zlib-devel 2>/dev/null | grep 'libz.so' | head -1"),
    ]
    
    # Test case scenarios
    test_scenarios = [
        ("Library found", "/usr/lib64/libz.so.1.2.11", "", 0),
        ("Library not found", "", "", 0),
        ("Command error", "", "find: permission denied", 1),
        ("Multiple libraries", "/usr/lib64/libz.so.1\n/usr/lib/libz.so.1", "", 0),
    ]
    
    print("\nCommands to be used:")
    for name, cmd in test_commands:
        print(f"- {name}: {cmd}")
    
    print(f"\nTest scenarios for validation logic:")
    print("-" * 40)
    
    for scenario, stdout, stderr, rc in test_scenarios:
        print(f"\nScenario: {scenario}")
        print(f"stdout: {repr(stdout)}")
        print(f"stderr: {repr(stderr)}")
        print(f"rc: {rc}")
        
        # Apply the new validation logic
        if rc != 0:
            result = "FAIL (command error)"
            reason = f"Command failed with return code {rc}"
        elif not stdout or not stdout.strip():
            result = "FAIL (library not found)"
            reason = "Library not found on system"
        else:
            result = "PASS (library found)"
            library_path = stdout.strip().split('\n')[0]
            reason = f"Found: {library_path}"
        
        print(f"Result: {result}")
        print(f"Reason: {reason}")
        print("-" * 30)
    
    print(f"\nKey improvements:")
    print("1. More specific search paths (/usr/lib*, /lib*, /opt/lib*)")
    print("2. Flexible pattern matching (libz.so*)")
    print("3. Validation of both return code AND stdout content")
    print("4. Better error messages for troubleshooting")
    
    print(f"\nCommon Red Hat library locations:")
    print("- /usr/lib64/ (64-bit libraries)")
    print("- /usr/lib/ (32-bit libraries)")  
    print("- /lib64/ (system 64-bit libraries)")
    print("- /lib/ (system 32-bit libraries)")

if __name__ == "__main__":
    test_library_search_commands()
