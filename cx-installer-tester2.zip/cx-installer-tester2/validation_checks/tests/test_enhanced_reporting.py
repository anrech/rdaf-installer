#!/usr/bin/env python3
"""
Test script to verify the enhanced validation reporting functionality.
"""

import json
import os
import subprocess
import sys
import tempfile
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

import yaml


@dataclass
class TestResult:
    """Structured test result format"""
    test_name: str
    status: str  # "PASS", "FAIL", "WARN"
    message: str
    details: Optional[str] = None
    duration_ms: Optional[int] = None

class StructuredTestReporter:
    """Enhanced test reporter with structured output"""

    def __init__(self):
        self.results: List[TestResult] = []
        self.start_time = None

    def start_test_suite(self, suite_name: str):
        """Start a test suite with structured header"""
        print(f"\n{'='*60}")
        print(f"🧪 {suite_name}")
        print(f"{'='*60}")
        import time
        self.start_time = time.time()

    def log_test_result(self, result: TestResult):
        """Log a structured test result"""
        self.results.append(result)

        status_icons = {
            "PASS": "✅",
            "FAIL": "❌",
            "WARN": "⚠️"
        }

        icon = status_icons.get(result.status, "ℹ️")
        print(f"{icon} {result.test_name}: {result.message}")

        if result.details:
            # Indent details for better readability
            for line in result.details.split('\n'):
                if line.strip():
                    print(f"   {line}")

    def generate_summary(self) -> Dict:
        """Generate structured test summary"""
        import time
        total_time = time.time() - self.start_time if self.start_time else 0

        summary = {
            "test_suite": "Enhanced Validation Reporting",
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "total_duration_ms": int(total_time * 1000),
            "total_tests": len(self.results),
            "results": {
                "PASS": len([r for r in self.results if r.status == "PASS"]),
                "FAIL": len([r for r in self.results if r.status == "FAIL"]),
                "WARN": len([r for r in self.results if r.status == "WARN"])
            },
            "tests": [
                {
                    "name": r.test_name,
                    "status": r.status,
                    "message": r.message,
                    "details": r.details,
                    "duration_ms": r.duration_ms
                }
                for r in self.results
            ]
        }

        return summary

    def print_summary(self):
        """Print structured test summary"""
        summary = self.generate_summary()

        print(f"\n{'='*60}")
        print("📊 TEST SUMMARY")
        print(f"{'='*60}")
        print(f"⏱️  Total Time: {summary['total_duration_ms']}ms")
        print(f"📝 Total Tests: {summary['total_tests']}")
        print(f"✅ Passed: {summary['results']['PASS']}")
        print(f"❌ Failed: {summary['results']['FAIL']}")
        print(f"⚠️  Warnings: {summary['results']['WARN']}")

        overall_status = "PASS" if summary['results']['FAIL'] == 0 else "FAIL"
        status_icon = "🎉" if overall_status == "PASS" else "💥"
        print(f"\n{status_icon} Overall Status: {overall_status}")

        return overall_status == "PASS"

def create_test_spec():
    """Create a simple test specification for validation."""
    test_spec = {
        'platforms': [
            {
                'apps': [
                    {'type': 'bpa'},
                    {'type': 'nso'}
                ]
            }
        ]
    }
    return test_spec

@contextmanager
def safe_directory_change(target_dir):
    """Safely change directory with automatic restoration."""
    original_cwd = os.getcwd()
    try:
        os.chdir(target_dir)
        yield target_dir
    finally:
        os.chdir(original_cwd)

@contextmanager
def temporary_sys_path(new_path):
    """Safely add path to sys.path with automatic cleanup."""
    if new_path not in sys.path:
        sys.path.insert(0, str(new_path))
        try:
            yield
        finally:
            if str(new_path) in sys.path:
                sys.path.remove(str(new_path))
    else:
        yield

def test_enhanced_reporting():
    """Test the enhanced reporting functionality with structured output."""
    reporter = StructuredTestReporter()
    reporter.start_test_suite("Enhanced Validation Reporting")

    # Get directories safely
    test_dir = Path(__file__).parent
    validation_checks_dir = test_dir.parent
    project_root = validation_checks_dir.parent

    # Create temporary spec file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        test_spec = create_test_spec()
        yaml.dump(test_spec, f)
        spec_file = f.name

    try:
        # Test 1: Verify logging configuration
        import time
        start_time = time.time()

        with safe_directory_change(validation_checks_dir):
            with temporary_sys_path(validation_checks_dir):
                try:
                    from check_log_utils import (get_check_logger,
                                                 get_reports_logger)

                    # Test reports logger
                    reports_logger = get_reports_logger()
                    reports_logger.info("=== TESTING ENHANCED VALIDATION REPORTING ===")

                    # Test check logger
                    check_logger = get_check_logger("test_check")
                    check_logger.info("Testing check logger functionality")

                    duration = int((time.time() - start_time) * 1000)
                    result = TestResult(
                        test_name="Logging Configuration",
                        status="PASS",
                        message="Logging system configured successfully",
                        details="Both reports logger and check logger initialized without errors",
                        duration_ms=duration
                    )
                    reporter.log_test_result(result)

                except Exception as e:
                    duration = int((time.time() - start_time) * 1000)
                    result = TestResult(
                        test_name="Logging Configuration",
                        status="FAIL",
                        message="Logging configuration failed",
                        details=f"Error: {str(e)}",
                        duration_ms=duration
                    )
                    reporter.log_test_result(result)

        # Test 2: Verify report generation via subprocess (safer)
        start_time = time.time()
        try:
            # Use subprocess to test the reporting without complex imports
            cmd = [
                sys.executable,
                str(validation_checks_dir / "run_validation_checks.py"),
                "-t", "pre",
                "-s", spec_file
            ]

            with safe_directory_change(validation_checks_dir):
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=30
                )

                duration = int((time.time() - start_time) * 1000)

                if result.returncode == 0 or "validation" in result.stdout.lower():
                    test_result = TestResult(
                        test_name="Report Generation",
                        status="PASS",
                        message="Report generation completed successfully",
                        details=f"Command output preview: {result.stdout[:200]}...",
                        duration_ms=duration
                    )
                else:
                    test_result = TestResult(
                        test_name="Report Generation",
                        status="WARN",
                        message=f"Report generation returned non-zero: {result.returncode}",
                        details=f"Error output: {result.stderr[:200]}...",
                        duration_ms=duration
                    )
                reporter.log_test_result(test_result)

        except subprocess.TimeoutExpired:
            duration = int((time.time() - start_time) * 1000)
            test_result = TestResult(
                test_name="Report Generation",
                status="WARN",
                message="Report generation timed out",
                details="This is expected for complex validation runs",
                duration_ms=duration
            )
            reporter.log_test_result(test_result)
        except Exception as e:
            duration = int((time.time() - start_time) * 1000)
            test_result = TestResult(
                test_name="Report Generation",
                status="FAIL",
                message="Report generation failed",
                details=f"Error: {str(e)}",
                duration_ms=duration
            )
            reporter.log_test_result(test_result)

        # Test 3: Verify log files structure
        start_time = time.time()
        with safe_directory_change(validation_checks_dir):
            log_dir = Path("check_logs")
            expected_files = ["validation_checks.log", "validation_reports.log"]

            found_files = []
            missing_files = []

            for log_file in expected_files:
                log_path = log_dir / log_file
                if log_path.exists():
                    found_files.append(log_file)
                else:
                    missing_files.append(log_file)

            duration = int((time.time() - start_time) * 1000)

            if found_files:
                status = "PASS" if not missing_files else "WARN"
                message = f"Found {len(found_files)}/{len(expected_files)} log files"
                details = f"Found: {', '.join(found_files)}"
                if missing_files:
                    details += f"\nMissing: {', '.join(missing_files)} (may be created during actual validation)"
            else:
                status = "WARN"
                message = "No log files found"
                details = "Log files may be created during actual validation runs"

            test_result = TestResult(
                test_name="Log Files Structure",
                status=status,
                message=message,
                details=details,
                duration_ms=duration
            )
            reporter.log_test_result(test_result)

        # Generate and print structured summary
        success = reporter.print_summary()

        # Optionally output JSON summary for CI/CD integration
        if os.getenv("OUTPUT_JSON_SUMMARY"):
            summary = reporter.generate_summary()
            with open("test_enhanced_reporting_summary.json", "w") as f:
                json.dump(summary, f, indent=2)
            print(f"\n📄 JSON summary written to: test_enhanced_reporting_summary.json")

    except Exception as e:
        test_result = TestResult(
            test_name="Test Framework",
            status="FAIL",
            message="Test framework error",
            details=f"Unexpected error: {str(e)}",
            duration_ms=0
        )
        reporter.log_test_result(test_result)
        success = False
    finally:
        # Clean up temporary file
        try:
            os.unlink(spec_file)
        except Exception:
            pass

    return success


if __name__ == "__main__":
    test_enhanced_reporting()
