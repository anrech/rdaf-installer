#!/usr/bin/env python3
"""
Test the fixed validation control logic with nested check_controls structure
"""

import sys
import tempfile
from pathlib import Path

import yaml

# Add project root to path
ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from validation_checks.run_validation_checks import is_validation_enabled


def test_nested_check_controls():
    """Test the validation control logic with nested stage-level check_controls"""
    
    # Configuration structure matching the real default.yaml structure
    validation_control = {
        'global_enabled': True,
        'app_controls': {
            'nso': {
                'enabled': True,
                # App-level check controls
                'check_controls': {
                    'ant_version_check': True,
                    'cpu_check': True,
                    'libexpat_presence_check': True,
                    'libz_presence_check': True
                },
                # Stage-level controls with nested check_controls
                'stage_controls': {
                    'pre': {
                        'enabled': True,
                        'check_controls': {
                            'ant_version_check': False,  # Disabled at stage level
                            'cpu_check': True,
                            'libexpat_presence_check': False,  # Disabled at stage level
                            'libz_presence_check': True,
                            'new_stage_check': False  # Only exists at stage level
                        }
                    },
                    'post': {
                        'enabled': True,
                        'check_controls': {
                            'check_tailf_hcc_oper_status': True,
                            'check_tailf_hcc_package_version': False  # Disabled at stage level
                        }
                    }
                }
            }
        }
    }

    # Test cases
    test_cases = [
        # Stage-level check_controls should override app-level
        ('nso', 'pre', 'ant_version_check', False, "Stage-level false overrides app-level true"),
        ('nso', 'pre', 'libexpat_presence_check', False, "Stage-level false overrides app-level true"),
        
        # Stage-level check_controls should be used when present
        ('nso', 'pre', 'cpu_check', True, "Stage-level true matches app-level true"),
        ('nso', 'pre', 'libz_presence_check', True, "Stage-level true overrides app-level true"),
        
        # App-level should be used when not defined at stage level
        ('nso', 'pre', 'missing_from_stage', True, "Should fallback to app-level default true"),
        
        # Checks only defined at stage level
        ('nso', 'pre', 'new_stage_check', False, "Stage-only check should work"),
        
        # Post-stage checks
        ('nso', 'post', 'check_tailf_hcc_oper_status', True, "Post-stage check enabled"),
        ('nso', 'post', 'check_tailf_hcc_package_version', False, "Post-stage check disabled"),
        
        # Checks not defined anywhere should default to true
        ('nso', 'post', 'undefined_check', True, "Undefined check should default to true"),
    ]

    print("Testing nested check_controls validation logic...")
    print("=" * 70)

    all_passed = True
    for app, stage, check_name, expected, description in test_cases:
        result = is_validation_enabled(app, stage, check_name, validation_control)
        status = "✅ PASS" if result == expected else "❌ FAIL"
        print(f"{status} {description}")
        print(f"      {app}.{stage}.{check_name} -> Expected: {expected}, Got: {result}")
        if result != expected:
            all_passed = False
        print()

    print("=" * 70)
    if all_passed:
        print("🎉 All nested check_controls tests passed!")
        return True
    else:
        print("💥 Some nested check_controls tests failed!")
        return False


def test_backward_compatibility():
    """Test backward compatibility with simple boolean stage controls"""
    
    # Old-style configuration with simple boolean stage controls
    validation_control = {
        'global_enabled': True,
        'app_controls': {
            'bpa': {
                'enabled': True,
                'stage_controls': {
                    'pre': True,
                    'post': False  # Simple boolean disable
                },
                'check_controls': {
                    'check_dns': True,
                    'check_smtp': False,
                    'hw_cpu': True
                }
            }
        }
    }

    test_cases = [
        ('bpa', 'pre', 'check_dns', True, "Pre-stage enabled, app-level true"),
        ('bpa', 'pre', 'check_smtp', False, "Pre-stage enabled, app-level false"),
        ('bpa', 'post', 'check_dns', False, "Post-stage disabled should override all"),
        ('bpa', 'post', 'hw_cpu', False, "Post-stage disabled should override all"),
    ]

    print("\nTesting backward compatibility with simple boolean stage controls...")
    print("=" * 70)

    all_passed = True
    for app, stage, check_name, expected, description in test_cases:
        result = is_validation_enabled(app, stage, check_name, validation_control)
        status = "✅ PASS" if result == expected else "❌ FAIL"
        print(f"{status} {description}")
        print(f"      {app}.{stage}.{check_name} -> Expected: {expected}, Got: {result}")
        if result != expected:
            all_passed = False
        print()

    print("=" * 70)
    if all_passed:
        print("🎉 All backward compatibility tests passed!")
        return True
    else:
        print("💥 Some backward compatibility tests failed!")
        return False


def main():
    print("Nested Check Controls Test Suite")
    print("=" * 70)
    
    test1_passed = test_nested_check_controls()
    test2_passed = test_backward_compatibility()
    
    if test1_passed and test2_passed:
        print("\n🎉 All tests passed! The validation control fix works correctly.")
        return True
    else:
        print("\n💥 Some tests failed!")
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
