#!/usr/bin/env python3
"""
Final demonstration test showing the validation control fix in action
"""

import sys
from pathlib import Path

# Add project root to path
ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from validation_checks.run_validation_checks import is_validation_enabled

def demonstrate_fix():
    """Demonstrate the fix with a real configuration example"""
    
    print("🔧 VALIDATION CONTROL FIX DEMONSTRATION")
    print("=" * 60)
    print()
    
    # Real configuration structure from default.yaml
    config = {
        'global_enabled': True,
        'app_controls': {
            'nso': {
                'enabled': True,
                # App-level check controls
                'check_controls': {
                    'libexpat_presence_check': True,  # App-level: enabled
                    'libz_presence_check': True,      # App-level: enabled
                    'ant_version_check': True,        # App-level: enabled
                },
                'stage_controls': {
                    'pre': {
                        'enabled': True,
                        # Stage-level check controls (should override app-level)
                        'check_controls': {
                            'libexpat_presence_check': False,  # Stage override: DISABLED
                            'libz_presence_check': False,      # Stage override: DISABLED
                            'ant_version_check': False,        # Stage override: DISABLED
                            'cpu_check': True,
                        }
                    }
                }
            }
        }
    }
    
    print("📋 Configuration:")
    print("   App-level check_controls:")
    print("     - libexpat_presence_check: True")
    print("     - libz_presence_check: True")
    print("     - ant_version_check: True")
    print()
    print("   Stage-level check_controls (pre):")
    print("     - libexpat_presence_check: False  ← Should override app-level")
    print("     - libz_presence_check: False      ← Should override app-level")  
    print("     - ant_version_check: False        ← Should override app-level")
    print("     - cpu_check: True")
    print()
    
    # Test cases
    test_cases = [
        ('libexpat_presence_check', False, "Stage-level False should override app-level True"),
        ('libz_presence_check', False, "Stage-level False should override app-level True"),
        ('ant_version_check', False, "Stage-level False should override app-level True"),
        ('cpu_check', True, "Stage-level True should be used"),
    ]
    
    print("🧪 Testing validation control logic:")
    print("-" * 40)
    
    for check_name, expected, description in test_cases:
        result = is_validation_enabled('nso', 'pre', check_name, config)
        status = "✅ PASS" if result == expected else "❌ FAIL" 
        print(f"{status} {check_name}")
        print(f"      Expected: {expected}, Got: {result}")
        print(f"      Test: {description}")
        print()
    
    print("🎯 SUMMARY:")
    print("Before fix: Stage-level check_controls were ignored")
    print("After fix:  Stage-level check_controls properly override app-level settings")
    print()
    print("✅ The fix correctly handles the nested configuration structure!")


if __name__ == "__main__":
    demonstrate_fix()
