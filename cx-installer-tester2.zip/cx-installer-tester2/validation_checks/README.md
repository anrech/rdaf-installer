# Validation Checks

This directory contains the validation checks framework for the CX Platform Installer.

## 📚 Documentation

For comprehensive documentation, please refer to:
- **[docs/validation_checks/](../docs/validation_checks/)** - Complete documentation

### Quick Start

1. **Run validation checks:**
   ```bash
   python3 run_validation_checks.py -t pre -s ../simple_test_config.yaml
   ```

2. **Update configuration:**
   ```bash
   make update-validation-config
   ```

3. **List available checks:**
   ```bash
   make list-validation-checks
   ```

### Available Make Targets

```bash
# Test enhanced reporting
make test-enhanced-reporting

# Run all tests
make test-all

# Get help
make help-validation

# View detailed execution logs
tail -f check_logs/validation_reports.log
```

## Directory Structure

```
validation_checks/
├── README.md                    # This file
├── Makefile                     # Management commands
├── run_validation_checks.py     # Main validation runner
├── generate_validation_config.py # Auto-discovery utility
├── check_core.py               # Core validation framework
├── check_log_utils.py          # Logging configuration
├── report_utils.py             # Enhanced reporting utilities
├── tests/                      # Test suite
│   ├── __init__.py
│   ├── test_validation_control.py
│   ├── test_jira_modes.py
│   └── test_enhanced_reporting.py
├── checks/                     # Validation check implementations
│   └── app/
│       ├── bpa/               # BPA-specific checks
│       └── nso/               # NSO-specific checks
├── validation_policies/        # Configuration files
│   └── default.yaml
└── check_logs/                # Log files
    ├── validation_checks.log   # General logging
    └── validation_reports.log  # Detailed reports
```                    # Show all available targets
make list-validation-checks            # List discovered validation checks
make update-validation-config          # Update validation configuration
make validate-validation-config        # Validate configuration syntax
make test-validation-control          # Test validation control logic
make test-jira-modes                  # Test JIRA integration modes
```

## 📖 Complete Documentation

For detailed information about:
- Configuration and setup
- JIRA integration
- Development guidelines
- Usage examples
- Troubleshooting

Visit: **[docs/validation_checks/](../docs/validation_checks/)**
