#!/usr/bin/env python3
"""
Run pre- or post-checks for the apps present in a deployment spec.
Critical / non-critical checks are defined in a YAML policy file.
"""

from __future__ import annotations

import argparse
import importlib.util
import logging
import pkgutil
import sys
from pathlib import Path
from typing import Dict, Set

import yaml

ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent
CHECK_DIR = ROOT / "checks"
DEFAULT_POLICY = PROJECT_ROOT / "validation_policies" / "default.yaml"

# Global variable to track original spec file for reporting
_original_spec_file = None


if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from integrations import jira_utils
from validation_checks.check_core import CHECK_REGISTRY, Result
from validation_checks.check_log_utils import get_reports_logger
from validation_checks.report_utils import ValidationReporter

logging.basicConfig(level=logging.INFO, format="%(levelname)-8s: %(message)s")
log = logging.getLogger("driver")
PACKAGE_PREFIX = "validation_checks.checks."


def import_all_modules():
    """Import every Python module under checks/"""
    for mod in pkgutil.walk_packages(
            path=[str(CHECK_DIR)],
            prefix=PACKAGE_PREFIX,        #  ← **critical**
            onerror=lambda x: None):
        importlib.import_module(mod.name)


def apps_from_spec(spec: Dict) -> Set[str]:
    return {
        a["type"].lower()
        for plat in spec.get("platforms", [])
        for a in plat.get("apps", []) if a.get("type")
    }


def load_policy(path: Path):
    if not path.exists():
        return set(), set(), True, {}
    data = yaml.safe_load(path.read_text()) or {}
    return (
        {x.lower() for x in data.get("critical", [])},
        {x.lower() for x in data.get("non_critical", [])},
        bool(data.get("default_critical", True)),
        data.get("validation_control", {})
    )

def is_critical(cid: str, crit: Set[str], non: Set[str], default: bool) -> bool:
    cid = cid.lower()
    if cid in crit: return True
    if cid in non : return False
    return default


def is_validation_enabled(app: str, stage: str, check_name: str, validation_control: Dict) -> bool:
    """Check if a specific validation should run based on configuration"""
    # Global check
    if not validation_control.get('global_enabled', True):
        return False

    app_controls = validation_control.get('app_controls', {})
    app_config = app_controls.get(app, {})

    # App-level check
    if not app_config.get('enabled', True):
        return False

    # Stage-level check
    stage_controls = app_config.get('stage_controls', {})
    stage_config = stage_controls.get(stage, True)  # Default to enabled
    
    # Handle two formats for stage configuration:
    # 1. Simple boolean: stage_controls: { pre: true, post: false }
    # 2. Complex dict: stage_controls: { pre: { enabled: true, check_controls: {...} } }
    if isinstance(stage_config, bool):
        if not stage_config:
            return False
        # For simple boolean format, fall back to app-level check controls
        app_check_controls = app_config.get('check_controls', {})
        return app_check_controls.get(check_name, True)
    
    # Complex dict format
    if isinstance(stage_config, dict):
        # Check if stage is enabled at all
        if not stage_config.get('enabled', True):
            return False

        # Check-level control - prioritize stage-specific controls over app-level
        stage_check_controls = stage_config.get('check_controls', {})
        app_check_controls = app_config.get('check_controls', {})
        
        # Stage-specific check controls take precedence over app-level
        if check_name in stage_check_controls:
            return stage_check_controls[check_name]
        
        # Fall back to app-level check controls
        return app_check_controls.get(check_name, True)
    
    # Default case - stage is enabled, check app-level controls
    app_check_controls = app_config.get('check_controls', {})
    return app_check_controls.get(check_name, True)  # Default enabled if not specified


def run(stage: str, spec: Dict, policy_path: Path) -> bool:
    # Set up dedicated reporting
    reports_logger = get_reports_logger()
    reporter = ValidationReporter(reports_logger)

    crit, non, default, validation_control = load_policy(policy_path)
    present_apps = apps_from_spec(spec)

    # Log run start with comprehensive details
    reporter.log_run_start(
        stage=stage,
        apps=present_apps,
        spec_file=_original_spec_file or "(spec provided as dict)",
        policy_file=str(policy_path)
    )

    # Log policy details
    reporter.log_policy_details(crit, non, default, validation_control)

    import_all_modules()

    relevant = []
    skipped = []

    for app in present_apps:
        app_checks = CHECK_REGISTRY.get(app, {})
        for fn in app_checks.get(stage, []):
            check_name = fn.__name__
            cid = f"{app}.{stage}.{check_name}"

            # Check if this validation should run
            if is_validation_enabled(app, stage, check_name, validation_control):
                relevant.append((cid, fn))
            else:
                skipped.append(cid)
                log.info(f"Skipping disabled check: {cid}")

    # Log check discovery results
    reporter.log_check_discovery(relevant, skipped)

    if skipped:
        log.info(f"Skipped {len(skipped)} disabled checks")
        if log.isEnabledFor(logging.DEBUG):
            for skip_id in skipped:
                log.debug(f"  - {skip_id}")

    if not relevant:
        log.warning("No %s checks discovered for apps %s", stage, ", ".join(present_apps))
        reporter.log_run_summary(success=True, failures=[])
        return True

    # Track failures for consolidated JIRA ticket
    failures = []

    for cid, fn in relevant:
        import time
        check_start_time = time.time()

        try:
            res: Result = fn(spec)
        except Exception as exc:
            res = Result(id=cid, success=False, message=str(exc))

        execution_time = time.time() - check_start_time
        crit_flag = is_critical(cid, crit, non, default)

        # Log detailed result to reports file
        reporter.log_check_result(cid, res, crit_flag, execution_time)

        tag = "OK" if res.success else ("FAIL (critical)" if crit_flag else "FAIL (non-critical)")
        print(f"▶ {cid} … {tag}")
        if not res.success:
            print("    Reason:", res.message)

            # Store failure information for potential consolidated ticket
            failure_info = {
                'check_id': cid,
                'message': f"{res.message}\n\nFull check output:\n{res.output if hasattr(res, 'output') and res.output else res}",
                'host': getattr(res, 'host', None),
                'extra': getattr(res, 'extra', None)
            }
            failures.append(failure_info)

            # Handle JIRA ticket creation based on mode
            try:
                from integrations import jira_utils
                ticket_mode = jira_utils.get_ticket_mode()

                if ticket_mode == "individual":
                    # Original behavior: create individual tickets
                    ticket_key = jira_utils.raise_ticket(
                        check_id=cid,
                        message=failure_info['message'],
                        stage=stage,
                        host=failure_info['host'],
                        extra=failure_info['extra']
                    )
                    if ticket_key:
                        ticket_url = f"{jira_utils.JIRA_URL}/browse/{ticket_key}"
                        print(f"    JIRA ticket created: {ticket_key} ({ticket_url})")
                        reporter.log_jira_activity("Individual Ticket Created", f"Check: {cid}, Ticket: {ticket_key}")
                    else:
                        print(f"    JIRA ticket creation is disabled for this stage (ENABLE_JIRA_{stage.upper()}=false). No ticket created.")
                        reporter.log_jira_activity("Individual Ticket Skipped", f"Check: {cid} (JIRA disabled for {stage})")
                # For consolidated mode, tickets will be created after all checks complete

            except Exception as e:
                print(f"    Failed to create JIRA ticket: {e}")
                reporter.log_jira_activity("Individual Ticket Failed", f"Check: {cid}, Error: {e}")
        elif res.message:
            print("    ", res.message)

        if not res.success and crit_flag:
            log.error("Stopping run after critical failure: %s", cid)
            reporter.log_run_summary(success=False, failures=failures)
            return False

    # Create consolidated JIRA ticket if in consolidated mode and there are failures
    if failures:
        try:
            from integrations import jira_utils
            ticket_mode = jira_utils.get_ticket_mode()

            if ticket_mode == "consolidated":
                ticket_key = jira_utils.raise_consolidated_ticket(failures, stage)
                if ticket_key:
                    ticket_url = f"{jira_utils.JIRA_URL}/browse/{ticket_key}"
                    print(f"\n📋 Consolidated JIRA ticket created: {ticket_key} ({ticket_url})")
                    print(f"    Contains {len(failures)} validation failures")
                    reporter.log_jira_activity("Consolidated Ticket Created", f"Ticket: {ticket_key}, Failures: {len(failures)}")
                else:
                    print(f"\n📋 Consolidated JIRA ticket creation is disabled for this stage (ENABLE_JIRA_{stage.upper()}=false).")
                    reporter.log_jira_activity("Consolidated Ticket Skipped", f"JIRA disabled for {stage}, Failures: {len(failures)}")
        except Exception as e:
            print(f"\n📋 Failed to create consolidated JIRA ticket: {e}")
            reporter.log_jira_activity("Consolidated Ticket Failed", f"Error: {e}, Failures: {len(failures)}")

    success = len(failures) == 0 or reporter.critical_failures == 0
    reporter.log_run_summary(success=success, failures=failures)

    return success


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-t", "--check-type", choices=["pre", "post"], required=True)
    ap.add_argument("-s", "--spec", required=True)
    ap.add_argument("-p", "--policy", default=str(DEFAULT_POLICY))
    args = ap.parse_args()

    spec = yaml.safe_load(open(args.spec))

    # Store the original spec file path for reporting
    global _original_spec_file
    _original_spec_file = args.spec

    try:
        ok = run(args.check_type, spec, Path(args.policy))
        sys.exit(0 if ok else 1)
    except KeyboardInterrupt:
        print("\nValidation interrupted by user (Ctrl+C). Exiting...")
        sys.exit(130)


if __name__ == "__main__":
    main()
