import logging
import logging.config
import os
import sys

LOG_ROOT_PATH = "./logs"
LOG_FILE_MAIN = "deployer.log"

LOGGING_CONFIG_DICT = {
    # Boilerplate
    "version": 1,
    "disable_existing_loggers": False,   # keep stdlib & dependency loggers alive

    # Log Formatters
    "formatters": {
        "verbose": {                     # timestamp, level, module, message
            "format": "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S",
        },
        "simple": {                      # just level + message (for console)
            "format": "%(levelname)-8s: %(message)s",
        },
    },

    # Log Stream Handlers
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "level": "DEBUG",
            "formatter": "simple",
        },
        "file": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": f"{LOG_ROOT_PATH}/{LOG_FILE_MAIN}",
            "maxBytes": 5_000_000,       # 5 MB per file
            "backupCount": 3,            # keep 3 old logs
            "encoding": "utf-8",
            "level": "DEBUG",
            "formatter": "verbose",
        }
    },

    # Root logger (default)
    "root": {
        "level": "INFO",
        "handlers": ["file"],
    },

    # Custom / package loggers
    "loggers": {
        "cli": {
            "level": "DEBUG",
            "handlers": [],
            "propagate": True,
        },
        "precheck": {
            "level": "INFO",
            "handlers": [],
            "propagate": True,
        },
    },
}


def setup_logger():
    """
    Sets up the logger based on calling module.
    """

    os.makedirs(LOG_ROOT_PATH, exist_ok=True)

    logging.config.dictConfig(LOGGING_CONFIG_DICT)  # apply once

    caller_frame = sys._getframe(1)
    caller_file = os.path.basename(caller_frame.f_code.co_filename)
    caller_module_name, _ = os.path.splitext(caller_file)

    logger = logging.getLogger(caller_module_name)
    logger.info("Logging initiated for %s module.", caller_module_name)

    return logger
