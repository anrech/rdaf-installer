
class KubeConfig:
    def __init__(self, host: str, api_key: str):
        self.host = host
        self.api_key = api_key

class Context:
    def __init__(self, kube_config: KubeConfig):
        self.kube_config = kube_config

    def getKubeConfig(self) -> KubeConfig:
        return self.kube_config
