
from abc import ABC

from driver.context import Context
from models.app import App
from models.response import Response


class AppDriver(ABC):
    def supports(self, app: App):
        pass

    def deploy(self, app: App, dry_run: bool = False) -> Response:
        pass
