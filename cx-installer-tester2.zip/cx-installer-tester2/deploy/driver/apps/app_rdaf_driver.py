import json
import os
from abc import ABC
from pathlib import Path

import ansible_runner
from ansible.executor.playbook_executor import PlaybookExecutor
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.inventory.manager import InventoryManager
from ansible.parsing.dataloader import DataLoader
from ansible.playbook.play import Play
from ansible.vars.manager import VariableManager
from driver.context import Context
from driver.platform.platform_driver import PlatformDriver
from models.app import RDAF, App
from models.response import Response

from deploy import log_utils

logger = log_utils.setup_logger()

def run_ansible_playbook(inventory_path, playbook_path):
    r = ansible_runner.run(
        inventory=inventory_path,
        playbook=playbook_path,
        extravars={'ansible_user':'rdauser'}
    )
    #Check the status
    if r.rc != 0:
        print("Playbook execution failed")
    else:
        print("Playbook executed successfully")

def run_ansible_playbook_check(inventory_path, playbook_path):
    command = f"ansible-playbook '{playbook_path}' -i '{inventory_path}' --check -u rdauser"
    print("Running ansible playbook in --check mode")
    r = ansible_runner.run_command(
        executable_cmd= command,
    )
    #Check the status
    if r[1] != 0:
        print("Playbook execution failed")
    else:
        print("Playbook executed successfully")


class RDAFAppDriver(ABC):
    _type = 'RDAF'
    
    def __init__(self):
        pass

    def supports(self, app) -> bool:
        if app is None:
            print("App is None, cannot check type.")
            return False
        elif hasattr(app, 'type') and app.type == RDAFAppDriver._type:
            return True
        else:
            return False

    def deploy(self, app, dry_run: bool) -> Response:
        app_dict = json.loads(app.model_dump_json()) if hasattr(app, 'model_dump_json') else {}
        
        # Extract RDAF-specific configuration 
        rdaf_config = app_dict.get("config", {})
        # cluster_enable = app_dict.get("cluster", {}).get("cluster_enable", False)
        # ha_enable = app_dict.get("HA", {}).get("ha_enable", False)
        
        print(f"RDAF config: {rdaf_config}")
        # print(f"cluster_enable: {cluster_enable}")
        # print(f"ha_enable: {ha_enable}")
        
        # Define paths to RDAF ansible playbooks
        inventory_path = str(Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "inventory" / "rdaf_inventory.ini")
        main_playbook_path = str(Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "playbooks" / "rdaf_install.yaml")
        # cluster_playbook_path = str(Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "playbooks" / "rdaf-cluster.yaml")
        # ha_playbook_path = str(Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "playbooks" / "rdaf-ha.yaml")
        
        print(f'Deploying via RDAF driver....')
        
        if dry_run:
            if os.path.isfile(inventory_path):
                if os.path.isfile(main_playbook_path):
                    run_ansible_playbook_check(inventory_path, main_playbook_path)
                    
                    # if cluster_enable:
                    #     if os.path.isfile(cluster_playbook_path):
                    #         run_ansible_playbook_check(inventory_path, cluster_playbook_path)
                    #     else:
                    #         logger.error("RDAF cluster playbook missing, please check path : %s", cluster_playbook_path)
                    #         print("\033[91m[ERROR] RDAF cluster playbook missing, please check path \033[0m" + cluster_playbook_path)
                    
                    # if ha_enable:
                    #     if os.path.isfile(ha_playbook_path):
                    #         run_ansible_playbook_check(inventory_path, ha_playbook_path)
                    #     else:
                    #         logger.error("RDAF HA playbook missing, please check path : %s", ha_playbook_path)
                    #         print("\033[91m[ERROR] RDAF HA playbook missing, please check path \033[0m" + ha_playbook_path)
                else:
                    logger.error("RDAF main playbook file is missing, please check path : %s", main_playbook_path)
                    print("\033[91m[ERROR] RDAF main playbook file is missing, please check path \033[0m" + main_playbook_path)
            else:
                logger.error("RDAF inventory file is missing, please check path : %s", inventory_path)
                print("\033[91m[ERROR] RDAF inventory file is missing, please check path \033[0m" + inventory_path)
        else:
            if os.path.isfile(inventory_path):
                if os.path.isfile(main_playbook_path):
                    run_ansible_playbook(inventory_path, main_playbook_path)
                    
                    # if cluster_enable:
                    #     if os.path.isfile(cluster_playbook_path):
                    #         run_ansible_playbook(inventory_path, cluster_playbook_path)
                    #     else:
                    #         logger.error("RDAF cluster playbook missing, please check path : %s", cluster_playbook_path)
                    #         print("\033[91m[ERROR] RDAF cluster playbook missing, please check path \033[0m" + cluster_playbook_path)
                    
                    # if ha_enable:
                    #     if os.path.isfile(ha_playbook_path):
                    #         run_ansible_playbook(inventory_path, ha_playbook_path)
                    #     else:
                    #         logger.error("RDAF HA playbook missing, please check path : %s", ha_playbook_path)
                    #         print("\033[91m[ERROR] RDAF HA playbook missing, please check path \033[0m" + ha_playbook_path)
                else:
                    logger.error("RDAF main playbook file is missing, please check path : %s", main_playbook_path)
                    print("\033[91m[ERROR] RDAF main playbook file is missing, please check path \033[0m" + main_playbook_path)
            else:
                logger.error("RDAF inventory file is missing, please check path : %s", inventory_path)
                print("\033[91m[ERROR] RDAF inventory file is missing, please check path \033[0m" + inventory_path)
        
        
