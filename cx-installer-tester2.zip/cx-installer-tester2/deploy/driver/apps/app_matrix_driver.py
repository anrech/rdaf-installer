
from abc import ABC

from driver.context import Context
from models.app import App, Matrix
from models.response import Response


class MatrixAppDriver(ABC):
    def supports(self, app: Matrix):
        if app.type == 'Matrix':
            return True
        return False

    def deploy(self, app: Matrix, dry_run: bool = False) -> Response:
        print(f'Deploying matrix using settings {app.model_dump_json()}')
