import json
import os
from abc import ABC
from pathlib import Path

import ansible_runner
from ansible.executor.playbook_executor import PlaybookExecutor
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.inventory.manager import InventoryManager
from ansible.parsing.dataloader import DataLoader
from ansible.playbook.play import Play
from ansible.vars.manager import VariableManager
from driver.context import Context
from driver.platform.platform_driver import PlatformDriver
from models.app import NSO, App
from models.response import Response

from deploy import log_utils

logger = log_utils.setup_logger()

def run_ansible_playbook(inventory_path, playbook_path):
    r = ansible_runner.run(
        inventory=inventory_path,
        playbook=playbook_path,
        extravars={'ansible_user':'root'}
    )
    #Check the status
    if r.rc != 0:
        print("Playbook execution failed")
    else:
        print("Playbook executed successfully")

def run_ansible_playbook_check(inventory_path, playbook_path):
    command = f"ansible-playbook '{playbook_path}' -i '{inventory_path}' --check -u root"
    print("Running ansible playbook in --check mode")
    r = ansible_runner.run_command(
        executable_cmd= command,
    )
    #Check the status
    if r[1] != 0:
        print("Playbook execution failed")
    else:
        print("Playbook executed successfully")

class NSODriver(ABC):
    _type= 'NSO'
    def __init__(self):
        pass

    def supports(self, app: NSO)-> bool:
        if app is None:
            print("App is None, cannot check type.")
        elif app.type == NSODriver._type:
            return True
        else:
            return False

    def deploy(self, app: NSO, dry_run: bool) -> Response:
        app_dict = json.loads(app.model_dump_json())
        ha_enable = app_dict.get("HA", {}).get("ha_enable", False)
        lsa_enable = app_dict.get("LSA", {}).get("lsa_enable", False)
        print(f"ha_enable: {ha_enable}")
        print(f"lsa_enable: {lsa_enable}")
        inventory_path = str(Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "inventory" / "nso_inventory.ini")
        playbook_path = str(Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "playbooks" / "nso-install.yaml")
        l2ha_playbook_path = str(Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "playbooks" / "nso-l2ha.yaml")
        lsa_playbook_path = str(Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "playbooks" / "nso-lsa-setup.yaml")

        print(f'Deploying via NSO driver....')
        if dry_run:
            if os.path.isfile(inventory_path):
                if os.path.isfile(playbook_path):
                    run_ansible_playbook_check(inventory_path, playbook_path)
                    if ha_enable:
                        if os.path.isfile(l2ha_playbook_path):
                            run_ansible_playbook_check(inventory_path, l2ha_playbook_path)
                        else:
                            logger.error("l2ha_playbook missing, please check path : %s", l2ha_playbook_path)
                            print("\033[91m[ERROR] l2ha_playbook missing, please check path \033[0m"+l2ha_playbook_path )
                    if lsa_enable:
                        if os.path.isfile(lsa_playbook_path):
                            run_ansible_playbook_check(inventory_path, lsa_playbook_path)
                        else:
                            logger.error("lsa_playbook missing, please check path : %s", lsa_playbook_path)
                            print("\033[91m[ERROR] lsa_playbook missing, please check path \033[0m"+lsa_playbook_path )
                else:
                    logger.error("NSO playbook file is missing, please check path : %s", playbook_path)
                    print("\033[91m[ERROR] NSO playbook file is missing, please check path \033[0m"+ playbook_path)
            else:
                logger.error("NSO inventory file is missing, please check path : %s", inventory_path)
                print("\033[91m[ERROR] NSO inventory file is missing, please check path \033[0m"+ inventory_path)
        else:
            if os.path.isfile(inventory_path):
                if os.path.isfile(playbook_path):
                    run_ansible_playbook(inventory_path, playbook_path)
                    if ha_enable:
                        if os.path.isfile(l2ha_playbook_path):
                            run_ansible_playbook(inventory_path, l2ha_playbook_path)
                        else:
                            logger.error("l2ha_playbook missing, please check path : %s", l2ha_playbook_path)
                            print("\033[91m[ERROR] l2ha_playbook missing, please check path \033[0m"+l2ha_playbook_path )
                    if lsa_enable:
                        if os.path.isfile(lsa_playbook_path):
                            run_ansible_playbook(inventory_path, lsa_playbook_path)
                        else:
                            logger.error("lsa_playbook missing, please check path : %s", lsa_playbook_path)
                            print("\033[91m[ERROR] lsa_playbook missing, please check path \033[0m"+lsa_playbook_path )
                else:
                    logger.error("NSO playbook file is missing, please check path : %s", playbook_path)
                    print("\033[91m[ERROR] NSO playbook file is missing, please check path \033[0m"+ playbook_path)
            else:
                logger.error("NSO inventory file is missing, please check path : %s", inventory_path)
                print("\033[91m[ERROR] NSO inventory file is missing, please check path \033[0m"+ inventory_path)
