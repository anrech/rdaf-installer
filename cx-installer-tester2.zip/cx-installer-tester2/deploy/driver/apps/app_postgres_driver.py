import os
import platform
import shutil
import subprocess
import time
from abc import ABC
from typing import List

import paramiko
from driver.context import Context
from kubernetes import client, config
from models.app import App, Postgres
from models.response import Response


class PostgresAppDriver(ABC):

    # Example usage
    helm_command = [
        'helm', 'install', 'my-release', '.',
        '--set', 'primary.persistence.existingClaim=data-my-postgres-postgresql',
        '--set', 'image.registry=10.197.243.89:5001'
    ]
    directory_path = '/opt/postgresql'
    def supports(self, app: Postgres):
        if app.type == 'Postgres':
            return True
        return False
    def deploy(self, app, dry_run=False):
        print(f'Deploying Postgres using settings {app.model_dump_json()}')
        '''image = app.image_registry
        helm_command = [
        'helm', 'install', 'my-release', '.',
        '--set', 'primary.persistence.existingClaim=data-my-postgres-postgresql',
        '--set', 'image.registry=image'
        ]'''
        server = app.imageserverip
        user = app.user  # TODO NINI
        key = app.absolute_keypath  # Ensure this is the correct absolute path to your private key
        directory = app.directory
        command = (
        f"cd {directory} && "
        "helm install my-postgres . "
        "--set primary.persistence.existingClaim=data-my-postgres-postgresql "
        "--set image.registry=image"
    )
        ##self.run_helm_command(server, app, user, key, command)

    '''def run_helm_command(self, server, app, user, key, command):
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            ssh.connect(
                hostname=app.hostname, port=app.port, username=app.user, password=app.password
            )
            stdin, stdout, stderr = ssh.exec_command(command)
            opt = stdout.readlines()
            opt = "".join(opt)

        except paramiko.AuthenticationException:
            print("Authentication failed, please check your credentials or key.")
        except paramiko.SSHException as e:
            print(f"SSH connection error: {e}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
        finally:
            ssh.close()'''
