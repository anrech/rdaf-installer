
import json
import os
from abc import ABC
from pathlib import Path

import ansible_runner
from ansible.executor.playbook_executor import PlaybookExecutor
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.inventory.manager import InventoryManager
from ansible.parsing.dataloader import DataLoader
from ansible.playbook.play import Play
from ansible.vars.manager import VariableManager
from driver.context import Context
from driver.platform.platform_driver import PlatformDriver
from models.app import BPA, App
from models.response import Response

from deploy import log_utils

logger = log_utils.setup_logger()


def run_ansible_playbook(inventory_path, playbook_path):
    r = ansible_runner.run(
        inventory=inventory_path,
        playbook=playbook_path,
        extravars={'ansible_user':'root'}
    )
    #Check the status
    if r.rc != 0:
        print("Playbook execution failed")
    else:
        print("Playbook executed successfully")

def run_ansible_playbook_check(inventory_path, playbook_path):
    command = f"ansible-playbook '{playbook_path}' -i '{inventory_path}' --check -u root"
    print("Running ansible playbook in --check mode")
    r = ansible_runner.run_command(
        executable_cmd= command,
    )
    #Check the status
    if r[1] != 0:
        print("Playbook execution failed")
    else:
        print("Playbook executed successfully")

# Path to your inventory file Need to use git submodule
inventory_path = str(Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "inventory" / "bpa_inventory.ini")

# Path to your playbook file Need to use git submodule
playbook_path = str(Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "playbooks" / "bpa-install.yaml")


class BPADriver(ABC):
    _type= 'BPA'
    def __init__(self):
        pass

    def supports(self, app: BPA)-> bool:
        if app is None:
            print("App is None, cannot check type.")
        elif app.type == BPADriver._type:
            return True
        else:
            return False

    def deploy(self, app: BPA, dry_run: bool) -> Response:
        print(f'Deploying via BPA driver....')
        if dry_run:
            if os.path.isfile(inventory_path):
                if os.path.isfile(playbook_path):
                    run_ansible_playbook_check(inventory_path, playbook_path)
                else:
                    logger.error("BPA playbook file is missing, please check path : %s", playbook_path)
                    print("\033[91m[ERROR] BPA playbook file is missing, please check path \033[0m"+ playbook_path)
            else:
                logger.error("BPA inventory file is missing, please check path : %s", inventory_path)
                print("\033[91m[ERROR] BPA inventory file is missing, please check path \033[0m"+ inventory_path)
        else:
            if os.path.isfile(inventory_path):
                if os.path.isfile(playbook_path):
                    run_ansible_playbook(inventory_path, playbook_path)
                else:
                    logger.error("BPA playbook file is missing, please check path : %s", playbook_path)
                    print("\033[91m[ERROR] BPA playbook file is missing, please check path \033[0m"+ playbook_path)
            else:
                logger.error("BPA inventory file is missing, please check path : %s", inventory_path)
                print("\033[91m[ERROR] BPA inventory file is missing, please check path \033[0m"+ inventory_path)
