import ansible_runner
from driver.platform.platform_driver import PlatformDriver
from models.platform import BasePlatform
from models.response import Response

# Path to your inventory file
inventory_path = '/Users/mandnaya/Documents/ansible-rke2/ansible-rke2/inventory.ini'

# Path to your playbook file
playbook_path = '/Users/mandnaya/Documents/ansible-rke2/ansible-rke2/rke-install.yml'


class OpenShiftDriver(PlatformDriver):
    _type= 'OpenShift'
    def __init__(self):
        pass

    def supports(self, platform: BasePlatform)-> bool:
        if platform is None:
            print("Platform is None, cannot check type.")
        elif platform.type == OpenShiftDriver._type:
            return True
        else:
            return False
    def deploy(self, platform: BasePlatform, dry_run: bool) -> Response:
        print(f'Deploying via OpenShift driver : {platform.model_dump_json()}')
