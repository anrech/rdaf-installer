import json
import os

import ansible_runner
from ansible.executor.playbook_executor import PlaybookExecutor
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.inventory.manager import InventoryManager
from ansible.parsing.dataloader import DataLoader
from ansible.playbook.play import Play
from ansible.vars.manager import VariableManager
from driver.platform.platform_driver import PlatformDriver
from models.platform import BasePlatform
from models.response import Response


class VanillaVMDriver(PlatformDriver):
    _type= 'VanillaVM'
    def __init__(self):
        pass

    def supports(self, platform: BasePlatform)-> bool:
        if platform is None:
            print("Platform is None, cannot check type.")
        elif platform.type == VanillaVMDriver._type:
            return True
        else:
            return False
    def deploy(self, platform: BasePlatform, dry_run: bool) -> Response:
        return
