from abc import ABC, abstractmethod

from models.platform import BasePlatform
from models.response import Response


class PlatformDriver(ABC):
    def __init__(self):
        pass

    @abstractmethod
    def supports(self, platform: BasePlatform) -> bool:
        pass

    @abstractmethod
    def deploy(self, platform: BasePlatform, dry_run: bool) -> Response:
        pass
