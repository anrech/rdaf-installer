import json
import os
from pathlib import Path

import ansible_runner
from ansible.executor.playbook_executor import PlaybookExecutor
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.inventory.manager import InventoryManager
from ansible.parsing.dataloader import DataLoader
from ansible.playbook.play import Play
from ansible.vars.manager import VariableManager
from driver.platform.platform_driver import PlatformDriver
from models.platform import BasePlatform
from models.response import Response

from deploy import log_utils

logger = log_utils.setup_logger()


def run_ansible_playbook(inventory_path, playbook_path, become_pass):
    r = ansible_runner.run(
        inventory=inventory_path,
        playbook=playbook_path,
        extravars=extra_vars
    )
    #Check the status
    if r.rc != 0:
        print("Playbook execution failed")
    else:
        print("Playbook executed successfully")

def run_ansible_playbook_check(inventory_path, playbook_path):
    command = f"ansible-playbook '{playbook_path}' -i '{inventory_path}' --check -u root"
    print("Running ansible playbook in --check mode")
    r = ansible_runner.run_command(
        executable_cmd= command,
    )
    #Check the status
    if r[1] != 0:
        print("Playbook execution failed")
    else:
        print("Playbook executed successfully")

# Path to your inventory file Need to use git submodule
inventory_path = str(Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "inventory" / "bpa_inventory.ini") #TODO path to be changed based on user when we take user as input in spec file

# Path to your playbook file Need to use git submodule
playbook_path = str(Path(__file__).resolve().parent.parent.parent.parent / "ansible_playbooks" / "playbooks" / "rke2-install.yml")#TODO path to be changed based on user when we take user as input in spec file

extra_vars = {
    'ansible_become_pass': 'cisco',
    'ansible_user': 'root',
}


class RKEDriver(PlatformDriver):
    _type= 'RKE2'
    def __init__(self):
        pass

    def supports(self, platform: BasePlatform)-> bool:
        if platform is None:
            print("Platform is None, cannot check type.")
        elif platform.type == RKEDriver._type:
            return True
        else:
            return False

    def deploy(self, platform: BasePlatform, dry_run: bool) -> Response:
        print(f'Deploying via RKE driver....')
        if dry_run:
            if os.path.isfile(inventory_path):
                if os.path.isfile(playbook_path):
                    run_ansible_playbook_check(inventory_path, playbook_path)
                else:
                    logger.error("RKE playbook file is missing, please check path : %s", playbook_path)
                    print("\033[91m[ERROR] RKE playbook file is missing, please check path \033[0m"+ playbook_path)
            else:
                logger.error("BPA inventory file is missing, please check path : %s", inventory_path)
                print("\033[91m[ERROR] BPA inventory file is missing, please check path \033[0m"+ inventory_path)
        else:
            if os.path.isfile(inventory_path):
                if os.path.isfile(playbook_path):
                    run_ansible_playbook(inventory_path, playbook_path)
                else:
                    logger.error("RKE playbook file is missing, please check path : %s", playbook_path)
                    print("\033[91m[ERROR] RKE playbook file is missing, please check path \033[0m"+ playbook_path)
            else:
                logger.error("BPA inventory file is missing, please check path : %s", inventory_path)
                print("\033[91m[ERROR] BPA inventory file is missing, please check path \033[0m"+ inventory_path)
