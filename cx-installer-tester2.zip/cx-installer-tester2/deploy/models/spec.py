from typing import List, Union

from models.app import BPA, CNC, NSO, Matrix, Postgres, RDAF
from models.platform import BasePlatform
from pydantic import BaseModel

AppUnion = Union[BPA, CNC, NSO, Matrix, Postgres, RDAF]

# Extend BasePlatform to include apps for each platform
class PlatformSpec(BasePlatform):
    apps: List[AppUnion]

    @classmethod
    def validate_apps(cls, apps):
        """Validate apps using correct subclass based on type."""
        validated = []
        for app in apps:
            app_type = app.get("type")
            if app_type == "BPA":
                validated.append(BPA(**app))
            elif app_type == "CNC":
                validated.append(CNC(**app))
            elif app_type == "NSO":
                validated.append(NSO(**app))
            elif app_type == "Matrix":
                validated.append(Matrix(**app))
            elif app_type == "Postgres":
                validated.append(Postgres(**app))
            elif app_type == "RDAF":
                validated.append(RDAF(**app))
            else:
                raise ValueError(f"Unknown app type: {app_type}")
        return validated

    @classmethod
    def model_validate(cls, data):
        # Ensure apps are validated into proper models
        if "apps" in data:
            data["apps"] = cls.validate_apps(data["apps"])
        return super().model_validate(data)

# Top-level Spec holds all platforms
class Spec(BaseModel):
    platforms: List[PlatformSpec]

    @classmethod
    def model_validate(cls, data):
        data["platforms"] = [PlatformSpec.model_validate(p) for p in data["platforms"]]
        return super().model_validate(data)
