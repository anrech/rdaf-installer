from typing import List, Literal, Optional, Union

from models.app import BPA, CNC, NSO, App, Matrix, Postgres, RDAF
from pydantic import BaseModel


class Credentials(BaseModel):
    user: str
    password: str

class BasePlatform(BaseModel):
    type: str  # Will be used for discriminator
    creds: Credentials
    hosts: List[str]
    jump_server: Optional[str] = None
    registry_server: Optional[str] = None
    vip: Optional[str] = None
    apps: List[Union[BPA, CNC, NSO, Matrix, Postgres, RDAF]]

# RKE2 Platform
class RKE2Platform(BasePlatform):
    type: Literal["RKE2"]

# Vanilla VM Platform
class VanillaVMPlatform(BasePlatform):
    type: Literal["VanillaVM"]
