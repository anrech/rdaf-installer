from typing import List, Literal, Optional

from pydantic import BaseModel


# Base App class
class App(BaseModel):
    name: str
    version: Optional[str] = None

# BPA Advanced Settings
class BPAAdvancedSettings(BaseModel):
    advSetting1: Optional[str] = 'fixed-string1'
    advSetting2: Optional[int] = 99

# BPA Model
class BPA(App):
    type: Literal['BPA']
    purge: bool
    ingress: bool
    registry_url: str
    registry_path: str
    registry_username: str
    registry_password: str
    advancedSettings: Optional[BPAAdvancedSettings] = None

class Credentials(BaseModel):
    user: str
    password: str

class HA(BaseModel):
    ha_enable: bool
    ha_type: str
    hcc_version: str
    hcc_url: str

class LSA(BaseModel):
    lsa_enable: bool
    cfs_nso_address: str
    rfs_nso1_address: str
    rfs_nso2_address: str

class CNC(App):
    type: Literal['CNC']

class NSO(App):
    type: Literal['NSO']
    version: str
    nso_url: str
    nso_download_server_username: str
    nso_download_server_password: str
    HA: HA
    LSA: LSA

# Matrix Advanced Settings
class MatrixAdvancedSettings(BaseModel):
    advSetting1: Optional[str] = 'fixed-string-5'
    advSetting2: Optional[int] = 5

# Matrix Model
class Matrix(App):
    type: Literal['Matrix']
    requiredMatrixSetting1: List[str]
    requiredMatrixSetting2: str
    advancedSettings: Optional[MatrixAdvancedSettings]

# Postgres Advanced Settings
class PostgresAdvancedSettings(BaseModel):
    advSetting1: Optional[str] = 'fixed-string-5'
    advSetting2: Optional[int] = 5

# Postgres Model
class Postgres(App):
    type: Literal['Postgres']
    version: Optional[str] = None
    imageserverip: Optional[str] = None
    user: Optional[str] = None
    absolute_keypath: Optional[str] = None
    directory: Optional[str] = None
    hostname: Optional[str] = None
    port: Optional[int] = None
    username: Optional[str] = None
    password: Optional[str] = None
    image_registry: Optional[str] = None
    advancedSettings: Optional[PostgresAdvancedSettings] = None

#RDAF Model
class RDAF(App):
    type: Literal['RDAF']
    version: str
    rdaf_url: Optional[str] = None
    rdaf_download_server_username: Optional[str] = None
    rdaf_download_server_password: Optional[str] = None
    flavour: Optional[str] = None
    HA: Optional[dict] = None
    mask: Optional[str] = None
    dns: Optional[List[str]] = None
    ntp: Optional[List[str]] = None
    worker_nodes: Optional[dict] = None
    platform_nodes: Optional[dict] = None
    application_nodes: Optional[dict] = None
    infrastructure_nodes: Optional[dict] = None
