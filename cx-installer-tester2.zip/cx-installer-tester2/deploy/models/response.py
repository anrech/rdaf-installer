from enum import Enum

from pydantic import BaseModel


class Resource(BaseModel):
    name: str
    id: str

class StatusEnum(str, Enum):
    ok = 'OK'
    failed = 'FAILED'

class Task(BaseModel):
    name: str
    desc: str
    status: StatusEnum

class Response(BaseModel):
    resources: list[Resource]
    tasks: list[Task]
