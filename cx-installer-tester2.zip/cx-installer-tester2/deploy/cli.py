import copy
import subprocess
import sys
from pathlib import Path

import click
import log_utils
import yaml
from models.spec import Spec

from deploy.deployer_main import Deployer

base_path = Path(__file__).resolve().parents[1]
sys.path.append(str(base_path / "apps" / "bpa" / "src"))
sys.path.append(str(base_path / "apps" / "nso" / "src"))
sys.path.append(str(base_path / "apps" / "rdaf" / "src"))
import bpa_validations as bpa
import nso_validations as nso
import rdaf_validations as rdaf
logger = log_utils.setup_logger()

@click.command()
@click.option("-s", "--spec", required=True, help="Path to spec file")
@click.option("--dry-run", is_flag=True, default=False, help="Perform a dry-run of the deploy")
def deploy(spec, dry_run):
    try:
        with open(spec) as f:
            spec_dict = yaml.safe_load(f)
        # Split spec dict by platform type
        rke2_spec = {
            **spec_dict,
            "platforms": [p for p in spec_dict.get("platforms", []) if p.get("type") == "RKE2"]
        }
        vanilla_vm_spec = {
            **spec_dict,
            "platforms": [p for p in spec_dict.get("platforms", []) if p.get("type") == "VanillaVM"]
        }

        # Validate models separately
        rke2_model = Spec.model_validate(rke2_spec)
        vanilla_vm_model = Spec.model_validate(vanilla_vm_spec)

        if rke2_model.platforms:
            for platform in rke2_model.platforms:
                apps = platform.apps
                for app in apps:
                    if app.name == "BPA":
                        if dry_run:
                            bpa.run_bpa_precheck(spec)
                            print("\033[94m[INFO] Generating BPA dependency.json from spec...\033[0m")
                            logger.info("Generating BPA dependency.json from spec...")
                            bpa.generate_dependency_json(spec)
                            logger.info("Generating BPA yaml file from common spec...")
                            bpa.deploy_commonspec_bpa()
                            bpa.bpa_generate_inventory_and_main_yaml(rke2_model)
                            deployer = Deployer()
                            deployer.deploy(rke2_model, dry_run)
                            logger.info("About to run BPA postcheck")
                            bpa.run_bpa_postcheck(spec)
                        else:
                            bpa.run_bpa_precheck(spec)
                            print("\033[94m[INFO] Generating BPA dependency.json from spec...\033[0m")
                            logger.info("Generating BPA dependency.json from spec...")
                            bpa.generate_dependency_json(spec)
                            logger.info("Generating BPA yaml file from common spec...")
                            bpa.deploy_commonspec_bpa()
                            bpa.bpa_generate_inventory_and_main_yaml(rke2_model)
                            deployer = Deployer()
                            deployer.deploy(rke2_model, dry_run)
                            logger.info("About to run BPA postcheck")
                            bpa.run_bpa_postcheck(spec)

    
        # Run NSO workflows on Vanilla VM spec
        if vanilla_vm_model.platforms:
            for platform in vanilla_vm_model.platforms:
                apps = platform.apps
                for app in apps:
                    if app.name == "NSO":
                        if dry_run:
                            nso.run_nso_precheck(spec)
                            logger.info("Generating NSO yaml file from common spec...")
                            nso.deploy_commonspec_nso()
                            nso.nso_generate_inventory_and_main_yaml(vanilla_vm_model)
                            deployer = Deployer()
                            deployer.deploy(vanilla_vm_model, dry_run)
                            logger.info("About to run NSO postcheck")
                            nso.run_nso_postcheck(spec)
                        else:
                            nso.run_nso_precheck(spec)
                            logger.info("Generating NSO yaml file from common spec...")
                            nso.deploy_commonspec_nso()
                            nso.nso_generate_inventory_and_main_yaml(vanilla_vm_model)
                            deployer = Deployer()
                            deployer.deploy(vanilla_vm_model, dry_run)
                            logger.info("About to run NSO postcheck")
                            nso.run_nso_postcheck(spec)

                    elif app.name == "RDAF":
                        if dry_run:
                          #  rdaf.run_rdaf_precheck(spec)
                            logger.info("Generating RDAF yaml file from common spec...")
                            rdaf.deploy_userspec_rdaf()
                            rdaf.rdaf_generate_inventory_and_main_yaml(vanilla_vm_model)
                            rdaf.generate_rdaf_input_template()
                          #  deployer = Deployer()
                          #  deployer.deploy(vanilla_vm_model, dry_run)
                          #  logger.info("About to run RDAF postcheck")
                          #  rdaf.run_rdaf_postcheck(spec)
                        else:
                          #  rdaf.run_rdaf_precheck(spec)
                            logger.info("Generating RDAF yaml file from common spec...")
                            rdaf.deploy_userspec_rdaf()
                            rdaf.rdaf_generate_inventory_and_main_yaml(vanilla_vm_model)
                            deployer = Deployer()
                            deployer.deploy(vanilla_vm_model, dry_run)
                            logger.info("About to run RDAF postcheck")
                            rdaf.run_rdaf_postcheck(spec)

    except IOError as e:
        print(f"\033[91m[ERROR] An error occurred while reading the spec: {e}\033[0m")
        logger.error("I/O error occurred while reading the spec.")

if __name__ == '__main__':
    deploy()
