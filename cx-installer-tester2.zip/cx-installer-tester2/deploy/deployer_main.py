import argparse
import json
import os
import subprocess

from driver.apps.app_bpa_driver import BPADriver
from driver.apps.app_cnc_driver import CNCDriver
from driver.apps.app_driver import AppDriver
from driver.apps.app_matrix_driver import MatrixAppDriver
from driver.apps.app_nso_driver import NSODriver
from driver.apps.app_postgres_driver import PostgresAppDriver
from driver.apps.app_rdaf_driver import RDAFAppDriver
from driver.platform.openshift_driver import OpenShiftDriver
from driver.platform.platform_driver import PlatformDriver
from driver.platform.rke_driver import RKEDriver
from driver.platform.vanillavm_driver import VanillaVMDriver
from models.app import App
from models.platform import BasePlatform
from models.response import Response
from models.spec import Spec


class Deployer:
    def __init__(self):
        self.platform_drivers = self.load_platform_drivers()
        self.app_drivers = self.load_app_drivers()

    def load_platform_drivers(self):
        return [RKEDriver(),VanillaVMDriver(),OpenShiftDriver()]

    def load_app_drivers(self):
        return [BPADriver(), CNCDriver(), NSODriver(), MatrixAppDriver(), PostgresAppDriver(), RDAFAppDriver()]

    def get_platform_driver(self, platform_spec: BasePlatform) -> PlatformDriver:
        for driver in self.platform_drivers:
            if driver.supports(platform_spec):
                return driver

    def get_app_driver(self, app_spec:App) -> AppDriver:
        for driver in self.app_drivers:
            if driver.supports(app_spec):
                return driver

    def deploy(self, spec: Spec, dry_run: bool) -> Response:
        responses = []
        for platform_spec in spec.platforms:
            platform_driver = self.get_platform_driver(platform_spec)
            if platform_driver is None:
                raise NotImplementedError(f"Unsupported platform type {platform_spec.type}")
            # Deploy platform itself once (if needed)
            result = platform_driver.deploy(platform_spec, dry_run=dry_run)
            responses.append(result)
            for app_spec in platform_spec.apps:
                app_driver = self.get_app_driver(app_spec)
                if app_driver is None:
                    raise NotImplementedError(f"Unsupported app: {app_spec.name}")
                result = app_driver.deploy(app_spec, dry_run=dry_run)
                responses.append(result)

            return responses
