# Validation Control Configuration

## Configuration Structure

The validation configuration is stored in `validation_checks/validation_policies/default.yaml`:

```yaml
critical: []
default_critical: false
non_critical: ["*"]

validation_control:
  global_enabled: true              # Master switch for all validation

  app_controls:
    bpa:                           # App-specific controls
      enabled: true                # Enable/disable all BPA checks
      stage_controls:
        pre: true                  # Enable/disable BPA pre-checks
        post: true                 # Enable/disable BPA post-checks
      check_controls:
        check_smtp: false          # Disable specific SMTP check
        check_dns: true            # Enable specific DNS check
        hw_disk_home: false        # Disable /home disk check
        # ... other checks default to true

    nso:
      enabled: true
      stage_controls:
        pre: true
        post: false                # Disable all NSO post-checks
      check_controls:
        cpu_check: false           # Disable specific check
        ant_version_check: false   # Disable ANT version check
        # ... other checks default to true
```

## Control Hierarchy

The framework follows this hierarchy (most specific setting wins):

1. **Global** (`global_enabled: false`) → All checks disabled
2. **App** (`app_controls.{app}.enabled: false`) → All checks for that app disabled
3. **Stage** (`stage_controls.{stage}: false`) → All checks for that app/stage disabled
4. **Check** (`check_controls.{check_name}: false`) → Specific check disabled

**Default Behavior**: All checks are enabled unless explicitly disabled.

## Auto-Discovery System

### Management Commands

All commands should be run from the `validation_checks/` directory:

```bash
cd validation_checks

# List all discovered validation checks
make list-validation-checks

# Update configuration with newly discovered checks
make update-validation-config

# Check if configuration is up-to-date
make check-validation-config

# Validate configuration file syntax
make validate-validation-config
```

### Auto-Discovery Script

The `generate_validation_config.py` script provides several modes:

```bash
# List all discovered checks without generating config
python3 generate_validation_config.py --list

# Generate/update configuration (preserves existing settings)
python3 generate_validation_config.py -v

# Generate fresh configuration (overwrites existing settings)
python3 generate_validation_config.py --fresh

# Validate existing configuration
python3 generate_validation_config.py --validate
```

### How Auto-Discovery Works

1. **Imports all validation check modules** from `validation_checks/checks/`
2. **Inspects the CHECK_REGISTRY** to find registered checks using `@check_for()` decorator
3. **Generates configuration entries** for discovered checks
4. **Preserves existing manual settings** during updates
5. **Adds new checks as enabled** by default

## Configuration Validation

The framework includes validation to ensure configuration files are well-formed:

```bash
cd validation_checks
make validate-validation-config
```

This checks:
- YAML syntax validity
- Required structure presence
- Data type correctness

## Integration with CI/CD

Add this to your CI pipeline to ensure configurations stay up-to-date:

```yaml
- name: Check validation configuration
  working-directory: validation_checks
  run: make check-validation-config
```

This will fail the build if new checks have been added but not included in the configuration.
