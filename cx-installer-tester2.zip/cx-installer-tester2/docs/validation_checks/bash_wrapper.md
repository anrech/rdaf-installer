# Validation Checks Bash Wrapper

The `run_validation.sh` bash script provides a user-friendly interface for running validation checks in the CX Installer platform. This wrapper simplifies the process of executing validation checks by providing colored output, error handling, and various execution modes.

## Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [Command Reference](#command-reference)
- [Examples](#examples)
- [Advanced Usage](#advanced-usage)
- [Configuration](#configuration)
- [Troubleshooting](#troubleshooting)

## Installation

### Prerequisites

Before using the bash wrapper, ensure you have:
- Python 3.6 or higher installed
- Required Python packages (see `requirements.txt`)
- Proper permissions to execute scripts

### Install the Wrapper

1. Navigate to the validation checks directory:
   ```bash
   cd validation_checks
   ```

2. Install the wrapper using Make:
   ```bash
   make install-wrapper
   ```

3. Verify installation:
   ```bash
   ./run_validation.sh help
   ```

The script will automatically check for prerequisites and guide you through any missing dependencies.

## Quick Start

### Basic Usage Pattern

```bash
./run_validation.sh <command> [options]
```

### Common Commands

```bash
# Run pre-install checks for NSO
./run_validation.sh pre nso

# Run post-install checks for BPA
./run_validation.sh post bpa

# List all available validation checks
./run_validation.sh list

# Check configuration status
./run_validation.sh config

# View recent log files
./run_validation.sh logs
```

## Command Reference

### Primary Commands

| Command | Description | Usage |
|---------|-------------|-------|
| `pre` | Run pre-install validation checks | `./run_validation.sh pre <app>` |
| `post` | Run post-install validation checks | `./run_validation.sh post <app>` |
| `list` | List all available validation checks | `./run_validation.sh list [app]` |
| `config` | Show configuration status and files | `./run_validation.sh config` |
| `logs` | Display recent validation log files | `./run_validation.sh logs [count]` |
| `help` | Show detailed help information | `./run_validation.sh help [command]` |

### Supported Applications

- `nso` - Network Services Orchestrator
- `bpa` - Business Process Automation
- `all` - Run checks for all applications (where applicable)

### Global Options

| Option | Description | Example |
|--------|-------------|---------|
| `--dry-run` | Preview commands without execution | `./run_validation.sh pre nso --dry-run` |
| `--jira-mode` | Enable JIRA ticket creation | `./run_validation.sh pre nso --jira-mode` |
| `--verbose` | Enable detailed logging | `./run_validation.sh pre nso --verbose` |
| `--no-color` | Disable colored output | `./run_validation.sh pre nso --no-color` |
| `--policy <file>` | Use custom policy file | `./run_validation.sh pre nso --policy custom.yaml` |
| `--spec <file>` | Use specific deployment spec | `./run_validation.sh pre nso --spec myapp.yaml` |

## Examples

### Basic Validation Checks

```bash
# Run NSO pre-install checks with default configuration
./run_validation.sh pre nso

# Run BPA post-install checks with verbose output
./run_validation.sh post bpa --verbose

# Preview what NSO pre-install checks would run
./run_validation.sh pre nso --dry-run
```

### Advanced Usage

```bash
# Run checks with JIRA ticket creation enabled
./run_validation.sh pre nso --jira-mode

# Use a custom policy file
./run_validation.sh pre nso --policy /path/to/custom-policy.yaml

# Run checks with specific deployment spec
./run_validation.sh pre nso --spec /path/to/deployment-spec.yaml

# Combine multiple options
./run_validation.sh pre nso --verbose --jira-mode --dry-run
```

### Information and Diagnostics

```bash
# List all NSO validation checks
./run_validation.sh list nso

# Show configuration status
./run_validation.sh config

# View the last 5 log files
./run_validation.sh logs 5

# Get help for a specific command
./run_validation.sh help pre
```

## Advanced Usage

### Environment Configuration

The wrapper respects several environment variables:

```bash
# Disable colored output globally
export NO_COLOR=1

# Set default verbosity
export VALIDATION_VERBOSE=1

# Set default JIRA mode
export VALIDATION_JIRA_MODE=1
```

### Custom Deployment Specs

When no `--spec` option is provided, the wrapper looks for deployment specs in this order:

1. `test_spec.yaml` in the project root
2. `../test_spec.yaml` (parent directory)
3. Environment variable `DEFAULT_SPEC_FILE`

```bash
# Set a default spec file
export DEFAULT_SPEC_FILE=/path/to/your/default-spec.yaml
./run_validation.sh pre nso
```

### Policy File Management

Default policy files are located in `../validation_policies/`. You can:

```bash
# Use a different policy file
./run_validation.sh pre nso --policy ../validation_policies/production.yaml

# Check current policy configuration
./run_validation.sh config
```

### Integration with Make

The wrapper integrates with the project's Makefile:

```bash
# Install the wrapper
make install-wrapper

# Show wrapper usage
make help-wrapper

# Update validation configuration
make update-validation-config

# Run all tests
make test-all
```

## Configuration

### Validation Policies

Validation behavior is controlled by YAML policy files in `../validation_policies/`:

```yaml
# Example policy configuration
validation_control:
  global_enabled: true
  app_controls:
    nso:
      enabled: true
      stage_controls:
        pre:
          enabled: true
          check_controls:
            disk_space_check: true
            memory_check: false
        post: true
```

### JIRA Integration

Configure JIRA integration through `../integrations/jira_config.env`:

```bash
JIRA_URL=https://your-jira.company.com
JIRA_TOKEN=your-api-token
JIRA_PROJECT=PROJ
TICKET_MODE=individual  # or 'consolidated'
ENABLE_JIRA_PRE=true
ENABLE_JIRA_POST=true
```

### Logging Configuration

The wrapper creates logs in `check_logs/` directory:
- `validation_checks.log` - Main validation log
- `validation_reports.log` - Detailed reporting log
- `wrapper.log` - Bash wrapper activity log

## Troubleshooting

### Common Issues

#### Permission Denied
```bash
# Make the script executable
chmod +x run_validation.sh
```

#### Missing Dependencies
```bash
# Install required Python packages
pip install -r requirements.txt

# Or use the project's setup
make install-deps  # if available
```

#### Spec File Not Found
```bash
# Specify the spec file explicitly
./run_validation.sh pre nso --spec /path/to/your/spec.yaml

# Or set environment variable
export DEFAULT_SPEC_FILE=/path/to/your/spec.yaml
```

#### No Checks Found
```bash
# Update validation configuration
make update-validation-config

# List available checks
./run_validation.sh list
```

### Debug Mode

Enable detailed debugging:

```bash
# Run with maximum verbosity
./run_validation.sh pre nso --verbose

# Check wrapper logs
tail -f check_logs/wrapper.log

# Verify configuration
./run_validation.sh config
```

### Environment Issues

```bash
# Check Python environment
python3 --version
python3 -c "import yaml; print('YAML OK')"

# Verify project structure
ls -la validation_checks/
ls -la validation_policies/
```

## Output Interpretation

### Success Indicators
- ✅ **Green checkmarks**: Successful operations
- 🔍 **Blue info symbols**: Informational messages
- ⚡ **Lightning bolts**: Quick operations

### Warning and Error Indicators
- ❌ **Red X marks**: Failures or errors
- ⚠️  **Warning triangles**: Non-critical issues
- 🔧 **Tools**: Configuration suggestions

### Status Messages
```
✅ Prerequisites check passed
🔍 Found 15 validation checks for nso/pre
⚡ Running validation checks...
▶ nso.pre.disk_space_check … OK
▶ nso.pre.memory_check … FAIL (non-critical)
    Reason: Available memory below recommended threshold
❌ Critical check failed: nso.pre.connectivity_check
📋 JIRA ticket created: PROJ-123
```

## Best Practices

### Development Workflow
1. Use `--dry-run` to preview changes
2. Test with `--verbose` for detailed output
3. Use `list` command to discover available checks
4. Check configuration with `config` command before major runs

### Production Usage
1. Always run pre-install checks before deployment
2. Enable JIRA integration for issue tracking
3. Use custom policy files for environment-specific rules
4. Monitor logs in `check_logs/` directory

### Maintenance
1. Regularly update validation configuration with `make update-validation-config`
2. Review and update policy files as requirements change
3. Monitor JIRA tickets for recurring validation failures
4. Clean up old log files periodically

## Integration Examples

### CI/CD Pipeline Integration

```bash
#!/bin/bash
# Example CI/CD integration
cd validation_checks

# Run pre-deployment checks
if ! ./run_validation.sh pre nso --jira-mode; then
    echo "Pre-deployment validation failed"
    exit 1
fi

# Deploy application here...

# Run post-deployment checks
if ! ./run_validation.sh post nso --jira-mode; then
    echo "Post-deployment validation failed"
    exit 1
fi

echo "Deployment validation completed successfully"
```

### Automated Reporting

```bash
#!/bin/bash
# Generate validation report
cd validation_checks

./run_validation.sh config > validation-report.txt
./run_validation.sh list >> validation-report.txt
./run_validation.sh logs 3 >> validation-report.txt

echo "Validation report generated: validation-report.txt"
```

## Support

For issues with the bash wrapper:

1. Check the troubleshooting section above
2. Review logs in `check_logs/wrapper.log`
3. Run `./run_validation.sh config` to verify setup
4. Use `--dry-run --verbose` to debug command execution

For validation check issues:
1. Review the main validation documentation
2. Check policy configuration in `../validation_policies/`
3. Verify JIRA configuration in `../integrations/jira_config.env`

---

*This documentation covers version 1.0 of the bash wrapper. For the latest updates and features, run `./run_validation.sh help` or check the project's main documentation.*
