# Development Guide

## Adding New Validation Checks

### 1. Write Your Check Function

Add your check function with the `@check_for()` decorator in the appropriate module:

```python
# Example: validation_checks/checks/app/bpa/bpa_precheck.py
from validation_checks.check_core import check_for, Result

@check_for("bpa", "pre")
def check_new_requirement(spec):
    """
    Check a new requirement for BPA pre-deployment
    """
    try:
        # Your validation logic here
        if some_condition:
            return Result("bpa.pre.check_new_requirement", True, "Check passed")
        else:
            return Result("bpa.pre.check_new_requirement", False, "Check failed: reason")
    except Exception as e:
        return Result("bpa.pre.check_new_requirement", False, f"Error: {str(e)}")
```

### 2. Update Configuration

Update the configuration to include your new check:

```bash
cd validation_checks
make update-validation-config
```

This automatically:
- Discovers your new check
- Adds it to the configuration with `enabled: true`
- Preserves existing settings

### 3. Review and Customize

Review the updated configuration in `validation_policies/default.yaml`:

```yaml
validation_control:
  app_controls:
    bpa:
      check_controls:
        check_new_requirement: true  # Your new check (auto-added)
        # ... other existing checks
```

Optionally disable the check if needed:
```yaml
        check_new_requirement: false  # Disable if problematic
```

### 4. Test Your Changes

Run the validation control tests:
```bash
cd validation_checks
make test-validation-control
```

Test your specific check:
```bash
cd ..
python3 validation_checks/run_validation_checks.py -t pre -s your_test_spec.yaml
```

### 5. Validate Configuration

Ensure your configuration is valid:
```bash
cd validation_checks
make validate-validation-config
```

### 6. Commit Changes

Commit both your new check code and the updated configuration:
```bash
git add validation_checks/checks/app/bpa/bpa_precheck.py
git add validation_checks/validation_policies/default.yaml
git commit -m "Add new BPA requirement check"
```

## Check Function Best Practices

### Return Result Objects
Always return `Result` objects with consistent structure:

```python
# Success
return Result(check_id, True, "Descriptive success message")

# Failure
return Result(check_id, False, "Clear failure reason with remediation steps")

# Error
return Result(check_id, False, f"Error during check: {str(exception)}")
```

### Include Host Information
If your check runs on specific hosts, include host information:

```python
result = Result(check_id, False, "Check failed")
result.host = "server1.example.com"  # For JIRA ticket creation
return result
```

### Add Extra Metadata
Include additional context for debugging:

```python
result = Result(check_id, False, "CPU usage too high")
result.extra = {"cpu_percent": 95, "threshold": 80, "cores": 4}
return result
```

### Error Handling
Wrap your check logic in try-catch blocks:

```python
@check_for("app", "stage")
def my_check(spec):
    try:
        # Check logic here
        pass
    except Exception as e:
        return Result("app.stage.my_check", False, f"Unexpected error: {str(e)}")
```

## Testing Framework

### Validation Control Tests
Test the control framework itself:
```bash
cd validation_checks
make test-validation-control
```

### JIRA Integration Tests
Test JIRA ticket creation:
```bash
cd validation_checks
make test-jira-modes
```

### Custom Test Creation
Create custom tests for your checks:

```python
#!/usr/bin/env python3
"""Test script for my custom checks"""

import sys
from pathlib import Path

# Add project to path
ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from validation_checks.checks.app.bpa.bpa_precheck import check_new_requirement

def test_my_check():
    # Create test spec
    test_spec = {
        "platforms": [
            {
                "apps": [
                    {"type": "bpa"}
                ]
            }
        ]
    }

    # Run check
    result = check_new_requirement(test_spec)

    # Verify result
    assert result.success == True, f"Check failed: {result.message}"
    print("✅ Custom check test passed")

if __name__ == "__main__":
    test_my_check()
```

## Workflow Integration

### Development Workflow

1. **Write check** → Add function with `@check_for()` decorator
2. **Update config** → `make update-validation-config`
3. **Customize** → Edit `validation_policies/default.yaml` if needed
4. **Test** → `make test-validation-control`
5. **Validate** → `make validate-validation-config`
6. **Commit** → Both code and config changes

### CI/CD Integration

Add to your pipeline:

```yaml
- name: Check validation configuration is current
  working-directory: validation_checks
  run: make check-validation-config

- name: Run validation control tests
  working-directory: validation_checks
  run: make test-validation-control

- name: Test JIRA integration
  working-directory: validation_checks
  run: make test-jira-modes
```

## Directory Structure

```
validation_checks/
├── checks/
│   ├── app/
│   │   ├── bpa/
│   │   │   ├── bpa_precheck.py      # BPA pre-deployment checks
│   │   │   └── bpa_postcheck.py     # BPA post-deployment checks
│   │   └── nso/
│   │       ├── nso_precheck.py      # NSO pre-deployment checks
│   │       └── nso_postcheck.py     # NSO post-deployment checks
│   └── common/
│       ├── common_checks.py         # Shared validation logic
│       └── ssh_utils.py             # SSH utilities
├── validation_policies/
│   ├── default.yaml                 # Main configuration
│   └── example_config.yaml          # Example configurations
├── tests/
│   ├── test_validation_control.py   # Control framework tests
│   ├── test_jira_modes.py          # JIRA integration tests
│   └── test_enhanced_reporting.py  # Reporting system tests
├── check_core.py                    # Core registration system
├── run_validation_checks.py         # Main validation runner
├── generate_validation_config.py    # Auto-discovery script
└── Makefile                        # Management targets
```

## Check Registration System

The framework uses a decorator-based registration system:

```python
# In check_core.py
CHECK_REGISTRY: Dict[str, Dict[str, List[Callable]]] = {}

def check_for(app: str, stage: str):
    """Decorator to register a check for an app and stage"""
    def decorator(func):
        # Register function in CHECK_REGISTRY
        return func
    return decorator
```

When you use `@check_for("bpa", "pre")`, your function is automatically registered and will be discovered by the auto-discovery system.

## Test Suite

The validation framework includes a comprehensive test suite located in `validation_checks/tests/`:

### Available Tests

```bash
cd validation_checks

# Individual test categories
make test-validation-control     # Test validation enable/disable functionality
make test-jira-modes            # Test JIRA integration modes
make test-enhanced-reporting    # Test detailed logging and reporting

# Run all tests
make test-all                   # Complete test suite
```

### Test Structure

```
validation_checks/tests/
├── __init__.py                     # Test package initialization
├── test_validation_control.py      # Control system tests
├── test_jira_modes.py              # JIRA integration tests
└── test_enhanced_reporting.py      # Reporting system tests
```

### Writing New Tests

When creating new test files in `tests/`, use this template:

```python
#!/usr/bin/env python3
"""Test script for [your feature]"""

import sys
import os
from pathlib import Path

# Add project root to path
ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

def test_your_feature():
    """Test your feature functionality."""
    # Change to validation_checks directory for proper module imports
    original_cwd = os.getcwd()
    validation_checks_dir = Path(__file__).parent.parent
    os.chdir(validation_checks_dir)

    # Add current directory to Python path for direct imports
    if str(validation_checks_dir) not in sys.path:
        sys.path.insert(0, str(validation_checks_dir))

    try:
        # Your test logic here
        print("✅ Test passed")
    except Exception as e:
        print(f"❌ Test failed: {e}")
    finally:
        os.chdir(original_cwd)  # Restore original directory

if __name__ == "__main__":
    test_your_feature()
```

### Adding Tests to Makefile

Add new test targets to `validation_checks/Makefile`:

```makefile
.PHONY: test-your-feature
test-your-feature:
	@echo "Testing your feature..."
	python3 tests/test_your_feature.py
```
