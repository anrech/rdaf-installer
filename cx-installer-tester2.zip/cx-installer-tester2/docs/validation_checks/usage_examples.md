# Usage Examples

## Common Configuration Scenarios

### 1. Disable All Validation Globally
```yaml
validation_control:
  global_enabled: false
```

**Use Case:** Temporarily disable all validation during development or testing.

### 2. Disable All Checks for an App
```yaml
validation_control:
  app_controls:
    nso:
      enabled: false  # All NSO checks skipped
```

**Use Case:** Skip NSO validation when NSO is not part of the deployment.

### 3. Disable All Post-Deployment Checks for an App
```yaml
validation_control:
  app_controls:
    bpa:
      stage_controls:
        post: false  # All BPA post-checks skipped
```

**Use Case:** Skip post-deployment validation during development phases.

### 4. Disable Specific Problematic Checks
```yaml
validation_control:
  app_controls:
    bpa:
      check_controls:
        check_smtp: false          # Skip SMTP check if not configured
        hw_disk_home: false        # Skip /home disk check if not relevant
    nso:
      check_controls:
        ant_version_check: false   # Skip ANT check if not needed
```

**Use Case:** Disable known problematic checks in specific environments.

### 5. Environment-Specific Configuration

**Development Environment:**
```yaml
validation_control:
  global_enabled: true
  app_controls:
    bpa:
      enabled: true
      stage_controls:
        pre: true
        post: false    # Skip post-checks in dev
      check_controls:
        check_smtp: false    # No SMTP in dev
        hw_disk_home: false  # Relaxed disk requirements
    nso:
      enabled: false   # No NSO in dev environment
```

**Production Environment:**
```yaml
validation_control:
  global_enabled: true
  app_controls:
    bpa:
      enabled: true
      stage_controls:
        pre: true
        post: true     # Full validation in prod
      check_controls:
        # All checks enabled (default)
    nso:
      enabled: true
      stage_controls:
        pre: true
        post: true
      check_controls:
        # All checks enabled
```

### 6. Gradual Check Rollout
```yaml
validation_control:
  app_controls:
    bpa:
      check_controls:
        # Stable checks - enabled
        check_dns: true
        check_ntp: true
        hw_cpu: true
        hw_memory: true

        # New/experimental checks - disabled initially
        check_new_feature: false
        experimental_check: false
```

**Use Case:** Gradually enable new checks as they stabilize.

## JIRA Configuration Examples

### Individual Tickets (Default)
```bash
# integrations/jira_config.env
JIRA_URL=https://jira.company.com
JIRA_USER=automation@company.com
JIRA_TOKEN=your-token-here
PROJECT_KEY=PLATFORM
ENABLE_JIRA_PRE=true
ENABLE_JIRA_POST=true
JIRA_TICKET_MODE=individual
```

**Result:** Each failed check creates a separate JIRA ticket.

### Consolidated Tickets
```bash
# integrations/jira_config.env
JIRA_TICKET_MODE=consolidated
```

**Result:** All failures in a validation run create one consolidated ticket.

### Stage-Specific JIRA
```bash
# Only create tickets for pre-deployment failures
ENABLE_JIRA_PRE=true
ENABLE_JIRA_POST=false
JIRA_TICKET_MODE=individual
```

## Running Validation Examples

### Basic Validation Run
```bash
cd /path/to/cx-installer
python3 validation_checks/run_validation_checks.py -t pre -s spec.yaml
```

### With Custom Policy
```bash
python3 validation_checks/run_validation_checks.py \
  -t pre \
  -s spec.yaml \
  -p validation_checks/validation_policies/custom_policy.yaml
```

### Validation Output Examples

**With Individual JIRA Mode:**
```
▶ bpa.pre.check_dns … OK
▶ bpa.pre.check_ntp … FAIL (non-critical)
    Reason: NTP synchronization failed
    JIRA ticket created: PLATFORM-123 (https://jira.company.com/browse/PLATFORM-123)
▶ bpa.pre.check_smtp … SKIPPED (disabled in configuration)
▶ bpa.pre.hw_cpu … OK
```

**With Consolidated JIRA Mode:**
```
▶ bpa.pre.check_dns … OK
▶ bpa.pre.check_ntp … FAIL (non-critical)
    Reason: NTP synchronization failed
▶ nso.pre.cpu_check … FAIL (non-critical)
    Reason: CPU usage too high: 95%

📋 Consolidated JIRA ticket created: PLATFORM-456 (https://jira.company.com/browse/PLATFORM-456)
    Contains 2 validation failures
```

## Management Commands Examples

### Discovery and Configuration
```bash
cd validation_checks

# See what checks are available
make list-validation-checks

# Update config with new checks
make update-validation-config

# Check if config is current
make check-validation-config

# Validate config syntax
make validate-validation-config
```

### Testing
```bash
# Test validation control
make test-validation-control

# Test JIRA integration
make test-jira-modes

# Test enhanced reporting
make test-enhanced-reporting

# Get help
make help-validation
```

## Log File Analysis

### Understanding Log Output

The validation framework generates comprehensive log files for detailed analysis:

1. **`validation_checks/check_logs/validation_checks.log`** - General framework logging
2. **`validation_checks/check_logs/validation_reports.log`** - Detailed validation reports with comprehensive execution details

**Report Log Structure:**
```
================================================================================
VALIDATION CHECKS RUN STARTED
================================================================================
Start Time: 2025-07-23 22:22:19
Stage: pre
Apps: bpa, nso
Specification File: /path/to/spec.yaml
Policy File: /path/to/policy.yaml
================================================================================
POLICY CONFIGURATION:
  Default Critical Setting: False
  Explicitly Critical Checks: 0
  Global Validation Enabled: True
  App-Specific Controls:
    bpa: enabled=True
      pre: enabled=True
      post: enabled=True
--------------------------------------------------------------------------------
CHECK DISCOVERY RESULTS:
  Total Checks Found: 26
  Checks to Execute: 24
  Checks Skipped: 2
  Checks to Execute:
    - bpa.pre.check_ntp
    - bpa.pre.check_dns
    ...
  Skipped Checks:
    - bpa.pre.disabled_check
    - nso.pre.another_disabled_check
--------------------------------------------------------------------------------
CHECK RESULT: bpa.pre.check_ntp - FAILED (NON-CRITICAL) [0.12s]
  Message: NTP service not running
  Requirement: NTP service must be active
  Observed: inactive (dead)
  Remediation: Run 'systemctl start ntp'
  Host: 192.168.1.100
  Command Output:
    systemctl status ntp
    ● ntp.service - Network Time Protocol
       Loaded: loaded (/lib/systemd/system/ntp.service; enabled; vendor preset: enabled)
       Active: inactive (dead)
...
JIRA ACTIVITY: Individual Ticket Created
  Check: bpa.pre.check_ntp, Ticket: DEV-123
...
================================================================================
VALIDATION CHECKS RUN SUMMARY
================================================================================
End Time: 2025-07-23 22:22:45
Total Duration: 0:00:23.456789
Overall Result: FAILURE

STATISTICS:
  Total Checks: 26
  Executed: 24
  Skipped: 2
  Passed: 21
  Failed: 3
    - Critical Failures: 0
    - Non-Critical Failures: 3

FAILURE DETAILS:
  Failure 1: bpa.pre.check_ntp
    Message: NTP service not running
    Host: 192.168.1.100
...
================================================================================
VALIDATION CHECKS RUN COMPLETED
================================================================================
Average check execution time: 0.98 seconds
```

### Analyzing Log Files

**Quick analysis commands:**
```bash
# View recent validation runs
tail -n 100 validation_checks/check_logs/validation_reports.log

# Count failures by type
grep "FAILED (CRITICAL)" validation_checks/check_logs/validation_reports.log | wc -l
grep "FAILED (NON-CRITICAL)" validation_checks/check_logs/validation_reports.log | wc -l

# Find specific check results
grep "CHECK RESULT.*your_check_name" validation_checks/check_logs/validation_reports.log

# View run summaries only
grep -A 20 "VALIDATION CHECKS RUN SUMMARY" validation_checks/check_logs/validation_reports.log

# Check JIRA ticket activity
grep "JIRA ACTIVITY" validation_checks/check_logs/validation_reports.log

# Find execution time patterns
grep "\[.*s\]" validation_checks/check_logs/validation_reports.log

# View policy configurations
grep -A 10 "POLICY CONFIGURATION" validation_checks/check_logs/validation_reports.log
```

### Log File Benefits

1. **Complete Audit Trail:** Every validation run is fully documented
2. **Performance Analysis:** Execution times for each check
3. **Configuration Tracking:** Policy settings recorded with each run
4. **Failure Analysis:** Detailed failure information including commands and outputs
5. **JIRA Integration Tracking:** Complete record of ticket creation activities
6. **Troubleshooting Support:** Full context for debugging issues

## Real-World Scenarios

### Scenario 1: New Environment Setup
1. **Initial state:** Fresh environment, some checks may fail
2. **Action:** Disable problematic checks temporarily
3. **Configuration:**
   ```yaml
   validation_control:
     app_controls:
       bpa:
         check_controls:
           check_smtp: false      # SMTP not configured yet
           hw_disk_home: false    # Custom disk layout
   ```
4. **Outcome:** Validation passes, allowing deployment to proceed

### Scenario 2: Check Development
1. **Initial state:** Developing new validation check
2. **Action:** Add check but keep disabled until tested
3. **Configuration:**
   ```yaml
   validation_control:
     app_controls:
       bpa:
         check_controls:
           check_new_feature: false  # Disable until stable
   ```
4. **Testing:** Enable manually for specific test runs
5. **Rollout:** Enable once proven stable

### Scenario 3: Production Issue
1. **Problem:** Specific check causing false positives in production
2. **Immediate action:** Disable problematic check
3. **Configuration:**
   ```yaml
   validation_control:
     app_controls:
       nso:
         check_controls:
           problematic_check: false  # Temporary disable
   ```
4. **Long-term:** Fix check and re-enable

### Scenario 4: JIRA Ticket Management
1. **Problem:** Too many individual JIRA tickets overwhelming team
2. **Solution:** Switch to consolidated mode
3. **Configuration:**
   ```bash
   # In jira_config.env
   JIRA_TICKET_MODE=consolidated
   ```
4. **Result:** One ticket per validation run with all failures summarized
