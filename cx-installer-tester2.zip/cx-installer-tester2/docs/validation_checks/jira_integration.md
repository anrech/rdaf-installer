# JIRA Integration

## Overview

The framework supports flexible JIRA ticket creation with two modes: individual tickets per failure or consolidated tickets containing all failures from a validation run.

## Configuration

JIRA settings are configured in `integrations/jira_config.env`:

```bash
# Basic JIRA settings
JIRA_URL=https://your-jira-instance.com
JIRA_USER=your-user@company.com
JIRA_TOKEN=your-api-token
PROJECT_KEY=YOUR_PROJECT
AUTH_STYLE=bearer

# Enable/disable for different stages
ENABLE_JIRA_PRE=true    # Enable for pre-deployment checks
ENABLE_JIRA_POST=true   # Enable for post-deployment checks

# Ticket creation mode
JIRA_TICKET_MODE=individual  # or "consolidated"
```

## Ticket Creation Modes

### Individual Mode (Default)
```bash
JIRA_TICKET_MODE=individual
```

**Benefits:**
- ✅ Creates one JIRA ticket per failed validation check
- ✅ Detailed individual failure information
- ✅ Easy to track and fix specific issues
- ✅ Clear assignment of individual checks to team members
- ✅ Preserves existing behavior (backward compatible)

**Example Individual Ticket:**
```
[bpa.pre.check_dns] DNS resolution failed for example.com

Check ID: bpa.pre.check_dns
Stage: pre
Host: server1.example.com

DNS resolution failed for example.com
Timeout after 30 seconds
```

### Consolidated Mode
```bash
JIRA_TICKET_MODE=consolidated
```

**Benefits:**
- ✅ Creates one JIRA ticket for all failures in a validation run
- ✅ Reduces JIRA ticket spam
- ✅ Provides both summary and detailed failure information
- ✅ Good for getting an overview of validation run results
- ✅ Includes failure count and organized sections

**Example Consolidated Ticket:**
```
[PRE] 3 Validation Check Failures

Stage: pre
Total Failures: 3
Timestamp: 2025-07-23 20:30:15

## Failed Checks Summary
1. bpa.pre.check_dns: DNS resolution failed for example.com
2. bpa.pre.check_ntp: NTP synchronization failed
3. nso.pre.cpu_check: CPU usage too high: 95%

## Detailed Failure Information

### 1. bpa.pre.check_dns
Host: server1.example.com

DNS resolution failed for example.com
Timeout after 30 seconds

### 2. bpa.pre.check_ntp
Host: server2.example.com

NTP synchronization failed
Time drift detected: 120 seconds

### 3. nso.pre.cpu_check
Host: nso-host.example.com

CPU usage too high: 95%

Extra Info:
cores: 4
load_avg: 3.8
```

## Mode Comparison

| Feature | Individual Mode | Consolidated Mode |
|---------|----------------|-------------------|
| Tickets Created | One per failure | One per validation run |
| Ticket Spam | Higher | Lower |
| Detail Level | Full per check | Summary + full details |
| Issue Tracking | Easy per check | Overview oriented |
| Default | ✅ Yes | No |
| Use Case | Detailed issue tracking | Validation run overview |

## Testing JIRA Integration

```bash
cd validation_checks
make test-jira-modes
```

This test script:
- ✅ Verifies current JIRA configuration
- ✅ Tests mode detection
- ✅ Provides configuration guidance
- ✅ Shows sample ticket structures

## Switching Between Modes

**To switch to consolidated mode:**
```bash
# Edit integrations/jira_config.env
JIRA_TICKET_MODE=consolidated
```

**To switch back to individual mode:**
```bash
# Edit integrations/jira_config.env
JIRA_TICKET_MODE=individual
```

## Stage-Specific Control

You can enable JIRA ticket creation for specific validation stages:

```bash
# Enable only for pre-deployment checks
ENABLE_JIRA_PRE=true
ENABLE_JIRA_POST=false

# Enable only for post-deployment checks
ENABLE_JIRA_PRE=false
ENABLE_JIRA_POST=true

# Enable for both stages
ENABLE_JIRA_PRE=true
ENABLE_JIRA_POST=true
```

## Implementation Details

### Individual Mode Flow
1. Validation check fails
2. Immediately creates JIRA ticket
3. Continues with next check
4. Each failure gets its own ticket

### Consolidated Mode Flow
1. Validation check fails
2. Stores failure information
3. Continues with next check
4. After all checks complete, creates one ticket with all failures

### Ticket Content Structure

**Individual tickets include:**
- Check ID and failure message
- Stage (pre/post)
- Host information (if available)
- Extra metadata (if available)
- Full failure output

**Consolidated tickets include:**
- Summary section with failure count and brief descriptions
- Detailed section with complete information for each failure
- Timestamp and stage information
- Structured format for easy reading
