# Troubleshooting Guide

## Common Issues and Solutions

### Configuration Issues

**Q: New checks aren't appearing in configuration**

A: Run the auto-discovery update:
```bash
cd validation_checks
make update-validation-config
```

**Q: Checks are running even though disabled**

A: Verify configuration syntax:
```bash
cd validation_checks
make validate-validation-config
```

Check for YAML syntax errors, incorrect indentation, or typos in check names.

**Q: Configuration seems out of date**

A: Check if config needs updating:
```bash
cd validation_checks
make check-validation-config
```

If out of date, run:
```bash
make update-validation-config
```

**Q: Auto-discovery not finding my new check**

A: Ensure your check function:
1. Has the `@check_for("app", "stage")` decorator
2. Is in a Python file under `validation_checks/checks/`
3. The module can be imported without errors

Debug by running:
```bash
cd validation_checks
python3 generate_validation_config.py --list
```

### JIRA Integration Issues

**Q: JIRA tickets aren't being created**

A: Check JIRA configuration in `integrations/jira_config.env`:
```bash
# Verify these settings
ENABLE_JIRA_PRE=true     # For pre-deployment checks
ENABLE_JIRA_POST=true    # For post-deployment checks
JIRA_URL=https://your-jira.com
JIRA_USER=your-user
JIRA_TOKEN=your-token
PROJECT_KEY=YOUR_PROJECT
```

Test JIRA connectivity:
```bash
cd validation_checks
make test-jira-modes
```

**Q: Too many JIRA tickets being created**

A: Switch to consolidated mode:
```bash
# Edit integrations/jira_config.env
JIRA_TICKET_MODE=consolidated
```

**Q: Want individual tickets instead of consolidated**

A: Switch to individual mode:
```bash
# Edit integrations/jira_config.env
JIRA_TICKET_MODE=individual
```

**Q: JIRA authentication failing**

A: Verify authentication settings:
- Check `AUTH_STYLE` (bearer vs basic)
- Verify token/credentials are correct
- Ensure user has permissions to create tickets in the project

### Validation Execution Issues

**Q: Can't find disabled checks in output**

A: Disabled checks are logged. Look for messages like:
```
INFO: Skipped 5 disabled checks
```

For detailed list, check debug logs or temporarily enable verbose logging.

**Q: Validation fails but should pass**

A: Check if specific checks are causing issues:
1. Identify failing check from output
2. Temporarily disable it:
   ```yaml
   validation_control:
     app_controls:
       app_name:
         check_controls:
           failing_check_name: false
   ```
3. Investigate and fix the underlying issue
4. Re-enable the check

**Q: All validation checks are being skipped**

A: Check global enable setting:
```yaml
validation_control:
  global_enabled: true  # Ensure this is true
```

**Q: App-specific checks not running**

A: Verify app is enabled:
```yaml
validation_control:
  app_controls:
    your_app:
      enabled: true  # Ensure this is true
```

### Debug Mode

**Q: Need more detailed debugging information**

A: Use detailed debugging:

1. **Verbose auto-discovery:**
   ```bash
   python3 generate_validation_config.py -v
   ```

2. **Check validation structure:**
   ```bash
   python3 generate_validation_config.py --list
   ```

3. **Run validation with debug logging:**
   ```python
   import logging
   logging.basicConfig(level=logging.DEBUG)
   # Then run validation
   ```

4. **Test specific functionality:**
   ```bash
   cd validation_checks
   make test-validation-control
   make test-jira-modes
   ```

### File and Path Issues

**Q: Configuration file not found**

A: Ensure the file exists at the expected location:
```bash
ls -la validation_checks/validation_policies/default.yaml
```

If missing, generate it:
```bash
cd validation_checks
make update-validation-config
```

**Q: Module import errors**

A: Check Python path and module structure:
```bash
cd validation_checks
python3 -c "from validation_checks.check_core import CHECK_REGISTRY; print(CHECK_REGISTRY)"
```

Ensure all `__init__.py` files are present in check directories.

### Permission Issues

**Q: Permission denied when writing configuration**

A: Check file permissions:
```bash
ls -la validation_checks/validation_policies/
```

Ensure you have write permissions to the directory.

**Q: JIRA API permission errors**

A: Verify your JIRA user has:
- Permission to create issues in the target project
- Valid API token (not password)
- Correct project key

## Diagnostic Commands

### System Health Check
```bash
cd validation_checks

# Check all components
make help-validation                    # Verify Makefile works
make list-validation-checks            # Test auto-discovery
make validate-validation-config        # Test config syntax
make test-validation-control           # Test control logic
make test-jira-modes                  # Test JIRA integration
make test-enhanced-reporting          # Test detailed logging
```

### Configuration Verification
```bash
# View current configuration
cat validation_checks/validation_policies/default.yaml

# Check what would be discovered
python3 validation_checks/generate_validation_config.py --list

# Validate JIRA settings
python3 validation_checks/tests/test_jira_modes.py
```

### Log File Analysis
```bash
# Check detailed validation reports
tail -f validation_checks/check_logs/validation_reports.log

# View latest run summary
grep -A 20 "VALIDATION CHECKS RUN SUMMARY" validation_checks/check_logs/validation_reports.log | tail -25

# Check for recent failures
grep "FAILED" validation_checks/check_logs/validation_reports.log | tail -10

# View execution times
grep "\[.*s\]" validation_checks/check_logs/validation_reports.log | tail -10

# Check JIRA activity
grep "JIRA ACTIVITY" validation_checks/check_logs/validation_reports.log | tail -5
```

### Manual Test Run
```bash
# Test with minimal spec (create a simple test file)
echo 'platforms: [{apps: [{type: "bpa"}]}]' > test_spec.yaml
python3 validation_checks/run_validation_checks.py -t pre -s test_spec.yaml
rm test_spec.yaml
```

## Getting Help

### Log Analysis
When reporting issues, include:
1. **Command that failed**
2. **Complete error output**
3. **Configuration file contents** (sanitize sensitive data)
4. **Environment information** (OS, Python version)
5. **Recent entries from validation_reports.log**

### Enhanced Log Debugging

**Check specific validation run details:**
```bash
# Find runs by timestamp
grep "VALIDATION CHECKS RUN STARTED" validation_checks/check_logs/validation_reports.log

# Get complete run details
sed -n '/VALIDATION CHECKS RUN STARTED/,/VALIDATION CHECKS RUN COMPLETED/p' \
  validation_checks/check_logs/validation_reports.log | tail -100

# Focus on failures only
grep -A 10 "FAILED" validation_checks/check_logs/validation_reports.log
```

**Performance analysis:**
```bash
# Find slow checks
grep "\[.*s\]" validation_checks/check_logs/validation_reports.log | \
  sort -k6 -nr | head -10

# Average execution time trends
grep "Average check execution time" validation_checks/check_logs/validation_reports.log
```

**Configuration audit:**
```bash
# Track configuration changes over time
grep -A 15 "POLICY CONFIGURATION" validation_checks/check_logs/validation_reports.log

# Check which checks were skipped and when
grep "Checks Skipped:" validation_checks/check_logs/validation_reports.log
```

### Configuration Debugging
To debug configuration issues:

1. **Check syntax:**
   ```bash
   python3 -c "import yaml; print(yaml.safe_load(open('validation_checks/validation_policies/default.yaml')))"
   ```

2. **Verify structure:**
   ```bash
   cd validation_checks
   python3 generate_validation_config.py --validate
   ```

3. **Compare with fresh config:**
   ```bash
   python3 generate_validation_config.py -o /tmp/fresh_config.yaml --fresh
   diff validation_policies/default.yaml /tmp/fresh_config.yaml
   ```

### JIRA Debugging
To debug JIRA issues:

1. **Test configuration loading:**
   ```python
   from integrations import jira_utils
   print(f"Mode: {jira_utils.get_ticket_mode()}")
   print(f"Pre enabled: {jira_utils.ENABLE_JIRA_PRE}")
   print(f"Post enabled: {jira_utils.ENABLE_JIRA_POST}")
   ```

2. **Test ticket creation (if JIRA is configured):**
   ```python
   # Only run if you want to create a test ticket
   from integrations import jira_utils
   key = jira_utils.raise_ticket("test.check", "Test message", stage="pre")
   print(f"Created ticket: {key}")
   ```

Remember to clean up test tickets if you create them!
