# Validation Checks Framework

## Overview

The validation checks framework provides comprehensive control over validation execution during pre- and post-deployment phases for the CX Installer platform.

## Key Features

- **Hierarchical Control**: Global → App → Stage → Individual check levels
- **Auto-Discovery**: Automatically discovers and configures new validation checks
- **JIRA Integration**: Flexible ticket creation (individual or consolidated)
- **Enhanced Reporting**: Comprehensive logging with detailed execution reports
- **Backward Compatible**: Preserves existing policy structure and functionality
- **Easy Management**: Simple make targets for common operations

## Quick Start

```bash
# Navigate to validation checks directory
cd validation_checks

# See all available checks (30 checks across 2 apps)
make list-validation-checks

# Update configuration with any new checks
make update-validation-config

# Run tests to verify functionality
make test-validation-control

# Test JIRA integration
make test-jira-modes

# Test enhanced reporting
make test-enhanced-reporting

# Get help
make help-validation

# View detailed execution logs
tail -f check_logs/validation_reports.log
```

## Current Discovery Results
- **BPA**: 13 checks (11 pre-deployment, 2 post-deployment)
- **NSO**: 17 checks (15 pre-deployment, 2 post-deployment)
- **Total**: 30 checks across 2 apps

## Documentation Structure

- **[Configuration Guide](configuration.md)** - How to configure validation control
- **[JIRA Integration](jira_integration.md)** - JIRA ticket creation modes and setup
- **[Development Guide](development.md)** - Adding new checks and workflows
- **[Usage Examples](usage_examples.md)** - Common configuration scenarios
- **[Troubleshooting](troubleshooting.md)** - Common issues and solutions

## Running Validation

The existing validation command works unchanged:

```bash
cd .. # Back to root directory
python3 validation_checks/run_validation_checks.py -t pre -s path/to/spec.yaml
```
The system automatically:
1. Loads the validation control configuration
2. Skips disabled checks with appropriate logging
3. Runs only enabled checks
4. Creates JIRA tickets based on configured mode
5. Provides summary of skipped checks

The validation check through new shell script goes as :

```bash
From cx-installer/validation_checks folder - 
./run_validation.sh pre ../specification/nso_spec/userSpecVanillaVM_nso.yaml
```

```bash
Usage: ./run_validation.sh [OPTIONS] COMMAND
COMMANDS:
    pre <spec_file>              Run pre-deployment validation checks
    post <spec_file>             Run post-deployment validation checks
    list                         List all available validation checks
    config                       Show current validation configuration
    logs                         Show recent validation logs
    help                         Show this help message

OPTIONS:
    -p, --policy <file>          Use custom policy file (default: validation_policies/default.yaml)
    -v, --verbose                Enable verbose output
    -q, --quiet                  Suppress non-error output
    -f, --follow-logs            Follow validation logs in real-time
    --jira-mode <mode>          Set JIRA ticket mode: individual|consolidated
    --no-jira                   Disable JIRA ticket creation
    --dry-run                   Show what would be run without executing
    --update-config             Update validation configuration before running
    --validate-config           Validate configuration file before running

EXAMPLES:
    ./run_validation.sh pre /path/to/deployment.yaml                    # Run pre-deployment checks
    ./run_validation.sh post /path/to/deployment.yaml -v               # Run post-deployment checks (verbose)
    ./run_validation.sh pre spec.yaml --jira-mode consolidated         # Use consolidated JIRA tickets
    ./run_validation.sh list                                            # List all available checks
    ./run_validation.sh config                                          # Show current configuration
    ./run_validation.sh logs --follow-logs                              # Follow logs in real-time

CONFIGURATION:
    Policy file: /root/mandakini/cx-installer/validation_checks/validation_policies/default.yaml
    Logs directory: /root/mandakini/cx-installer/validation_checks/check_logs
    JIRA config: ../integrations/jira_config.env
```


## Files and Components

### Core Files
- `validation_checks/validation_policies/default.yaml` - Main configuration file
- `validation_checks/validation_policies/example_config.yaml` - Example configurations
- `validation_checks/generate_validation_config.py` - Auto-discovery script
- `validation_checks/tests/test_validation_control.py` - Validation control test suite
- `validation_checks/tests/test_jira_modes.py` - JIRA integration test suite
- `validation_checks/Makefile` - Management targets

### Enhanced Files
- `validation_checks/run_validation_checks.py` - Enhanced with validation control
- `validation_checks/check_core.py` - Core check registration system
- `integrations/jira_utils.py` - Enhanced with consolidated ticket support
- `integrations/jira_config.env` - JIRA configuration including ticket modes

The validation checks framework provides a robust, flexible, and maintainable solution for managing validation checks across the CX Installer platform! 🚀
