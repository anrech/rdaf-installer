0.1.0 (Aug 26, 2025)

Initial doc release
