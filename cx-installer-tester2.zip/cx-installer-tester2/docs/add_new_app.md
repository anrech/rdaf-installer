## Key Points:
 - Each app is modular: add new apps by creating a new folder under apps/.
 - Centralize deployment logic in deploy/ (e.g., cli.py and deployer_main.py).
 - Use Makefile for automation (build, deploy, lint, etc.).
 - Place all ansible playbooks and dependencies under ansible_playbooks
 - Place all documentation in docs/.
 - .gitignore should cover Python, OS, and editor artifacts.

 How to deploy:
     - python/python3 deploy/cli.py --spec << spec-file-name-with-absolute-path >>


## - How to add new apps

1. **Create the App Model**
Add a new class for your app in app.py, similar to NSO and BPA.

- Example:
```
class MyApp(App):
    type: Literal['MyApp']
    version: str
    ## Add other fields as needed
```

2. **Add App Logic in src**
Create a new folder for your app under apps/<your_app>/src/.
Add validation, precheck, postcheck, and any other logic scripts (like myapp_validations.py, myapp_precheck.py, etc.).
Follow the structure used for NSO and BPA.

3. **Add App to Spec Schema**
Update your spec schema (e.g., specification/specschema.yaml) to allow your new app under platforms[].apps[].
Add required fields for your app.

4. **Add App Handler in CLI**
In deploy/cli.py, add logic to detect and handle your new app in the deployment workflow:
for app in apps:
    if app.name == "MyApp":
        import myapp_validations as myapp
        myapp.run_myapp_precheck(spec)
        # ...other steps...

5. **Add Ansible Playbooks and Roles**
Add playbooks and roles for your app in ansible_playbooks/roles/ and ansible_playbooks/playbooks/.
Follow the structure used for NSO and BPA.
     1. **Create a New Role**
     - In `ansible_playbooks/roles/`, create a new directory for your app (e.g., `my_app`).
     - Add the standard Ansible role structure:
     ```
     ansible_playbooks/roles/my_app/
       ├── tasks/
       │   └── main.yml
       ├── templates/
       └── files/
     ```

    2. **Write Tasks**
     - In `tasks/main.yml`, define the steps to install or configure your app.
     - Example:
     ```yaml
     # filepath: ansible_playbooks/roles/my_app/tasks/main.yml
     ---
     - name: Deploy My App
       ansible.builtin.shell: |
         kubectl apply -f /path/to/my_app_manifest.yaml
     ```

    3. **Add to Playbook**
     - Edit the relevant playbook (e.g., `ansible_playbooks/playbooks/app_install.yml`) and include your new role:
     ```yaml
     # filepath: ansible_playbooks/playbooks/app_install.yml
     ...
     roles:
       - k8s_install/load_images
       - my_app
     ```

   4. **Add Variables (Optional)**
     - If your app needs variables, add them to `group_vars` or `host_vars`.

---

6. **Add Driver/Model/app and platform specific Wrapper**
    •	Add changes to cx-installer/deploy/cli.py
	•	Add changes to cx-installer/deploy/deployer_main.py
	•	Update the deploy/models/platform.py for new platform driver if any
	•	Add cx-installer/deploy/driver/platform/<name_of_platform>.py for new platform
	•	Create a new folder under apps for a new application and add ur app specific pre and post checks here
	•	Update the deploy/models/app.py for new app driver if any
	•	Add cx-installer/deploy/driver/apps/app_<appname>_driver.py for new app
	•	Add the manifest/spec file under specification/<name_of_app>/<spec.yaml>
	•	Add any Python dependencies to requirements.txt
    •   Update README.md
      


8. **Add Dependencies**
Add any Python dependencies to requirements.txt.
Add OS/package dependencies to your documentation.

9. **Test and Commit**

- Test your changes locally or in a test environment.
- Commit your new role/script and update the playbooks as needed.
- Open a pull request for review.

9. **Test End-to-End**
Add your app to a test spec file.
Run the CLI with your new app and verify all steps (precheck, deploy, postcheck, etc.) work.

**Note**
Follow the structure and naming conventions used for NSO and BPA for consistency.

# - How to contribute (fork, branch, PR workflow)
