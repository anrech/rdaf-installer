# How to Contribute

Programmable installer is a open source project that is under very active development. We’re still working out the kinks to make contributing to this project as easy and transparent as possible, but we’re not quite there yet. Hopefully this document makes the process for contributing clear and answers some questions that you may have.


## Open Development

All work on programmable installer happens directly on GitHub. Both core team members and external contributors send pull requests which go through the same review process.

## Semantic Versioning

We follow the below mentioned versioning strategy. 
Given a version number MAJOR.MINOR.PATCH, increment the:

  MAJOR version when you make incompatible API changes
  MINOR version when you add functionality in a backward compatible manner
  PATCH version when you make backward compatible bug fixes
 Additional labels for pre-release and build metadata are available as extensions to the MAJOR.MINOR.PATCH format.

 Every significant change is documented in the https://wwwin-github.cisco.com/CX-SAO-TOOLS/cx-installer/blob/develop/docs/CHANGELOG.md

 ## Branch Organization

Submit all changes directly to the develop branch. We don’t use separate branches for development or for upcoming releases. We do our best to keep develop in good shape, with all tests passing.

Code that lands in develop must be compatible with the latest stable release. It may contain additional features, but no breaking changes. We should be able to release a new minor version from the tip of main at any time.

## Bugs

### Where to Find Known Issues

We are using JIRA for our bugs. We keep a close eye on this and try to make it clear when we have an internal fix in progress. Before filing a new jira task, try to make sure your problem doesn’t already exist.

### Reporting New Issues
The best way to get your bug fixed is to create a new JIRA bug

## How to Get in Touch

platform-installer@cisco.com

## Proposing a Change
If you intend to change the public API, or make any non-trivial changes to the implementation, we recommend filing an issue. This lets us reach an agreement on your proposal before you put significant effort into it.

If you’re only fixing a bug, it’s fine to submit a pull request right away but we still recommend to file an issue detailing what you’re fixing. This is helpful in case we don’t accept that specific fix but want to keep track of the issue.





