"""
Light-weight helper around Jira REST API.

* Reads server URL, user, token from ENV or .env file.
* Exposes a single `raise_ticket()` used by validation_checks.py
  and by any individual check that wants custom logic.

Requires:  requests  (pip install requests)
"""
from __future__ import annotations

import logging
import os
import time
from datetime import datetime
from functools import wraps
from typing import Any, Dict
from urllib.parse import urlparse

import requests
from dotenv import load_dotenv

log = logging.getLogger("jira")

# Get the directory where this script is located
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
env_file = os.path.join(BASE_DIR, "jira_config.env")

if os.path.exists(env_file):
    load_dotenv(env_file)
else:
    log.warning(f"JIRA config file '{env_file}' was not found, unable to raise tickets.")

JIRA_URL   = os.getenv("JIRA_URL", "")
JIRA_USER  = os.getenv("JIRA_USER", "")
JIRA_TOKEN = os.getenv("JIRA_TOKEN", "")
PROJECT_KEY = os.getenv("PROJECT_KEY", "")
AUTH_STYLE = os.getenv("AUTH_STYLE", "bearer").lower()   # "basic" (default) or "bearer"
ENABLE_JIRA_PRE = os.getenv("ENABLE_JIRA_PRE", "true").lower() == "true"
ENABLE_JIRA_POST = os.getenv("ENABLE_JIRA_POST", "true").lower() == "true"
JIRA_TICKET_MODE = os.getenv("JIRA_TICKET_MODE", "individual").lower()  # "individual" or "consolidated"
API_ENDPOINT = f"{JIRA_URL}/rest/api/2/issue"
API_PREFIX   = "/rest/api/2"

HEADERS = {
    "Content-Type": "application/json",
}


def retry_on_failure(max_retries=3, delay=1.0):
    """Decorator to retry function calls on failure with exponential backoff."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt == max_retries - 1:
                        log.error(f"Function {func.__name__} failed after {max_retries} attempts: {e}")
                        raise

                    # Exponential backoff with jitter
                    sleep_time = delay * (2 ** attempt) + (0.1 * attempt)
                    log.warning(f"Attempt {attempt + 1} failed: {e}. Retrying in {sleep_time:.1f}s...")
                    time.sleep(sleep_time)
            return None
        return wrapper
    return decorator


def validate_jira_config():
    """Validate required JIRA configuration variables."""
    required_vars = {
        "JIRA_URL": JIRA_URL,
        "JIRA_USER": JIRA_USER,
        "JIRA_TOKEN": JIRA_TOKEN,
        "PROJECT_KEY": PROJECT_KEY
    }

    missing = []
    empty = []

    for var_name, var_value in required_vars.items():
        if not var_value:
            if var_value is None:
                missing.append(var_name)
            else:
                empty.append(var_name)

    if missing or empty:
        error_msg = []
        if missing:
            error_msg.append(f"Missing environment variables: {', '.join(missing)}")
        if empty:
            error_msg.append(f"Empty environment variables: {', '.join(empty)}")

        full_error = "; ".join(error_msg)
        log.error(f"JIRA configuration validation failed: {full_error}")
        raise ValueError(f"Invalid JIRA configuration: {full_error}")

    # Mask sensitive data for logging
    masked_token = f"{JIRA_TOKEN[:4]}...{JIRA_TOKEN[-4:]}" if len(JIRA_TOKEN) > 8 else "***"
    log.debug(f"JIRA config validated - URL: {JIRA_URL}, User: {JIRA_USER}, Token: {masked_token}, Project: {PROJECT_KEY}")


def _ensure_scheme(url: str) -> str:
    return url if urlparse(url).scheme else "https://" + url


@retry_on_failure(max_retries=3, delay=2.0)
def _api(path: str, payload: Dict[str, Any]):
    """Make authenticated API call to JIRA with retry logic."""
    validate_jira_config()

    url = f"{_ensure_scheme(JIRA_URL)}{API_PREFIX}/{path.lstrip('/')}"

    # Mask sensitive data in logs
    log_payload = {k: v for k, v in payload.items()}
    if 'description' in log_payload and len(str(log_payload['description'])) > 200:
        log_payload['description'] = f"{str(log_payload['description'])[:200]}..."

    log.debug(f"Making JIRA API call to {url} with payload keys: {list(payload.keys())}")

    try:
        if AUTH_STYLE == "basic":
            resp = requests.post(url,
                                 json=payload,
                                 auth=(JIRA_USER, JIRA_TOKEN),
                                 headers=HEADERS,
                                 timeout=30,  # Increased timeout
                                 allow_redirects=False)
        else:  # bearer
            hdrs = HEADERS.copy()
            hdrs["Authorization"] = f"Bearer {JIRA_TOKEN}"
            resp = requests.post(url,
                                 json=payload,
                                 headers=hdrs,
                                 timeout=30,  # Increased timeout
                                 allow_redirects=False)

        if resp.status_code in (301, 302, 303, 307, 308):
            raise RuntimeError(f"Jira redirected to {resp.headers.get('Location')}. "
                               "Check auth style or base URL.")
        if resp.status_code >= 300:
            raise RuntimeError(f"Jira error {resp.status_code}: {resp.text}")

        log.debug(f"JIRA API call successful: {resp.status_code}")
        return resp.json()

    except requests.exceptions.Timeout:
        raise RuntimeError("JIRA API request timed out")
    except requests.exceptions.ConnectionError:
        raise RuntimeError("Failed to connect to JIRA API")
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"JIRA API request failed: {e}")


@retry_on_failure(max_retries=3, delay=1.0)
def raise_ticket(check_id: str,
                 message: str,
                 host: str | None = None,
                 stage: str | None = None,
                 extra: Dict[str, Any] | None = None) -> str | None:
    """
    Create a Jira ticket and return the ticket key, or None if disabled.
    """
    # Check if ticket creation is enabled for this stage
    if (stage == "pre" and not ENABLE_JIRA_PRE) or (stage == "post" and not ENABLE_JIRA_POST):
        log.info(f"Jira ticket creation disabled for stage: {stage}")
        return None
    summary = f"[{check_id}] {message.splitlines()[0][:120]}"
    desc_lines = [
        f"*Check ID*: {check_id}",
        f"*Stage*: {stage or 'unknown'}",
        f"*Host*:  {host or 'N/A'}",
        "",
        "{code}",
        message,
        "{code}",
    ]
    if extra:
        desc_lines += ["", "*Extra Info:*", f"{{code}}{extra}{{code}}"]

    payload = {
        "fields": {
            "project": {"key": PROJECT_KEY},
            "summary": summary,
            "description": "\n".join(desc_lines),
            "issuetype": {"name": "Bug"},
            "labels": ["precheck-failure"],
        }
    }
    data = _api("issue", payload)
    key  = data["key"]
    log.info("Jira ticket created: %s", key)
    return key


def raise_consolidated_ticket(failures: list[dict], stage: str | None = None) -> str | None:
    """
    Create a single consolidated Jira ticket for multiple failures.

    Args:
        failures: List of failure dictionaries with keys: check_id, message, host, extra
        stage: The validation stage (pre/post)

    Returns:
        Ticket key if created, None if disabled or no failures
    """
    if not failures:
        return None

    # Check if ticket creation is enabled for this stage
    if (stage == "pre" and not ENABLE_JIRA_PRE) or (stage == "post" and not ENABLE_JIRA_POST):
        log.info(f"Jira ticket creation disabled for stage: {stage}")
        return None

    # Create summary
    num_failures = len(failures)
    summary = f"[{stage.upper() if stage else 'VALIDATION'}] {num_failures} Validation Check Failures"

    # Build description
    desc_lines = [
        f"*Stage*: {stage or 'unknown'}",
        f"*Total Failures*: {num_failures}",
        f"*Timestamp*: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "h3. Failed Checks Summary",
    ]

    # Add summary table
    for i, failure in enumerate(failures, 1):
        check_id = failure.get('check_id', 'unknown')
        message_preview = failure.get('message', '').splitlines()[0][:100]
        desc_lines.append(f"{i}. *{check_id}*: {message_preview}")

    desc_lines.extend(["", "h3. Detailed Failure Information", ""])

    # Add detailed information for each failure
    for i, failure in enumerate(failures, 1):
        check_id = failure.get('check_id', 'unknown')
        message = failure.get('message', 'No message provided')
        host = failure.get('host', 'N/A')
        extra = failure.get('extra')

        desc_lines.extend([
            f"h4. {i}. {check_id}",
            f"*Host*: {host}",
            "",
            "{code}",
            message,
            "{code}",
        ])

        if extra:
            desc_lines.extend(["", "*Extra Info:*", f"{{code}}{extra}{{code}}"])

        desc_lines.append("")  # Add spacing between failures

    payload = {
        "fields": {
            "project": {"key": PROJECT_KEY},
            "summary": summary,
            "description": "\n".join(desc_lines),
            "issuetype": {"name": "Bug"},
            "labels": ["validation-failures", f"{stage}-check" if stage else "validation-check"],
        }
    }

    data = _api("issue", payload)
    key = data["key"]
    log.info("Consolidated Jira ticket created: %s (%d failures)", key, num_failures)
    return key


def get_ticket_mode() -> str:
    """Get the current JIRA ticket creation mode."""
    return JIRA_TICKET_MODE


if __name__ == "__main__":
    data = raise_ticket(
        check_id="test.check",
        message="This is a test message for the Jira ticket creation.",
        host="test-host.example.com")

    print(f"Ticket created: {data}")
