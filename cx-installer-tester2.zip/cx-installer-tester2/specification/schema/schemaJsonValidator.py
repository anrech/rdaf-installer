import yaml
import json
from pathlib import Path
from jsonschema import Draft7Validator

def load_yaml_file(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def load_json_schema(path):
    with open(path, "r") as f:
        return json.load(f)

def validate_yaml(data, validator):
    return sorted(validator.iter_errors(data), key=lambda e: e.path)

def validate_folder(schema_map, folder_path):
    json_files = list(Path(folder_path).rglob("*.json"))

    if not json_files:
        print(f"No JSON files found in folder: {folder_path}")
        return

    for file_path in json_files:
        lower_name = file_path.name.lower()
        schema_file = None

        # dynamic match against all schema_map keys (case insensitive)
        for key, path in schema_map.items():
            if key in lower_name:
                schema_file = path
                break

        if not schema_file:
            print(f"\n⚠️ Skipping {file_path.name}, no matching schema")
            continue

        print(f"\n📄 Validating {file_path.name} with {schema_file} ...")
        try:
            schema = load_json_schema(schema_file)
            validator = Draft7Validator(schema)
            data = load_yaml_file(file_path)
            errors = validate_yaml(data, validator)
            if errors:
                print(f"❌ {len(errors)} error(s) found:")
                for error in errors:
                    path = ".".join(map(str, error.absolute_path))
                    print(f"   - {path}: {error.message}")
            else:
                print("✅ Valid")
        except Exception as e:
            print(f"⚠️ Failed to validate {file_path.name}: {e}")

if __name__ == "__main__":
    # normalize all keys to lowercase
    schema_map = {
        "bpa": "SCHEMA/schema.bpa.intentjson.json",
        "nso": "SCHEMA/schema.nso.intentjson.json",
        "rdaf": "SCHEMA/schema.rdaf.intentjson.json",
        # "vmanage": "SCHEMA/schema.vmanage.intentjson.json",
        "rke": "SCHEMA/schema.rke.intentjson.json",
        "k8snative": "SCHEMA/schema.k8sNative.intentjson.json",
    }
    schema_map = {k.lower(): v for k, v in schema_map.items()}

    samples_folder = "JSON"
    validate_folder(schema_map, samples_folder)
