import json
import yaml
from pathlib import Path

INPUT_DIR = Path("JSON")
OUTPUT_DIR = Path("YAML")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def prune_empty(obj):
    """Recursively remove empty values, arrays, and objects."""
    if isinstance(obj, dict):
        return {
            k: prune_empty(v)
            for k, v in obj.items()
            if v not in (None, "", [], {})
            and prune_empty(v) != {}
            and prune_empty(v) != []
        }
    elif isinstance(obj, list):
        return [
            prune_empty(v)
            for v in obj
            if v not in (None, "", [], {})
            and prune_empty(v) != {}
            and prune_empty(v) != []
        ]
    else:
        return obj


def convert_json_to_yaml(input_file, output_file):
    with open(input_file, "r") as f:
        data = json.load(f)

    # Clean up empty/null values
    cleaned_data = prune_empty(data)

    with open(output_file, "w") as f:
        yaml.dump(cleaned_data, f, sort_keys=False)

    # print(f"✅ Converted {input_file} → {output_file}")


# Process all JSON files in INTENT
for json_file in INPUT_DIR.glob("*.json"):
    output_file = OUTPUT_DIR / (json_file.stem + ".yaml")
    print(f"\n📥 Processing INPUT: {json_file}")
    convert_json_to_yaml(json_file, output_file)


def convertJsonToYaml():
    for json_file in INPUT_DIR.glob("*.json"):
        output_file = OUTPUT_DIR / (json_file.stem + ".yaml")
        print(f"\n📥 Processing INPUT: {json_file}")
        convert_json_to_yaml(json_file, output_file)
    print(f"✅ Converted {json_file} → {output_file}")


def main():
    print("🚀 Starting JSON → YAML conversion...")
    convertJsonToYaml()
    print("🎉 All conversions completed.")


if __name__ == "__main__":
    main()
