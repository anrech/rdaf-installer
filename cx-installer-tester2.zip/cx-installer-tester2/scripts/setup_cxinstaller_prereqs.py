import subprocess
import sys
from pathlib import Path

import questionary
import requests
from tqdm import tqdm


def download_cx_files():
    url = "http://10.127.195.225/cx-installer-artifacts.tar.gz"
    tarball = Path("cx-installer-artifacts.tar.gz")
    extract_dir = Path("ansible_playbooks/")

    # Ensure target directory exists
    extract_dir.mkdir(parents=True, exist_ok=True)

    # 1. Download file (equivalent to wget)
    print(f"Downloading {url} ...")
    response = requests.get(url, stream=True)
    response.raise_for_status()
    total_size = int(response.headers.get("content-length", 0))
    block_size = 1024  # 1 KB

    with open(tarball, "wb") as f, tqdm(
        total=total_size, unit="B", unit_scale=True, desc=tarball.name, ncols=80
    ) as pbar:
        for chunk in response.iter_content(block_size):
            f.write(chunk)
            pbar.update(len(chunk))

    print(f"Saved to {tarball}")

    subprocess.run(["tar", "-xzvf", str(tarball), "-C", "ansible_playbooks/", "--strip-components=1","cx-installer-artifacts/files/"],check=True)
    print("\nExtracted file structure:\n")
    subprocess.run("tree ansible_playbooks/files",shell=True)

    # 4. Remove tarball (equivalent to rm -rf)
    print(f"\nCleaning up {tarball} ...")
    tarball.unlink()
    print("\n✅ Done.")


def main():
    choice = questionary.select(
        "Select an action:",
        choices=[
        "Install prerequisites",
        "Full setup (install prerequisites + download installer files)",
        "Exit"
        ]
    ).ask()

    install_cx_dependencies_flag : bool = False
    download_cx_files_flag: bool = False
    if choice == "Install prerequisites only":
        install_cx_dependencies_flag = True
    elif choice == "Full setup (install prerequisites + download installer files)":
        download_cx_files_flag = True
        install_cx_dependencies_flag = True
    else:
        print('Exiting')
        sys.exit(0)

    if install_cx_dependencies_flag:
        subprocess.run("dnf install epel-release sshpass python pip wget zip tree git -y",shell=True)


    subprocess.run("pip install -r requirements.txt",shell=True)

    if download_cx_files_flag:
        download_cx_files()


if __name__ == "__main__":
    main()
